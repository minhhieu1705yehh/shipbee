export type UserRole = 'ADMIN' | 'MANAGER' | 'DRIVER';

export type OrderStatus =
  | 'CHO_BAN_GIAO'      // Chờ bàn giao
  | 'DA_BAN_GIAO'       // Đã bàn giao
  | 'XE_DA_NHAN'        // Xế đã nhận
  | 'DANG_DI_GIAO'      // Đang đi giao
  | 'DA_LIEN_HE_KHACH'  // Đã liên hệ khách
  | 'GIAO_THANH_CONG'   // Giao thành công
  | 'GIAO_THAT_BAI'     // Giao thất bại
  | 'KHANG_HEN_GIAO_LAI'// Khách hẹn giao lại
  | 'KHANG_KHONG_NGHE'  // Khách không nghe máy
  | 'SAI_DIA_CHI'       // Sai địa chỉ
  | 'KHANG_TU_CHOI'     // Khách từ chối nhận
  | 'DON_HOAN'          // Đơn hoàn
  | 'DA_NOP_COD'        // Đã nộp COD
  | 'DA_DOI_SOAT';      // Đã đối soát

export type HandoverSheetStatus =
  | 'CHO_XE_XAC_NHAN'   // Đang chờ Xế xác nhận
  | 'XE_DA_XAC_NHAN'    // Xế đã xác nhận
  | 'DANG_GIAO_HANG'    // Đang giao hàng
  | 'DA_HOAN_TAT'       // Đã hoàn tất
  | 'CHO_DOI_SOAT'      // Chờ đối soát
  | 'DA_DOI_SOAT'       // Đã đối soát
  | 'CO_SAI_LECH';      // Có sai lệch

export type CODDepositStatus =
  | 'CHO_XAC_NHAN' // Chờ Quản lý xác nhận
  | 'DA_XAC_NHAN'  // Quản lý đã xác nhận
  | 'TU_CHOI';     // Bị từ chối

export interface User {
  id: string;
  username: string;
  fullName: string;
  phone: string;
  role: UserRole;
  managerId?: string; // Driver belongs to this Manager ID
  avatarUrl?: string;
  isLocked: boolean;
  createdAt: string;
  lastLogin?: string;
}

export interface Order {
  id: string;
  orderCode: string;          // Mã đơn
  trackingCode: string;       // Mã vận đơn
  recipientName: string;      // Tên người nhận
  recipientPhone: string;     // Số điện thoại
  recipientAddress: string;   // Địa chỉ
  area?: string;              // Khu vực (VD: Cầu Giấy, Hoàn Kiếm, Quận 1...)
  googleMapsUrl?: string;     // Google maps link
  codAmount: number;          // Tiền COD
  shippingFee: number;        // Phí giao hàng
  productName: string;        // Sản phẩm
  quantity: number;           // Số lượng
  notes?: string;             // Ghi chú
  labelImageUrl?: string;     // Ảnh nhãn đơn
  status: OrderStatus;        // Trạng thái đơn
  managerId: string;          // Quản lý đơn phụ trách
  driverId?: string;          // Xế phụ trách
  handoverSheetId?: string;   // Phiếu bàn giao phụ thuộc
  isPriority?: boolean;       // Đơn ưu tiên
  
  // Timestamps
  createdAt: string;
  handoverAt?: string;
  acceptedAt?: string;
  deliveredAt?: string;
  
  // Delivery proof & failure
  proofImageUrl?: string;     // Ảnh xác nhận giao hàng
  failureReason?: string;     // Lý do giao thất bại
  collectedCodAmount?: number;// Số tiền COD đã thu
  deliveryLocation?: {        // Vị trí GPS khi giao thành công
    lat: number;
    lng: number;
    addressName?: string;
  };
}

export interface HandoverSheet {
  id: string;
  sheetCode: string;          // Mã phiếu bàn giao (VD: PBG-20260730-01)
  managerId: string;          // ID Quản lý đơn
  managerName: string;
  driverId: string;           // ID Xế
  driverName: string;
  orderIds: string[];         // Danh sách ID đơn hàng
  totalOrders: number;        // Tổng số đơn
  totalCodAmount: number;     // Tổng tiền COD
  status: HandoverSheetStatus;
  
  createdAt: string;
  acceptedAt?: string;
  reconciledAt?: string;
  
  acceptanceDevice?: string;  // Thiết bị xác nhận
  acceptanceLocation?: string;// Vị trí xác nhận
  
  hasDiscrepancy?: boolean;   // Có sai lệch không
  discrepancyNote?: string;   // Ghi chú sai lệch
}

export interface CODDeposit {
  id: string;
  depositCode: string;        // Mã phiếu nộp COD
  driverId: string;
  driverName: string;
  managerId: string;
  managerName: string;
  amount: number;             // Số tiền nộp
  proofImageUrl?: string;     // Ảnh biên nhận / chuyển khoản
  note?: string;
  status: CODDepositStatus;
  createdAt: string;
  confirmedAt?: string;
}

export interface ActivityLog {
  id: string;
  userId: string;
  userName: string;
  userRole: UserRole;
  action: string;             // Ví dụ: "Tạo đơn hàng", "Bàn giao đơn", "Xác nhận nhận đơn", "Đổi trạng thái"
  entityType: 'ORDER' | 'HANDOVER' | 'USER' | 'COD' | 'SYSTEM';
  entityId: string;
  details: string;
  oldValue?: string;
  newValue?: string;
  timestamp: string;
}

export interface NotificationItem {
  id: string;
  userId: string;             // Targeted user ID (or 'ALL' or 'ADMIN')
  title: string;
  message: string;
  type: 'INFO' | 'WARNING' | 'SUCCESS' | 'ALERT';
  read: boolean;
  createdAt: string;
  linkTab?: string;
}

export type TransferBatchStatus =
  | 'CHO_TIEP_NHAN'     // Chờ kho nhận tiếp nhận & quét đối soát
  | 'DA_TIEP_NHAN'      // Kho nhận đã quét kiểm đếm & nhận lô
  | 'DA_THANH_TOAN_COD' // Đã thanh toán / trả tiền COD theo lô
  | 'TU_CHOI';           // Bị từ chối

export interface ManagerTransferBatch {
  id: string;
  batchCode: string;             // Ví dụ: BATCH-LOC-HA-20260730-01
  senderManagerId: string;
  senderManagerName: string;
  receiverManagerId: string;
  receiverManagerName: string;
  areaName: string;              // Khu vực (Lộc Hà, Can Lộc, Hương Sơn, Hồng Lĩnh...)
  orderIds: string[];            // Danh sách ID đơn trong lô
  scannedOrderIds: string[];     // Danh sách ID đơn đã quét mã vạch đối soát khi nhận
  totalOrders: number;
  totalCodAmount: number;
  status: TransferBatchStatus;
  note?: string;
  createdAt: string;
  acceptedAt?: string;
  settledAt?: string;
  settledCodAmount?: number;     // Số tiền COD đã thanh toán đối soát theo lô
}

export interface AreaGroup {
  areaName: string;
  ordersCount: number;
  orders: Order[];
}
