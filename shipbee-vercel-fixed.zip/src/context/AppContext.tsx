import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  User,
  Order,
  HandoverSheet,
  CODDeposit,
  ActivityLog,
  NotificationItem,
  UserRole,
  OrderStatus,
  CODDepositStatus,
  ManagerTransferBatch,
} from '../types';
import { Storage } from '../utils/storage';

interface AppContextType {
  currentUser: User | null;
  users: User[];
  orders: Order[];
  handoverSheets: HandoverSheet[];
  codDeposits: CODDeposit[];
  transferBatches: ManagerTransferBatch[];
  activityLogs: ActivityLog[];
  notifications: NotificationItem[];
  theme: 'light' | 'dark';
  
  // Auth & Account
  switchUser: (userId: string) => void;
  createAccount: (data: Omit<User, 'id' | 'createdAt' | 'isLocked'>) => void;
  toggleLockAccount: (userId: string) => void;
  assignDriverToManager: (driverId: string, managerId: string) => void;
  
  // Orders
  createOrder: (orderData: Partial<Order>) => Order;
  batchCreateOrders: (ordersData: Partial<Order>[]) => void;
  updateOrder: (orderId: string, data: Partial<Order>) => void;
  deleteOrder: (orderId: string) => boolean;
  
  // Handover Workflow (Manager -> Driver)
  createHandoverSheet: (driverId: string, orderIds: string[]) => HandoverSheet | null;
  acceptHandoverSheet: (sheetId: string) => void;
  rejectHandoverSheet: (sheetId: string, reason: string) => void;

  // Inter-Manager Batch Transfer Workflow (Manager -> Manager)
  createTransferBatch: (receiverManagerId: string, orderIds: string[], areaName: string, note?: string) => ManagerTransferBatch | null;
  scanOrderInBatch: (batchId: string, trackingOrOrderCode: string) => { success: boolean; message: string };
  acceptTransferBatch: (batchId: string) => void;
  settleBatchCod: (batchId: string, settledAmount: number) => void;
  
  // Driver Actions & Delivery
  updateOrderStatus: (
    orderId: string,
    status: OrderStatus,
    extraData?: {
      proofImageUrl?: string;
      failureReason?: string;
      collectedCodAmount?: number;
      location?: { lat: number; lng: number; addressName?: string };
    }
  ) => void;
  
  // COD Management
  submitCodDeposit: (amount: number, proofImageUrl?: string, note?: string) => void;
  confirmCodDeposit: (depositId: string) => void;
  reconcileHandoverSheet: (sheetId: string) => void;
  
  // System Utils
  toggleTheme: () => void;
  resetDemoData: () => void;
  markNotificationRead: (id: string) => void;
  addActivityLog: (action: string, entityType: ActivityLog['entityType'], entityId: string, details: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [users, setUsers] = useState<User[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [handoverSheets, setHandoverSheets] = useState<HandoverSheet[]>([]);
  const [codDeposits, setCodDeposits] = useState<CODDeposit[]>([]);
  const [transferBatches, setTransferBatches] = useState<ManagerTransferBatch[]>([]);
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [currentUserId, setCurrentUserId] = useState<string>('usr_admin');
  const [theme, setTheme] = useState<'light' | 'dark'>('light');

  // Load from Storage on Mount
  useEffect(() => {
    const loadedUsers = Storage.getUsers();
    const loadedOrders = Storage.getOrders();
    const loadedSheets = Storage.getHandovers();
    const loadedDeposits = Storage.getCodDeposits();
    const loadedBatches = Storage.getTransferBatches();
    const loadedLogs = Storage.getActivityLogs();
    const loadedNotifs = Storage.getNotifications();
    const loadedCurrentId = Storage.getCurrentUserId();
    const loadedTheme = Storage.getTheme();

    setUsers(loadedUsers);
    setOrders(loadedOrders);
    setHandoverSheets(loadedSheets);
    setCodDeposits(loadedDeposits);
    setTransferBatches(loadedBatches);
    setActivityLogs(loadedLogs);
    setNotifications(loadedNotifs);
    setCurrentUserId(loadedCurrentId);
    setTheme(loadedTheme);

    if (loadedTheme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, []);

  const currentUser = users.find((u) => u.id === currentUserId) || users[0] || null;

  // Save changes
  const saveAll = (
    newUsers = users,
    newOrders = orders,
    newSheets = handoverSheets,
    newDeposits = codDeposits,
    newLogs = activityLogs,
    newNotifs = notifications
  ) => {
    Storage.saveUsers(newUsers);
    Storage.saveOrders(newOrders);
    Storage.saveHandovers(newSheets);
    Storage.saveCodDeposits(newDeposits);
    Storage.saveActivityLogs(newLogs);
    Storage.saveNotifications(newNotifs);
  };

  const addActivityLog = (
    action: string,
    entityType: ActivityLog['entityType'],
    entityId: string,
    details: string
  ) => {
    if (!currentUser) return;
    const newLog: ActivityLog = {
      id: `log_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
      userId: currentUser.id,
      userName: currentUser.fullName,
      userRole: currentUser.role,
      action,
      entityType,
      entityId,
      details,
      timestamp: new Date().toISOString(),
    };
    const updatedLogs = [newLog, ...activityLogs];
    setActivityLogs(updatedLogs);
    Storage.saveActivityLogs(updatedLogs);
  };

  const addNotification = (
    userId: string,
    title: string,
    message: string,
    type: NotificationItem['type'] = 'INFO',
    linkTab?: string
  ) => {
    const newNotif: NotificationItem = {
      id: `noti_${Date.now()}`,
      userId,
      title,
      message,
      type,
      read: false,
      createdAt: new Date().toISOString(),
      linkTab,
    };
    const updatedNotifs = [newNotif, ...notifications];
    setNotifications(updatedNotifs);
    Storage.saveNotifications(updatedNotifs);
  };

  const switchUser = (userId: string) => {
    setCurrentUserId(userId);
    Storage.saveCurrentUserId(userId);
  };

  const toggleTheme = () => {
    const nextTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(nextTheme);
    Storage.saveTheme(nextTheme);
    if (nextTheme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  const resetDemoData = () => {
    Storage.resetToDemo();
    setUsers(Storage.getUsers());
    setOrders(Storage.getOrders());
    setHandoverSheets(Storage.getHandovers());
    setCodDeposits(Storage.getCodDeposits());
    setActivityLogs(Storage.getActivityLogs());
    setNotifications(Storage.getNotifications());
    setCurrentUserId('usr_admin');
  };

  // Account Operations
  const createAccount = (data: Omit<User, 'id' | 'createdAt' | 'isLocked'>) => {
    const newUser: User = {
      ...data,
      id: `usr_${Date.now()}`,
      createdAt: new Date().toISOString(),
      isLocked: false,
    };
    const updatedUsers = [...users, newUser];
    setUsers(updatedUsers);
    Storage.saveUsers(updatedUsers);
    addActivityLog('Tạo tài khoản mới', 'USER', newUser.id, `Tạo tài khoản ${newUser.role}: ${newUser.fullName} (${newUser.username})`);
  };

  const toggleLockAccount = (userId: string) => {
    const updatedUsers = users.map((u) => {
      if (u.id === userId) {
        const nextLock = !u.isLocked;
        addActivityLog(
          nextLock ? 'Khóa tài khoản' : 'Mở khóa tài khoản',
          'USER',
          u.id,
          `${nextLock ? 'Khóa' : 'Mở khóa'} tài khoản ${u.fullName}`
        );
        return { ...u, isLocked: nextLock };
      }
      return u;
    });
    setUsers(updatedUsers);
    Storage.saveUsers(updatedUsers);
  };

  const assignDriverToManager = (driverId: string, managerId: string) => {
    const updatedUsers = users.map((u) => {
      if (u.id === driverId) {
        return { ...u, managerId };
      }
      return u;
    });
    setUsers(updatedUsers);
    Storage.saveUsers(updatedUsers);

    const driver = users.find((u) => u.id === driverId);
    const manager = users.find((u) => u.id === managerId);
    if (driver && manager) {
      addActivityLog('Phân công Xế cho Quản lý', 'USER', driverId, `Phân Xế ${driver.fullName} thuộc quản lý ${manager.fullName}`);
    }
  };

  // Order Operations
  const createOrder = (orderData: Partial<Order>): Order => {
    const managerId = orderData.managerId || currentUser?.id || 'usr_m1';
    const trackingSuffix = String(Math.floor(Math.random() * 899 + 100));
    const codeSuffix = String(Math.floor(Math.random() * 8999 + 1000));

    const newOrder: Order = {
      id: `ord_${Date.now()}_${Math.floor(Math.random() * 100)}`,
      orderCode: orderData.orderCode || `DH-${codeSuffix}`,
      trackingCode: orderData.trackingCode || `VND-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${trackingSuffix}`,
      recipientName: orderData.recipientName || 'Khách hàng',
      recipientPhone: orderData.recipientPhone || '0900000000',
      recipientAddress: orderData.recipientAddress || 'Hà Nội',
      area: orderData.area || 'Nội thành',
      googleMapsUrl: orderData.googleMapsUrl || `https://maps.google.com/?q=${encodeURIComponent(orderData.recipientAddress || 'Hà Nội')}`,
      codAmount: orderData.codAmount || 0,
      shippingFee: orderData.shippingFee || 30000,
      productName: orderData.productName || 'Sản phẩm giao',
      quantity: orderData.quantity || 1,
      notes: orderData.notes || '',
      labelImageUrl: orderData.labelImageUrl || 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=400&auto=format&fit=crop&q=80',
      status: 'CHO_BAN_GIAO',
      managerId,
      isPriority: orderData.isPriority || false,
      createdAt: new Date().toISOString(),
    };

    const updatedOrders = [newOrder, ...orders];
    setOrders(updatedOrders);
    Storage.saveOrders(updatedOrders);
    addActivityLog('Tạo đơn hàng mới', 'ORDER', newOrder.id, `Tạo đơn hàng ${newOrder.orderCode} (${newOrder.recipientName}) - COD: ${newOrder.codAmount}đ`);

    return newOrder;
  };

  const batchCreateOrders = (ordersData: Partial<Order>[]) => {
    const managerId = currentUser?.id || 'usr_m1';
    const newOrdersList: Order[] = ordersData.map((data, idx) => {
      const codeSuffix = String(Math.floor(Math.random() * 8999 + 1000));
      return {
        id: `ord_b_${Date.now()}_${idx}`,
        orderCode: data.orderCode || `DH-${codeSuffix}`,
        trackingCode: data.trackingCode || `VND-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${idx + 100}`,
        recipientName: data.recipientName || 'Khách hàng Excel',
        recipientPhone: data.recipientPhone || '0900000000',
        recipientAddress: data.recipientAddress || 'Địa chỉ giao hàng',
        area: data.area || 'Khu vực',
        googleMapsUrl: `https://maps.google.com/?q=${encodeURIComponent(data.recipientAddress || 'Địa chỉ giao hàng')}`,
        codAmount: Number(data.codAmount) || 0,
        shippingFee: Number(data.shippingFee) || 30000,
        productName: data.productName || 'Hàng hóa Excel',
        quantity: Number(data.quantity) || 1,
        notes: data.notes || '',
        labelImageUrl: 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=400&auto=format&fit=crop&q=80',
        status: 'CHO_BAN_GIAO',
        managerId,
        isPriority: false,
        createdAt: new Date().toISOString(),
      };
    });

    const updatedOrders = [...newOrdersList, ...orders];
    setOrders(updatedOrders);
    Storage.saveOrders(updatedOrders);
    addActivityLog('Nhập file Excel đơn hàng', 'ORDER', 'BATCH', `Nhập thành công ${newOrdersList.length} đơn hàng từ Excel`);
  };

  const updateOrder = (orderId: string, data: Partial<Order>) => {
    const updatedOrders = orders.map((o) => {
      if (o.id === orderId) {
        return { ...o, ...data };
      }
      return o;
    });
    setOrders(updatedOrders);
    Storage.saveOrders(updatedOrders);
    addActivityLog('Cập nhật đơn hàng', 'ORDER', orderId, `Cập nhật thông tin đơn hàng ${orderId}`);
  };

  const deleteOrder = (orderId: string): boolean => {
    const target = orders.find((o) => o.id === orderId);
    if (!target) return false;
    if (target.status !== 'CHO_BAN_GIAO') {
      alert('Không thể xóa đơn hàng đã bàn giao!');
      return false;
    }
    const updated = orders.filter((o) => o.id !== orderId);
    setOrders(updated);
    Storage.saveOrders(updated);
    addActivityLog('Xóa đơn hàng', 'ORDER', orderId, `Xóa đơn hàng chưa bàn giao ${target.orderCode}`);
    return true;
  };

  // Handover Operations
  const createHandoverSheet = (driverId: string, orderIds: string[]): HandoverSheet | null => {
    if (!currentUser) return null;
    const driver = users.find((u) => u.id === driverId);
    if (!driver) return null;

    const selectedOrders = orders.filter((o) => orderIds.includes(o.id));
    if (selectedOrders.length === 0) return null;

    const totalCodAmount = selectedOrders.reduce((sum, o) => sum + (o.codAmount || 0) + (o.shippingFee || 0), 0);
    const sheetCode = `PBG-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${String(handoverSheets.length + 1).padStart(2, '0')}`;

    const newSheet: HandoverSheet = {
      id: `pbg_${Date.now()}`,
      sheetCode,
      managerId: currentUser.id,
      managerName: currentUser.fullName,
      driverId: driver.id,
      driverName: driver.fullName,
      orderIds,
      totalOrders: selectedOrders.length,
      totalCodAmount,
      status: 'CHO_XE_XAC_NHAN',
      createdAt: new Date().toISOString(),
    };

    // Update order status to DA_BAN_GIAO
    const updatedOrders = orders.map((o) => {
      if (orderIds.includes(o.id)) {
        return {
          ...o,
          status: 'DA_BAN_GIAO' as OrderStatus,
          driverId: driver.id,
          handoverSheetId: newSheet.id,
          handoverAt: new Date().toISOString(),
        };
      }
      return o;
    });

    const updatedSheets = [newSheet, ...handoverSheets];
    setHandoverSheets(updatedSheets);
    setOrders(updatedOrders);
    Storage.saveHandovers(updatedSheets);
    Storage.saveOrders(updatedOrders);

    addActivityLog('Tạo phiếu bàn giao', 'HANDOVER', newSheet.id, `Bàn giao ${selectedOrders.length} đơn cho Xế ${driver.fullName} (Mã PBG: ${sheetCode})`);
    
    // Notify Driver
    addNotification(
      driver.id,
      'Đơn hàng mới được bàn giao',
      `Quản lý ${currentUser.fullName} vừa bàn giao ${selectedOrders.length} đơn hàng (${sheetCode}). Tổng COD: ${totalCodAmount.toLocaleString('vi-VN')}đ. Vui lòng xác nhận!`,
      'ALERT',
      'handovers'
    );

    return newSheet;
  };

  const acceptHandoverSheet = (sheetId: string) => {
    const sheet = handoverSheets.find((s) => s.id === sheetId);
    if (!sheet) return;

    const acceptanceDevice = navigator.userAgent.includes('Android')
      ? 'Mobile Device (Android)'
      : navigator.userAgent.includes('iPhone')
      ? 'Mobile Device (iOS)'
      : 'Desktop Browser Web';
    const acceptanceLocation = 'Vị trí xác nhận GPS kho giao hàng (21.0285, 105.8542)';

    const updatedSheets = handoverSheets.map((s) => {
      if (s.id === sheetId) {
        return {
          ...s,
          status: 'DANG_GIAO_HANG' as HandoverSheet['status'],
          acceptedAt: new Date().toISOString(),
          acceptanceDevice,
          acceptanceLocation,
        };
      }
      return s;
    });

    // Update all orders in sheet to XE_DA_NHAN
    const updatedOrders = orders.map((o) => {
      if (sheet.orderIds.includes(o.id)) {
        return {
          ...o,
          status: 'XE_DA_NHAN' as OrderStatus,
          acceptedAt: new Date().toISOString(),
        };
      }
      return o;
    });

    setHandoverSheets(updatedSheets);
    setOrders(updatedOrders);
    Storage.saveHandovers(updatedSheets);
    Storage.saveOrders(updatedOrders);

    addActivityLog('Xác nhận nhận đơn', 'HANDOVER', sheetId, `Xế ${sheet.driverName} đã xác nhận tiếp nhận phiếu ${sheet.sheetCode}`);
    
    // Notify Manager
    addNotification(
      sheet.managerId,
      'Xế đã xác nhận nhận đơn',
      `Xế ${sheet.driverName} đã xác nhận nhận ${sheet.totalOrders} đơn thuộc phiếu bàn giao ${sheet.sheetCode}.`,
      'SUCCESS',
      'handovers'
    );
  };

  const rejectHandoverSheet = (sheetId: string, reason: string) => {
    const sheet = handoverSheets.find((s) => s.id === sheetId);
    if (!sheet) return;

    const updatedSheets = handoverSheets.map((s) => {
      if (s.id === sheetId) {
        return {
          ...s,
          status: 'CO_SAI_LECH' as HandoverSheet['status'],
          hasDiscrepancy: true,
          discrepancyNote: `Xế từ chối: ${reason}`,
        };
      }
      return s;
    });

    // Reset orders back to CHO_BAN_GIAO
    const updatedOrders = orders.map((o) => {
      if (sheet.orderIds.includes(o.id)) {
        return {
          ...o,
          status: 'CHO_BAN_GIAO' as OrderStatus,
          driverId: undefined,
          handoverSheetId: undefined,
        };
      }
      return o;
    });

    setHandoverSheets(updatedSheets);
    setOrders(updatedOrders);
    Storage.saveHandovers(updatedSheets);
    Storage.saveOrders(updatedOrders);

    addActivityLog('Từ chối bàn giao', 'HANDOVER', sheetId, `Xế ${sheet.driverName} phản hồi sai lệch phiếu ${sheet.sheetCode}: ${reason}`);

    addNotification(
      sheet.managerId,
      'Cảnh báo: Xế từ chối phiếu bàn giao',
      `Xế ${sheet.driverName} từ chối phiếu ${sheet.sheetCode} với lý do: "${reason}". Vui lòng kiểm tra lại!`,
      'WARNING',
      'handovers'
    );
  };

  // Inter-Manager Batch Transfer Workflow (Manager -> Manager)
  const createTransferBatch = (
    receiverManagerId: string,
    orderIds: string[],
    areaName: string,
    note?: string
  ): ManagerTransferBatch | null => {
    if (!currentUser || currentUser.role !== 'MANAGER') return null;
    const receiver = users.find((u) => u.id === receiverManagerId);
    if (!receiver) return null;

    const selectedOrders = orders.filter((o) => orderIds.includes(o.id));
    if (selectedOrders.length === 0) return null;

    const totalCodAmount = selectedOrders.reduce((sum, o) => sum + (o.codAmount || 0) + (o.shippingFee || 0), 0);
    const dateStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const codeSlug = areaName ? areaName.toUpperCase().replace(/\s+/g, '') : 'KHAC';
    const batchCode = `LO-${codeSlug}-${dateStr}-${String(transferBatches.length + 1).padStart(2, '0')}`;

    const newBatch: ManagerTransferBatch = {
      id: `batch_${Date.now()}`,
      batchCode,
      senderManagerId: currentUser.id,
      senderManagerName: currentUser.fullName,
      receiverManagerId,
      receiverManagerName: receiver.fullName,
      areaName: areaName || 'Chuyển Kho',
      orderIds,
      scannedOrderIds: [],
      totalOrders: selectedOrders.length,
      totalCodAmount,
      status: 'CHO_TIEP_NHAN',
      note,
      createdAt: new Date().toISOString(),
    };

    const updatedBatches = [newBatch, ...transferBatches];
    setTransferBatches(updatedBatches);
    Storage.saveTransferBatches(updatedBatches);

    addActivityLog('Lập phiếu chuyển lô kho', 'HANDOVER', newBatch.id, `Chuyển lô ${batchCode} (${selectedOrders.length} đơn, khu vực ${areaName}) tới Quản lý ${receiver.fullName}`);

    addNotification(
      receiverManagerId,
      'Có lô đơn hàng chuyển giao mới',
      `Quản lý ${currentUser.fullName} đã gửi lô đơn hàng ${batchCode} (${selectedOrders.length} đơn, tổng COD ${totalCodAmount.toLocaleString('vi-VN')}đ) cho khu vực ${areaName}. Vui lòng kiểm đếm!`,
      'ALERT',
      'handovers'
    );

    return newBatch;
  };

  const scanOrderInBatch = (batchId: string, trackingOrOrderCode: string): { success: boolean; message: string } => {
    const batch = transferBatches.find((b) => b.id === batchId);
    if (!batch) return { success: false, message: 'Không tìm thấy lô hàng này' };

    const raw = trackingOrOrderCode.trim().toUpperCase().replace(/[\r\n\t]/g, '');
    const rawAlpha = raw.replace(/[^A-Z0-9]/g, '');

    const targetOrder = orders.find((o) => {
      if (!batch.orderIds.includes(o.id)) return false;
      const tCode = o.trackingCode.toUpperCase();
      const oCode = o.orderCode.toUpperCase();
      const tAlpha = tCode.replace(/[^A-Z0-9]/g, '');
      const oAlpha = oCode.replace(/[^A-Z0-9]/g, '');

      return (
        raw === tCode ||
        raw === oCode ||
        (rawAlpha.length > 0 && (rawAlpha === tAlpha || rawAlpha === oAlpha)) ||
        raw.includes(tCode) ||
        raw.includes(oCode) ||
        tCode.includes(raw) ||
        oCode.includes(raw)
      );
    });

    if (!targetOrder) {
      return { success: false, message: `Không tìm thấy đơn có mã "${trackingOrOrderCode}" trong lô hàng!` };
    }

    if (batch.scannedOrderIds.includes(targetOrder.id)) {
      return { success: false, message: `Đơn hàng ${targetOrder.orderCode} đã được quét kiểm đếm trước đó!` };
    }

    const updatedScanned = [...batch.scannedOrderIds, targetOrder.id];
    const updatedBatches = transferBatches.map((b) => {
      if (b.id === batchId) {
        return {
          ...b,
          scannedOrderIds: updatedScanned,
        };
      }
      return b;
    });

    setTransferBatches(updatedBatches);
    Storage.saveTransferBatches(updatedBatches);

    return { success: true, message: `Đã quét đối soát mã đơn ${targetOrder.orderCode} (${targetOrder.recipientName})` };
  };

  const acceptTransferBatch = (batchId: string) => {
    const batch = transferBatches.find((b) => b.id === batchId);
    if (!batch) return;

    const updatedBatches = transferBatches.map((b) => {
      if (b.id === batchId) {
        return {
          ...b,
          status: 'DA_TIEP_NHAN' as ManagerTransferBatch['status'],
          acceptedAt: new Date().toISOString(),
        };
      }
      return b;
    });

    // Reassign orders in batch to receiverManager & reset status to CHO_BAN_GIAO
    const updatedOrders = orders.map((o) => {
      if (batch.orderIds.includes(o.id)) {
        return {
          ...o,
          managerId: batch.receiverManagerId,
          status: 'CHO_BAN_GIAO' as OrderStatus,
        };
      }
      return o;
    });

    setTransferBatches(updatedBatches);
    setOrders(updatedOrders);
    Storage.saveTransferBatches(updatedBatches);
    Storage.saveOrders(updatedOrders);

    addActivityLog('Tiếp nhận lô chuyển kho', 'HANDOVER', batchId, `Quản lý ${batch.receiverManagerName} đã tiếp nhận lô ${batch.batchCode} (${batch.totalOrders} đơn)`);

    addNotification(
      batch.senderManagerId,
      'Lô hàng chuyển giao đã được tiếp nhận',
      `Quản lý ${batch.receiverManagerName} đã tiếp nhận lô hàng ${batch.batchCode}.`,
      'SUCCESS',
      'handovers'
    );
  };

  const settleBatchCod = (batchId: string, settledAmount: number) => {
    const batch = transferBatches.find((b) => b.id === batchId);
    if (!batch) return;

    const updatedBatches = transferBatches.map((b) => {
      if (b.id === batchId) {
        return {
          ...b,
          status: 'DA_THANH_TOAN_COD' as ManagerTransferBatch['status'],
          settledAt: new Date().toISOString(),
          settledCodAmount: settledAmount,
        };
      }
      return b;
    });

    setTransferBatches(updatedBatches);
    Storage.saveTransferBatches(updatedBatches);

    addActivityLog('Thanh toán COD theo lô', 'COD', batchId, `Hoàn tất thanh toán COD theo lô ${batch.batchCode} số tiền ${settledAmount.toLocaleString('vi-VN')}đ`);

    addNotification(
      batch.senderManagerId,
      'Thanh toán COD lô hàng hoàn tất',
      `Đã nhận thanh toán COD theo lô ${batch.batchCode} số tiền ${settledAmount.toLocaleString('vi-VN')}đ từ Quản lý ${batch.receiverManagerName}.`,
      'SUCCESS',
      'reconcile'
    );
  };

  const updateOrderStatus = (
    orderId: string,
    status: OrderStatus,
    extraData?: {
      proofImageUrl?: string;
      failureReason?: string;
      collectedCodAmount?: number;
      location?: { lat: number; lng: number; addressName?: string };
    }
  ) => {
    const targetOrder = orders.find((o) => o.id === orderId);
    if (!targetOrder) return;

    const updatedOrders = orders.map((o) => {
      if (o.id === orderId) {
        return {
          ...o,
          status,
          ...(extraData?.proofImageUrl ? { proofImageUrl: extraData.proofImageUrl } : {}),
          ...(extraData?.failureReason ? { failureReason: extraData.failureReason } : {}),
          ...(extraData?.collectedCodAmount !== undefined ? { collectedCodAmount: extraData.collectedCodAmount } : { collectedCodAmount: o.codAmount }),
          ...(extraData?.location ? { deliveryLocation: extraData.location } : {}),
          ...(status === 'GIAO_THANH_CONG' ? { deliveredAt: new Date().toISOString() } : {}),
        };
      }
      return o;
    });

    setOrders(updatedOrders);
    Storage.saveOrders(updatedOrders);

    addActivityLog('Đổi trạng thái đơn hàng', 'ORDER', orderId, `Đơn hàng ${targetOrder.orderCode} đổi trạng thái sang "${status}"`);

    // Check if all orders in sheet completed
    if (targetOrder.handoverSheetId) {
      const sheetOrders = updatedOrders.filter((o) => o.handoverSheetId === targetOrder.handoverSheetId);
      const allDone = sheetOrders.every((o) => ['GIAO_THANH_CONG', 'GIAO_THAT_BAI', 'KHANG_HEN_GIAO_LAI', 'DON_HOAN'].includes(o.status));
      if (allDone) {
        const updatedSheets = handoverSheets.map((s) => {
          if (s.id === targetOrder.handoverSheetId) {
            return { ...s, status: 'CHO_DOI_SOAT' as HandoverSheet['status'] };
          }
          return s;
        });
        setHandoverSheets(updatedSheets);
        Storage.saveHandovers(updatedSheets);
      }
    }
  };

  // COD Operations
  const submitCodDeposit = (amount: number, proofImageUrl?: string, note?: string) => {
    if (!currentUser || currentUser.role !== 'DRIVER') return;
    const managerId = currentUser.managerId || 'usr_m1';
    const manager = users.find((u) => u.id === managerId);

    const depositCode = `NC-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${String(codDeposits.length + 1).padStart(3, '0')}`;

    const newDeposit: CODDeposit = {
      id: `cod_${Date.now()}`,
      depositCode,
      driverId: currentUser.id,
      driverName: currentUser.fullName,
      managerId,
      managerName: manager?.fullName || 'Quản lý',
      amount,
      proofImageUrl,
      note,
      status: 'CHO_XAC_NHAN',
      createdAt: new Date().toISOString(),
    };

    const updatedDeposits = [newDeposit, ...codDeposits];
    setCodDeposits(updatedDeposits);
    Storage.saveCodDeposits(updatedDeposits);

    addActivityLog('Nộp tiền COD', 'COD', newDeposit.id, `Xế ${currentUser.fullName} nộp ${amount.toLocaleString('vi-VN')}đ tiền COD`);

    addNotification(
      managerId,
      'Yêu cầu xác nhận nộp tiền COD',
      `Xế ${currentUser.fullName} đã gửi yêu cầu nộp ${amount.toLocaleString('vi-VN')}đ COD (${depositCode}). Vui lòng xác nhận!`,
      'INFO',
      'reconcile'
    );
  };

  const confirmCodDeposit = (depositId: string) => {
    const deposit = codDeposits.find((d) => d.id === depositId);
    if (!deposit) return;

    const updatedDeposits = codDeposits.map((d) => {
      if (d.id === depositId) {
        return {
          ...d,
          status: 'DA_XAC_NHAN' as CODDepositStatus,
          confirmedAt: new Date().toISOString(),
        };
      }
      return d;
    });

    setCodDeposits(updatedDeposits);
    Storage.saveCodDeposits(updatedDeposits);

    addActivityLog('Xác nhận thu tiền COD', 'COD', depositId, `Quản lý đã xác nhận nhận ${deposit.amount.toLocaleString('vi-VN')}đ COD từ Xế ${deposit.driverName}`);

    addNotification(
      deposit.driverId,
      'Quản lý đã xác nhận nộp COD',
      `Quản lý đã xác nhận khoản nộp COD ${deposit.amount.toLocaleString('vi-VN')}đ (${deposit.depositCode}) của bạn.`,
      'SUCCESS',
      'cod'
    );
  };

  const reconcileHandoverSheet = (sheetId: string) => {
    const sheet = handoverSheets.find((s) => s.id === sheetId);
    if (!sheet) return;

    const updatedSheets = handoverSheets.map((s) => {
      if (s.id === sheetId) {
        return {
          ...s,
          status: 'DA_DOI_SOAT' as HandoverSheet['status'],
          reconciledAt: new Date().toISOString(),
        };
      }
      return s;
    });

    const updatedOrders = orders.map((o) => {
      if (sheet.orderIds.includes(o.id)) {
        return {
          ...o,
          status: 'DA_DOI_SOAT' as OrderStatus,
        };
      }
      return o;
    });

    setHandoverSheets(updatedSheets);
    setOrders(updatedOrders);
    Storage.saveHandovers(updatedSheets);
    Storage.saveOrders(updatedOrders);

    addActivityLog('Xác nhận đối soát phiếu bàn giao', 'HANDOVER', sheetId, `Hoàn tất đối soát phiếu ${sheet.sheetCode}`);
  };

  const markNotificationRead = (id: string) => {
    const updatedNotifs = notifications.map((n) => (n.id === id ? { ...n, read: true } : n));
    setNotifications(updatedNotifs);
    Storage.saveNotifications(updatedNotifs);
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        users,
        orders,
        handoverSheets,
        codDeposits,
        transferBatches,
        activityLogs,
        notifications,
        theme,
        switchUser,
        createAccount,
        toggleLockAccount,
        assignDriverToManager,
        createOrder,
        batchCreateOrders,
        updateOrder,
        deleteOrder,
        createHandoverSheet,
        acceptHandoverSheet,
        rejectHandoverSheet,
        createTransferBatch,
        scanOrderInBatch,
        acceptTransferBatch,
        settleBatchCod,
        updateOrderStatus,
        submitCodDeposit,
        confirmCodDeposit,
        reconcileHandoverSheet,
        toggleTheme,
        resetDemoData,
        markNotificationRead,
        addActivityLog,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
