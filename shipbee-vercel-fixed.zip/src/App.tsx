import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/common/Header';
import { TechDocsModal } from './components/common/TechDocsModal';
import { ScannerModal } from './components/common/ScannerModal';

// Admin Components
import { AdminDashboard } from './components/admin/AdminDashboard';
import { AccountManagement } from './components/admin/AccountManagement';
import { AllOrdersView } from './components/admin/AllOrdersView';
import { CODReportView } from './components/admin/CODReportView';
import { SystemLogsView } from './components/admin/SystemLogsView';

// Manager Components
import { ManagerDashboard } from './components/manager/ManagerDashboard';
import { OrderManagement } from './components/manager/OrderManagement';
import { HandoverManagement } from './components/manager/HandoverManagement';
import { DriverReconciliation } from './components/manager/DriverReconciliation';
import { ManagerDriverManagement } from './components/manager/ManagerDriverManagement';
import { InterManagerTransfer } from './components/manager/InterManagerTransfer';

// Driver Components
import { DriverHome } from './components/driver/DriverHome';
import { DriverOrders } from './components/driver/DriverOrders';
import { DriverHandovers } from './components/driver/DriverHandovers';
import { DriverCOD } from './components/driver/DriverCOD';
import { DriverAccount } from './components/driver/DriverAccount';

// Driver Bottom Nav Icons
import { LayoutDashboard, Users, Package, DollarSign, Clock, Truck, FileCheck, Home, User, ArrowRightLeft } from 'lucide-react';

const MainAppContent: React.FC = () => {
  const { currentUser } = useApp();

  const [activeTab, setActiveTab] = useState('dashboard');
  const [selectedOrderIdsForHandover, setSelectedOrderIdsForHandover] = useState<string[]>([]);
  const [isTechDocsOpen, setIsTechDocsOpen] = useState(false);
  const [isScannerOpen, setIsScannerOpen] = useState(false);

  if (!currentUser) return null;

  const role = currentUser.role;

  // Handle Tab Switching from Manager Dashboard buttons
  const handleManagerNavigateTab = (tabKey: string) => {
    setActiveTab(tabKey);
  };

  const handleGoToHandoverWithOrders = (orderIds: string[]) => {
    setSelectedOrderIdsForHandover(orderIds);
    setActiveTab('handover');
  };

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-sans flex flex-col antialiased">
      {/* Top Header Navigation */}
      <Header
        onOpenTechDocs={() => setIsTechDocsOpen(true)}
        onOpenScanner={() => setIsScannerOpen(true)}
      />

      {/* Main Container */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 py-6 pb-24 md:pb-8">
        {/* ================= ADMIN VIEW ================= */}
        {role === 'ADMIN' && (
          <div className="space-y-6">
            {/* Admin Desktop Tabs */}
            <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-[#E5E7EB] dark:border-slate-800">
              <button
                onClick={() => setActiveTab('dashboard')}
                className={`px-4 py-2.5 rounded-lg font-bold text-xs flex items-center gap-2 transition-all shrink-0 ${
                  activeTab === 'dashboard'
                    ? 'bg-[#FF6321] text-white shadow-sm'
                    : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 hover:bg-orange-50/60 border border-[#E5E7EB] dark:border-slate-800'
                }`}
              >
                <LayoutDashboard className="w-4 h-4" /> Báo Cáo Tổng Quan
              </button>
              <button
                onClick={() => setActiveTab('accounts')}
                className={`px-4 py-2.5 rounded-lg font-bold text-xs flex items-center gap-2 transition-all shrink-0 ${
                  activeTab === 'accounts'
                    ? 'bg-[#FF6321] text-white shadow-sm'
                    : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 hover:bg-orange-50/60 border border-[#E5E7EB] dark:border-slate-800'
                }`}
              >
                <Users className="w-4 h-4" /> Quản Lý Tài Khoản (3 Cấp)
              </button>
              <button
                onClick={() => setActiveTab('all_orders')}
                className={`px-4 py-2.5 rounded-lg font-bold text-xs flex items-center gap-2 transition-all shrink-0 ${
                  activeTab === 'all_orders'
                    ? 'bg-[#FF6321] text-white shadow-sm'
                    : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 hover:bg-orange-50/60 border border-[#E5E7EB] dark:border-slate-800'
                }`}
              >
                <Package className="w-4 h-4" /> Toàn Bộ Đơn Hàng
              </button>
              <button
                onClick={() => setActiveTab('cod_report')}
                className={`px-4 py-2.5 rounded-lg font-bold text-xs flex items-center gap-2 transition-all shrink-0 ${
                  activeTab === 'cod_report'
                    ? 'bg-[#FF6321] text-white shadow-sm'
                    : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 hover:bg-orange-50/60 border border-[#E5E7EB] dark:border-slate-800'
                }`}
              >
                <DollarSign className="w-4 h-4" /> Đối Soát COD Hệ Thống
              </button>
              <button
                onClick={() => setActiveTab('logs')}
                className={`px-4 py-2.5 rounded-lg font-bold text-xs flex items-center gap-2 transition-all shrink-0 ${
                  activeTab === 'logs'
                    ? 'bg-[#FF6321] text-white shadow-sm'
                    : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 hover:bg-orange-50/60 border border-[#E5E7EB] dark:border-slate-800'
                }`}
              >
                <Clock className="w-4 h-4" /> Nhật Ký Audit Log
              </button>
            </div>

            {/* Admin Tab Contents */}
            {activeTab === 'dashboard' && <AdminDashboard onNavigateTab={(tab) => setActiveTab(tab)} />}
            {activeTab === 'accounts' && <AccountManagement />}
            {activeTab === 'all_orders' && <AllOrdersView />}
            {activeTab === 'cod_report' && <CODReportView />}
            {activeTab === 'logs' && <SystemLogsView />}
          </div>
        )}

        {/* ================= MANAGER VIEW ================= */}
        {role === 'MANAGER' && (
          <div className="space-y-6">
            {/* Manager Desktop Tabs */}
            <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-[#E5E7EB] dark:border-slate-800">
              <button
                onClick={() => setActiveTab('dashboard')}
                className={`px-4 py-2.5 rounded-lg font-bold text-xs flex items-center gap-2 transition-all shrink-0 ${
                  activeTab === 'dashboard'
                    ? 'bg-[#FF6321] text-white shadow-sm'
                    : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 hover:bg-orange-50/60 border border-[#E5E7EB] dark:border-slate-800'
                }`}
              >
                <LayoutDashboard className="w-4 h-4" /> Tổng Quan Kho
              </button>
              <button
                onClick={() => setActiveTab('create_order')}
                className={`px-4 py-2.5 rounded-lg font-bold text-xs flex items-center gap-2 transition-all shrink-0 ${
                  activeTab === 'create_order'
                    ? 'bg-[#FF6321] text-white shadow-sm'
                    : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 hover:bg-orange-50/60 border border-[#E5E7EB] dark:border-slate-800'
                }`}
              >
                <Package className="w-4 h-4" /> Quản Lý & Nhập Đơn
              </button>
              <button
                onClick={() => setActiveTab('handover')}
                className={`px-4 py-2.5 rounded-lg font-bold text-xs flex items-center gap-2 transition-all shrink-0 ${
                  activeTab === 'handover'
                    ? 'bg-[#FF6321] text-white shadow-sm'
                    : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 hover:bg-orange-50/60 border border-[#E5E7EB] dark:border-slate-800'
                }`}
              >
                <Truck className="w-4 h-4" /> Bàn Giao Đơn Cho Xế
              </button>
              <button
                onClick={() => setActiveTab('inter_transfer')}
                className={`px-4 py-2.5 rounded-lg font-bold text-xs flex items-center gap-2 transition-all shrink-0 ${
                  activeTab === 'inter_transfer'
                    ? 'bg-[#FF6321] text-white shadow-sm'
                    : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 hover:bg-orange-50/60 border border-[#E5E7EB] dark:border-slate-800'
                }`}
              >
                <ArrowRightLeft className="w-4 h-4" /> Chuyển Lô Liên Kho
              </button>
              <button
                onClick={() => setActiveTab('my_drivers')}
                className={`px-4 py-2.5 rounded-lg font-bold text-xs flex items-center gap-2 transition-all shrink-0 ${
                  activeTab === 'my_drivers'
                    ? 'bg-[#FF6321] text-white shadow-sm'
                    : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 hover:bg-orange-50/60 border border-[#E5E7EB] dark:border-slate-800'
                }`}
              >
                <Users className="w-4 h-4" /> Quản Lý Đội Xế
              </button>
              <button
                onClick={() => setActiveTab('reconcile')}
                className={`px-4 py-2.5 rounded-lg font-bold text-xs flex items-center gap-2 transition-all shrink-0 ${
                  activeTab === 'reconcile'
                    ? 'bg-[#FF6321] text-white shadow-sm'
                    : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 hover:bg-orange-50/60 border border-[#E5E7EB] dark:border-slate-800'
                }`}
              >
                <FileCheck className="w-4 h-4" /> Thu Tiền COD & Đối Soát
              </button>
            </div>

            {/* Manager Tab Contents */}
            {activeTab === 'dashboard' && <ManagerDashboard onNavigateTab={handleManagerNavigateTab} />}
            {activeTab === 'create_order' && <OrderManagement onGoToHandoverWithOrders={handleGoToHandoverWithOrders} />}
            {activeTab === 'handover' && <HandoverManagement initialSelectedOrderIds={selectedOrderIdsForHandover} />}
            {activeTab === 'inter_transfer' && <InterManagerTransfer />}
            {activeTab === 'my_drivers' && <ManagerDriverManagement />}
            {activeTab === 'reconcile' && <DriverReconciliation />}
          </div>
        )}

        {/* ================= DRIVER VIEW (MOBILE-FIRST) ================= */}
        {role === 'DRIVER' && (
          <div className="max-w-md mx-auto">
            {activeTab === 'dashboard' || activeTab === 'home' ? (
              <DriverHome onNavigateTab={(t) => setActiveTab(t)} />
            ) : null}
            {activeTab === 'orders' && <DriverOrders />}
            {activeTab === 'handovers' && <DriverHandovers />}
            {activeTab === 'cod' && <DriverCOD />}
            {activeTab === 'profile' && <DriverAccount />}
          </div>
        )}
      </main>

      {/* Driver Mobile Fixed Bottom Navigation Bar */}
      {role === 'DRIVER' && (
        <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-[#E5E7EB] dark:border-slate-800 px-2 py-2">
          <div className="max-w-md mx-auto grid grid-cols-5 text-center">
            <button
              onClick={() => setActiveTab('home')}
              className={`flex flex-col items-center justify-center py-1 transition-colors ${
                activeTab === 'home' || activeTab === 'dashboard'
                  ? 'text-[#FF6321] font-extrabold'
                  : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              <Home className="w-5 h-5 mb-0.5" />
              <span className="text-[10px]">Trang chủ</span>
            </button>

            <button
              onClick={() => setActiveTab('orders')}
              className={`flex flex-col items-center justify-center py-1 transition-colors ${
                activeTab === 'orders'
                  ? 'text-[#FF6321] font-extrabold'
                  : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              <Package className="w-5 h-5 mb-0.5" />
              <span className="text-[10px]">Đơn hàng</span>
            </button>

            <button
              onClick={() => setActiveTab('handovers')}
              className={`flex flex-col items-center justify-center py-1 transition-colors ${
                activeTab === 'handovers'
                  ? 'text-[#FF6321] font-extrabold'
                  : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              <Truck className="w-5 h-5 mb-0.5" />
              <span className="text-[10px]">Bàn giao</span>
            </button>

            <button
              onClick={() => setActiveTab('cod')}
              className={`flex flex-col items-center justify-center py-1 transition-colors ${
                activeTab === 'cod'
                  ? 'text-[#FF6321] font-extrabold'
                  : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              <DollarSign className="w-5 h-5 mb-0.5" />
              <span className="text-[10px]">Nộp COD</span>
            </button>

            <button
              onClick={() => setActiveTab('profile')}
              className={`flex flex-col items-center justify-center py-1 transition-colors ${
                activeTab === 'profile'
                  ? 'text-[#FF6321] font-extrabold'
                  : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              <User className="w-5 h-5 mb-0.5" />
              <span className="text-[10px]">Tài khoản</span>
            </button>
          </div>
        </nav>
      )}

      {/* Tech Architecture Docs Modal */}
      <TechDocsModal isOpen={isTechDocsOpen} onClose={() => setIsTechDocsOpen(false)} />

      {/* Global Scanner Modal for Mobile / USB Gun */}
      <ScannerModal isOpen={isScannerOpen} onClose={() => setIsScannerOpen(false)} />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainAppContent />
    </AppProvider>
  );
}
