import React from 'react';
import { Truck, CheckCircle2, AlertTriangle, DollarSign, Clock, MapPin, Phone, ArrowRight, ShieldCheck } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { formatVND } from '../../utils/helpers';

interface DriverHomeProps {
  onNavigateTab: (tabKey: string) => void;
}

export const DriverHome: React.FC<DriverHomeProps> = ({ onNavigateTab }) => {
  const { currentUser, orders, handoverSheets, codDeposits } = useApp();

  if (!currentUser) return null;

  // Driver's orders
  const myOrders = orders.filter((o) => o.driverId === currentUser.id);
  const pendingOrders = myOrders.filter((o) => o.status === 'XE_DA_NHAN' || o.status === 'DANG_DI_GIAO' || o.status === 'DA_LIEN_HE_KHACH');
  const deliveredOrders = myOrders.filter((o) => o.status === 'GIAO_THANH_CONG' || o.status === 'DA_NOP_COD' || o.status === 'DA_DOI_SOAT');
  const failedOrders = myOrders.filter((o) => ['GIAO_THAT_BAI', 'KHANG_HEN_GIAO_LAI', 'KHANG_KHONG_NGHE', 'SAI_DIA_CHI', 'KHANG_TU_CHOI', 'DON_HOAN'].includes(o.status));

  // COD metrics
  const totalCodToCollect = myOrders.reduce((sum, o) => sum + (o.codAmount || 0), 0);
  const totalCodCollected = deliveredOrders.reduce((sum, o) => sum + (o.collectedCodAmount || o.codAmount || 0), 0);

  const confirmedDeposits = codDeposits
    .filter((d) => d.driverId === currentUser.id && d.status === 'DA_XAC_NHAN')
    .reduce((sum, d) => sum + d.amount, 0);

  const codToDeposit = totalCodCollected - confirmedDeposits;

  // Pending handover sheet to accept
  const pendingHandovers = handoverSheets.filter((s) => s.driverId === currentUser.id && s.status === 'CHO_XE_XAC_NHAN');

  return (
    <div className="space-y-5 animate-fade-in pb-12">
      {/* Mobile Driver Welcome Card */}
      <div className="p-5 bg-[#1F2937] rounded-xl text-white shadow-lg border border-slate-700 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src={currentUser.avatarUrl} alt="" className="w-11 h-11 rounded-full object-cover border-2 border-[#FF6321] shadow-xs" />
            <div>
              <p className="text-[10px] uppercase tracking-wider font-extrabold text-[#FF6321]">Xế Giao Hàng</p>
              <h2 className="text-lg font-black tracking-tight text-white">{currentUser.fullName}</h2>
            </div>
          </div>
          <span className="px-2.5 py-1 bg-[#FFF5F1]/10 text-[#FF6321] border border-[#FF6321]/30 rounded text-[10px] font-bold">
            SĐT: {currentUser.phone}
          </span>
        </div>

        {/* Start Delivering Action Button */}
        <button
          onClick={() => onNavigateTab('orders')}
          className="w-full py-3 bg-[#FF6321] hover:bg-[#e05318] text-white font-black text-sm rounded-lg shadow-sm transition-all flex items-center justify-center gap-2 active:scale-98"
        >
          <Truck className="w-5 h-5 text-white" /> BẮT ĐẦU GIAO HÀNG ({pendingOrders.length} ĐƠN)
        </button>
      </div>

      {/* Pending Handover Sheet Notification Banner */}
      {pendingHandovers.length > 0 && (
        <div className="p-4 bg-orange-50 dark:bg-rose-950/50 border-2 border-[#FF6321] rounded-xl flex items-center justify-between text-xs text-slate-800 dark:text-rose-200">
          <div className="flex items-center gap-3">
            <Clock className="w-6 h-6 text-[#FF6321] shrink-0" />
            <div>
              <p className="font-bold text-sm text-[#FF6321]">Có {pendingHandovers.length} phiếu bàn giao mới!</p>
              <p className="text-slate-600 dark:text-rose-300 text-[11px]">
                Quản lý đã tạo phiếu bàn giao đơn hàng. Vui lòng kiểm tra và bấm "Xác nhận".
              </p>
            </div>
          </div>
          <button
            onClick={() => onNavigateTab('handovers')}
            className="px-3 py-2 bg-[#FF6321] text-white font-bold rounded-md hover:bg-[#e05318] transition-colors shrink-0 flex items-center gap-1 shadow-xs text-xs"
          >
            Nhận ngay <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Today Orders Summary Grid */}
      <div>
        <h3 className="text-[10px] font-bold text-[#9CA3AF] uppercase tracking-wider mb-2 px-1">
          Trạng thái đơn hôm nay
        </h3>
        <div className="grid grid-cols-2 gap-3">
          <div
            onClick={() => onNavigateTab('orders')}
            className="p-4 bg-white dark:bg-slate-900 rounded-xl border border-[#E5E7EB] dark:border-slate-800 shadow-sm space-y-1 cursor-pointer hover:border-[#FF6321] transition-all"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs text-[#9CA3AF] font-medium">Chờ đi giao</span>
              <Truck className="w-4 h-4 text-[#FF6321]" />
            </div>
            <p className="text-2xl font-black text-[#1F2937] dark:text-white">{pendingOrders.length} <span className="text-xs font-normal text-[#9CA3AF]">đơn</span></p>
          </div>

          <div
            onClick={() => onNavigateTab('orders')}
            className="p-4 bg-white dark:bg-slate-900 rounded-xl border border-[#E5E7EB] dark:border-slate-800 shadow-sm space-y-1 cursor-pointer hover:border-emerald-500 transition-all"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs text-[#9CA3AF] font-medium">Đã giao xong</span>
              <CheckCircle2 className="w-4 h-4 text-emerald-500" />
            </div>
            <p className="text-2xl font-black text-emerald-600 dark:text-emerald-400">{deliveredOrders.length} <span className="text-xs font-normal text-[#9CA3AF]">đơn</span></p>
          </div>

          <div
            onClick={() => onNavigateTab('orders')}
            className="p-4 bg-white dark:bg-slate-900 rounded-xl border border-[#E5E7EB] dark:border-slate-800 shadow-sm space-y-1 cursor-pointer hover:border-rose-400 transition-all"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs text-[#9CA3AF] font-medium">Thất bại / Hẹn lại</span>
              <AlertTriangle className="w-4 h-4 text-rose-500" />
            </div>
            <p className="text-2xl font-black text-rose-600 dark:text-rose-400">{failedOrders.length} <span className="text-xs font-normal text-[#9CA3AF]">đơn</span></p>
          </div>

          <div
            onClick={() => onNavigateTab('cod')}
            className="p-4 bg-white dark:bg-slate-900 rounded-xl border border-[#E5E7EB] dark:border-slate-800 shadow-sm space-y-1 cursor-pointer hover:border-blue-400 transition-all"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs text-[#9CA3AF] font-medium">Cần nộp COD</span>
              <DollarSign className="w-4 h-4 text-blue-500" />
            </div>
            <p className="text-lg font-mono font-black text-blue-600 dark:text-blue-400">{formatVND(codToDeposit)}</p>
          </div>
        </div>
      </div>

      {/* Quick Orders List Preview */}
      <div className="p-4 bg-white dark:bg-slate-900 rounded-xl border border-[#E5E7EB] dark:border-slate-800 shadow-sm space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-[#E5E7EB] dark:border-slate-800">
          <h4 className="font-bold text-[10px] text-[#9CA3AF] uppercase tracking-wider">
            Đơn hàng cần giao gần nhất
          </h4>
          <button
            onClick={() => onNavigateTab('orders')}
            className="text-xs font-bold text-[#FF6321] hover:underline"
          >
            Xem tất cả ({myOrders.length})
          </button>
        </div>

        <div className="space-y-2">
          {myOrders.slice(0, 3).map((ord) => (
            <div key={ord.id} className="p-3 bg-[#F8F9FA] dark:bg-slate-800/40 rounded-lg border border-[#E5E7EB] dark:border-slate-800 text-xs space-y-1">
              <div className="flex justify-between items-start">
                <span className="font-bold text-[#1F2937] dark:text-white">{ord.recipientName}</span>
                <span className="font-mono font-bold text-[#FF6321]">{formatVND(ord.codAmount)}</span>
              </div>
              <p className="text-[#9CA3AF] truncate text-[11px]">{ord.recipientAddress}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
