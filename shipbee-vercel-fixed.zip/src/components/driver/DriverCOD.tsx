import React, { useState } from 'react';
import { DollarSign, Upload, Clock, CheckCircle2, AlertTriangle, ArrowRight, Camera } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { formatVND, formatDateTime } from '../../utils/helpers';
import { Modal } from '../common/Modal';

export const DriverCOD: React.FC = () => {
  const { currentUser, orders, codDeposits, submitCodDeposit } = useApp();

  const [isDepositModalOpen, setIsDepositModalOpen] = useState(false);
  const [depositAmount, setDepositAmount] = useState<number>(0);
  const [depositNote, setDepositNote] = useState('');
  const [proofImage, setProofImage] = useState<string>('https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=500&auto=format&fit=crop&q=80');

  const myOrders = orders.filter((o) => o.driverId === currentUser?.id);
  const deliveredOrders = myOrders.filter((o) => o.status === 'GIAO_THANH_CONG' || o.status === 'DA_NOP_COD' || o.status === 'DA_DOI_SOAT');

  const totalCodCollected = deliveredOrders.reduce(
    (sum, o) => sum + (o.collectedCodAmount !== undefined ? o.collectedCodAmount : ((o.codAmount || 0) + (o.shippingFee || 0))),
    0
  );

  const myDeposits = codDeposits.filter((d) => d.driverId === currentUser?.id);
  const confirmedDeposits = myDeposits.filter((d) => d.status === 'DA_XAC_NHAN').reduce((sum, d) => sum + d.amount, 0);

  const pendingDeposits = myDeposits.filter((d) => d.status === 'CHO_XAC_NHAN').reduce((sum, d) => sum + d.amount, 0);

  const codToDeposit = totalCodCollected - confirmedDeposits;

  const handleOpenDepositModal = () => {
    setDepositAmount(codToDeposit > 0 ? codToDeposit : 0);
    setDepositNote('');
    setIsDepositModalOpen(true);
  };

  const handleSubmitDeposit = (e: React.FormEvent) => {
    e.preventDefault();
    if (depositAmount <= 0) {
      alert('Số tiền nộp phải lớn hơn 0!');
      return;
    }

    submitCodDeposit({
      amount: depositAmount,
      note: depositNote || 'Xế nộp tiền mặt / chuyển khoản',
      proofImageUrl: proofImage,
    });

    setIsDepositModalOpen(false);
    alert('Đã gửi phiếu nộp COD! Quản lý kho sẽ đối soát và xác nhận.');
  };

  return (
    <div className="space-y-4 animate-fade-in pb-16">
      {/* Top Mobile Header */}
      <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
        <h2 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
          <DollarSign className="w-5 h-5 text-emerald-500" /> Quản Lý Tiền COD Giao Hàng
        </h2>
        <p className="text-xs text-slate-500">
          Tổng số tiền thu hộ từ khách hàng và trạng thái nộp tiền về Quản lý kho.
        </p>
      </div>

      {/* COD Summary Card */}
      <div className="p-5 bg-gradient-to-br from-slate-900 to-slate-800 text-white rounded-3xl space-y-4 shadow-xl">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-[10px] uppercase font-bold text-slate-400">Tiền COD Cần Nộp Về Kho</p>
            <p className="text-3xl font-black text-amber-400 mt-1">{formatVND(codToDeposit)}</p>
          </div>
          <button
            onClick={handleOpenDepositModal}
            className="px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs rounded-xl shadow-md transition-all active:scale-95"
          >
            NỘP TIỀN COD
          </button>
        </div>

        <div className="grid grid-cols-2 gap-2 text-xs pt-3 border-t border-slate-700/80 text-slate-300">
          <div>
            <span>Đã thu thực tế:</span>
            <p className="font-bold text-emerald-400 text-sm">{formatVND(totalCodCollected)}</p>
          </div>
          <div>
            <span>Kho đã xác nhận:</span>
            <p className="font-bold text-blue-400 text-sm">{formatVND(confirmedDeposits)}</p>
          </div>
        </div>

        {pendingDeposits > 0 && (
          <p className="text-[11px] text-amber-300 italic bg-amber-950/60 p-2 rounded-xl border border-amber-800">
            Đang có {formatVND(pendingDeposits)} chờ Quản lý duyệt nhận tiền.
          </p>
        )}
      </div>

      {/* Deposit Requests History */}
      <div className="space-y-3">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider px-1">
          Lịch sử các lần nộp COD ({myDeposits.length})
        </h3>

        {myDeposits.length === 0 ? (
          <p className="text-center py-8 text-slate-400 text-xs">Chưa có lịch sử nộp tiền COD</p>
        ) : (
          myDeposits.map((dep) => (
            <div key={dep.id} className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-2">
              <div className="flex justify-between items-start">
                <div>
                  <p className="font-bold text-sm text-slate-900 dark:text-white">{formatVND(dep.amount)}</p>
                  <p className="text-[10px] text-slate-400">{dep.depositCode} • {formatDateTime(dep.createdAt)}</p>
                </div>
                {dep.status === 'DA_XAC_NHAN' ? (
                  <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 font-bold rounded-md text-[10px]">
                    Kho đã nhận
                  </span>
                ) : (
                  <span className="px-2 py-0.5 bg-amber-100 text-amber-800 font-bold rounded-md text-[10px]">
                    Chờ kho duyệt
                  </span>
                )}
              </div>
              {dep.note && <p className="text-xs text-slate-500 italic">"{dep.note}"</p>}
            </div>
          ))
        )}
      </div>

      {/* Deposit Form Modal */}
      <Modal isOpen={isDepositModalOpen} onClose={() => setIsDepositModalOpen(false)} title="Nộp Tiền COD Về Quản Lý Kho">
        <form onSubmit={handleSubmitDeposit} className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Số tiền COD nộp (VNĐ):</label>
            <input
              type="number"
              required
              value={depositAmount}
              onChange={(e) => setDepositAmount(Number(e.target.value))}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl font-bold text-amber-600 text-base"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Ghi chú nộp (Ví dụ: Nộp tiền mặt ca sáng):</label>
            <input
              type="text"
              placeholder="VD: Chuyển khoản Vietcombank / Nộp tiền mặt quầy"
              value={depositNote}
              onChange={(e) => setDepositNote(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Ảnh biên nhận / Bill chuyển khoản:</label>
            <div className="flex items-center gap-3">
              <img src={proofImage} alt="" className="w-16 h-16 object-cover rounded-xl border border-slate-300" />
              <button
                type="button"
                onClick={() => alert('Đã chụp / tải ảnh biên nhận!')}
                className="px-3 py-2 bg-slate-100 dark:bg-slate-800 font-bold rounded-xl flex items-center gap-1.5"
              >
                <Camera className="w-4 h-4 text-amber-500" /> Tải Ảnh Biên Nhận
              </button>
            </div>
          </div>

          <div className="pt-3 flex justify-end gap-3">
            <button
              type="button"
              onClick={() => setIsDepositModalOpen(false)}
              className="px-4 py-2 text-slate-600 dark:text-slate-300"
            >
              Hủy
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl shadow-md"
            >
              Gửi Yêu Cầu Nộp Tiền
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
