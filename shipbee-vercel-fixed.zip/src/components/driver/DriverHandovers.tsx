import React, { useState } from 'react';
import { Truck, CheckCircle2, Clock, FileText, ShieldAlert, ChevronDown, ChevronUp } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { formatVND, formatDateTime, getHandoverSheetStatusMeta } from '../../utils/helpers';
import { PrintHandoverModal } from '../common/PrintHandoverModal';
import { HandoverSheet } from '../../types';

export const DriverHandovers: React.FC = () => {
  const { currentUser, handoverSheets, acceptHandoverSheet, orders } = useApp();

  const [expandedSheetId, setExpandedSheetId] = useState<string | null>(null);
  const [printableSheet, setPrintableSheet] = useState<HandoverSheet | null>(null);

  const mySheets = handoverSheets.filter((s) => s.driverId === currentUser?.id);

  const pendingSheets = mySheets.filter((s) => s.status === 'CHO_XE_XAC_NHAN');
  const acceptedSheets = mySheets.filter((s) => s.status !== 'CHO_XE_XAC_NHAN');

  const handleAccept = (sheet: HandoverSheet) => {
    acceptHandoverSheet(sheet.id, '21.0362, 105.7821 (App Mobile)');
    alert(`Đã xác nhận tiếp nhận phiếu ${sheet.sheetCode}! Toàn bộ ${sheet.totalOrders} đơn hàng đã được chuyển sang trạng thái "Xế đã nhận".`);
  };

  return (
    <div className="space-y-4 animate-fade-in pb-16">
      {/* Top Header */}
      <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <h2 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
          <Truck className="w-5 h-5 text-amber-500" /> Phiếu Bàn Giao Của Xế ({mySheets.length})
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          Kiểm tra số lượng đơn & tiền COD thực nhận từ Quản lý kho trước khi bấm xác nhận.
        </p>
      </div>

      {/* Pending Accept Sheets Alert Section */}
      {pendingSheets.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-xs font-extrabold text-rose-600 uppercase tracking-wider px-1">
            Phiếu bàn giao mới cần xác nhận ({pendingSheets.length})
          </h3>

          {pendingSheets.map((sheet) => {
            const sheetOrders = orders.filter((o) => sheet.orderIds.includes(o.id));
            const isExpanded = expandedSheetId === sheet.id;

            return (
              <div key={sheet.id} className="p-4 bg-rose-50/80 dark:bg-rose-950/40 border-2 border-rose-500 rounded-2xl space-y-3 shadow-md">
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-[10px] font-bold text-rose-600 uppercase">Chờ Xế xác nhận</span>
                    <h4 className="font-black text-base text-slate-900 dark:text-white">{sheet.sheetCode}</h4>
                    <p className="text-xs text-slate-500">Quản lý kho: {sheet.managerName}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-lg font-black text-rose-600 dark:text-rose-400">{formatVND(sheet.totalCodAmount)}</p>
                    <span className="text-xs font-bold text-slate-700 dark:text-slate-200">{sheet.totalOrders} đơn hàng</span>
                  </div>
                </div>

                {/* Toggle View Order List */}
                <button
                  onClick={() => setExpandedSheetId(isExpanded ? null : sheet.id)}
                  className="w-full py-1.5 text-xs font-semibold text-rose-700 dark:text-rose-300 flex items-center justify-center gap-1 bg-white/60 dark:bg-slate-900/60 rounded-xl"
                >
                  {isExpanded ? 'Ẩn danh sách đơn' : 'Xem danh sách đơn'} {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </button>

                {isExpanded && (
                  <div className="space-y-1.5 pt-2 border-t border-rose-200 dark:border-rose-900 text-xs">
                    {sheetOrders.map((ord, idx) => (
                      <div key={ord.id} className="p-2 bg-white dark:bg-slate-900 rounded-lg flex justify-between">
                        <span>{idx + 1}. {ord.recipientName} ({ord.recipientPhone})</span>
                        <strong className="text-amber-600">{formatVND(ord.codAmount)}</strong>
                      </div>
                    ))}
                  </div>
                )}

                {/* Big Accept Button */}
                <button
                  onClick={() => handleAccept(sheet)}
                  className="w-full py-3 bg-rose-600 hover:bg-rose-700 text-white font-black text-xs rounded-xl shadow-lg flex items-center justify-center gap-2"
                >
                  <CheckCircle2 className="w-5 h-5" /> XÁC NHẬN ĐÃ NHẬN ĐỦ {sheet.totalOrders} ĐƠN & TỔNG TIỀN
                </button>
              </div>
            );
          })}
        </div>
      )}

      {/* Accepted Sheets History */}
      <div className="space-y-3">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider px-1">
          Lịch sử phiếu đã tiếp nhận ({acceptedSheets.length})
        </h3>

        {acceptedSheets.length === 0 ? (
          <p className="text-center py-8 text-slate-400 text-xs">Chưa có phiếu bàn giao đã nhận</p>
        ) : (
          acceptedSheets.map((sheet) => {
            const statusMeta = getHandoverSheetStatusMeta(sheet.status);
            return (
              <div key={sheet.id} className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-2">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-bold text-sm text-slate-900 dark:text-white">{sheet.sheetCode}</h4>
                    <p className="text-[11px] text-slate-400">{formatDateTime(sheet.acceptedAt || sheet.createdAt)}</p>
                  </div>
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${statusMeta.badgeClass}`}>
                    {statusMeta.label}
                  </span>
                </div>

                <div className="flex justify-between text-xs pt-1 border-t border-slate-100 dark:border-slate-800">
                  <span className="text-slate-500">Số đơn: <strong>{sheet.totalOrders}</strong></span>
                  <span className="text-slate-500">COD: <strong className="text-emerald-600">{formatVND(sheet.totalCodAmount)}</strong></span>
                </div>

                <button
                  onClick={() => setPrintableSheet(sheet)}
                  className="w-full py-1.5 bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 font-bold text-[11px] rounded-xl text-center"
                >
                  In / Xem Chi Tiết Phiếu Điện Tử
                </button>
              </div>
            );
          })
        )}
      </div>

      <PrintHandoverModal sheet={printableSheet} isOpen={!!printableSheet} onClose={() => setPrintableSheet(null)} />
    </div>
  );
};
