import React from 'react';
import { User, Phone, Shield, Lock, LogOut, CheckCircle2 } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const DriverAccount: React.FC = () => {
  const { currentUser, users, setCurrentUser } = useApp();

  if (!currentUser) return null;

  const manager = users.find((u) => u.id === currentUser.managerId);

  return (
    <div className="space-y-4 animate-fade-in pb-16">
      {/* Account Profile Header */}
      <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs text-center space-y-3">
        <img
          src={currentUser.avatarUrl}
          alt={currentUser.fullName}
          className="w-20 h-20 rounded-full object-cover mx-auto border-4 border-amber-500 shadow-md"
        />
        <div>
          <h2 className="text-lg font-black text-slate-900 dark:text-white">{currentUser.fullName}</h2>
          <p className="text-xs text-slate-400">@{currentUser.username} • Tài Khoản Xế Giao Hàng</p>
        </div>
        <span className="inline-block px-3 py-1 bg-emerald-100 text-emerald-800 dark:bg-emerald-900/50 dark:text-emerald-300 font-bold text-xs rounded-full">
          Đang Hoạt Động
        </span>
      </div>

      {/* Driver Details Card */}
      <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3 text-xs">
        <h3 className="font-bold text-slate-900 dark:text-white pb-2 border-b border-slate-100 dark:border-slate-800">
          Thông Tin Tài Khoản
        </h3>

        <div className="flex justify-between py-1">
          <span className="text-slate-500">Số điện thoại:</span>
          <strong className="text-slate-800 dark:text-slate-200">{currentUser.phone}</strong>
        </div>

        <div className="flex justify-between py-1">
          <span className="text-slate-500">Quản lý kho phụ trách:</span>
          <strong className="text-amber-600">{manager ? manager.fullName : 'N/A'}</strong>
        </div>

        <div className="flex justify-between py-1">
          <span className="text-slate-500">Thiết bị đăng nhập:</span>
          <span className="text-slate-600 dark:text-slate-400">Mobile Web App (Android / iOS)</span>
        </div>
      </div>

      {/* Role Switcher for Demo */}
      <div className="p-5 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-2xl space-y-3 text-xs">
        <h3 className="font-bold text-amber-900 dark:text-amber-200">
          Chuyển Đổi Tài Khoản Demo (Kiểm thử 3 Cấp)
        </h3>
        <p className="text-slate-600 dark:text-slate-300 text-[11px]">
          Bạn có thể chuyển sang tài khoản Admin hoặc Quản lý kho để trải nghiệm luồng bàn giao toàn trình.
        </p>
        <div className="grid grid-cols-2 gap-2 pt-1">
          {users
            .filter((u) => u.id !== currentUser.id)
            .map((u) => (
              <button
                key={u.id}
                onClick={() => setCurrentUser(u)}
                className="p-2 bg-white dark:bg-slate-800 border border-amber-300 rounded-xl font-bold text-slate-800 dark:text-slate-200 text-left hover:bg-amber-100 transition-colors"
              >
                <p className="truncate">{u.fullName}</p>
                <span className="text-[10px] text-amber-600 font-normal">
                  {u.role === 'ADMIN' ? 'Admin' : u.role === 'MANAGER' ? 'Quản lý kho' : 'Xế'}
                </span>
              </button>
            ))}
        </div>
      </div>
    </div>
  );
};
