import React, { useState } from 'react';
import { Phone, MapPin, Copy, CheckCircle2, XCircle, Search, Camera, QrCode, AlertTriangle, Navigation, Upload, Check } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { formatVND, getOrderStatusMeta, buildGoogleMapsUrl } from '../../utils/helpers';
import { Order, OrderStatus } from '../../types';
import { Modal } from '../common/Modal';

export const DriverOrders: React.FC = () => {
  const { currentUser, orders, updateOrderStatus } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFilterStatus, setSelectedFilterStatus] = useState<string>('ALL');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Status Modal State
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [isSuccessMode, setIsSuccessMode] = useState(true);

  // Form Fields
  const [collectedCod, setCollectedCod] = useState<number>(0);
  const [proofImage, setProofImage] = useState<string>('https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=500&auto=format&fit=crop&q=80');
  const [failureReason, setFailureReason] = useState<OrderStatus>('KHANG_HEN_GIAO_LAI');
  const [failureNotes, setFailureNotes] = useState('');
  const [deliveryAddressNote, setDeliveryAddressNote] = useState('');

  const myOrders = orders.filter((o) => o.driverId === currentUser?.id);

  const filteredOrders = myOrders.filter((o) => {
    const matchesSearch =
      o.orderCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
      o.recipientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      o.recipientPhone.includes(searchTerm) ||
      o.recipientAddress.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = selectedFilterStatus === 'ALL' || o.status === selectedFilterStatus;

    return matchesSearch && matchesStatus;
  });

  const handleCopyAddress = (address: string, id: string) => {
    navigator.clipboard.writeText(address);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleOpenStatusModal = (ord: Order, successMode: boolean) => {
    setSelectedOrder(ord);
    setIsSuccessMode(successMode);
    setCollectedCod(ord.codAmount + (ord.shippingFee || 0));
    setFailureNotes('');
    setDeliveryAddressNote('');
  };

  const handleConfirmStatusUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedOrder) return;

    if (isSuccessMode) {
      updateOrderStatus(selectedOrder.id, 'GIAO_THANH_CONG', {
        collectedCodAmount: collectedCod,
        proofImageUrl: proofImage,
        deliveryNotes: deliveryAddressNote || 'Giao thành công cho chính chủ',
        deliveryLocation: '21.0362, 105.7821 (Cầu Giấy, Hà Nội)',
      });
      alert(`Đã cập nhật giao thành công cho đơn ${selectedOrder.orderCode}!`);
    } else {
      updateOrderStatus(selectedOrder.id, failureReason, {
        failureReason: failureNotes || 'Khách báo hẹn lại / không nghe máy',
        deliveryNotes: failureNotes,
      });
      alert(`Đã cập nhật trạng thái thất bại / hẹn lại cho đơn ${selectedOrder.orderCode}!`);
    }

    setSelectedOrder(null);
  };

  return (
    <div className="space-y-4 animate-fade-in pb-16">
      {/* Top Mobile Bar */}
      <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
        <div className="flex justify-between items-center">
          <h2 className="text-base font-black text-slate-900 dark:text-white">
            Danh Sách Đơn Của Xế ({myOrders.length})
          </h2>
          <span className="text-xs text-slate-500">Chợt nhẹ để gọi điện / chỉ đường</span>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
          <input
            type="text"
            placeholder="Tìm tên khách, SĐT, địa chỉ, mã đơn..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-hidden"
          />
        </div>

        {/* Status Pills */}
        <div className="flex gap-2 overflow-x-auto pb-1 text-xs">
          <button
            onClick={() => setSelectedFilterStatus('ALL')}
            className={`px-3 py-1.5 rounded-md font-bold whitespace-nowrap transition-all ${
              selectedFilterStatus === 'ALL'
                ? 'bg-[#FF6321] text-white'
                : 'bg-white dark:bg-slate-800 text-[#1F2937] dark:text-slate-300 border border-[#E5E7EB]'
            }`}
          >
            Tất cả ({myOrders.length})
          </button>
          <button
            onClick={() => setSelectedFilterStatus('XE_DA_NHAN')}
            className={`px-3 py-1.5 rounded-md font-bold whitespace-nowrap transition-all ${
              selectedFilterStatus === 'XE_DA_NHAN'
                ? 'bg-[#FF6321] text-white'
                : 'bg-white dark:bg-slate-800 text-[#1F2937] dark:text-slate-300 border border-[#E5E7EB]'
            }`}
          >
            Chờ giao
          </button>
          <button
            onClick={() => setSelectedFilterStatus('GIAO_THANH_CONG')}
            className={`px-3 py-1.5 rounded-md font-bold whitespace-nowrap transition-all ${
              selectedFilterStatus === 'GIAO_THANH_CONG'
                ? 'bg-emerald-600 text-white'
                : 'bg-white dark:bg-slate-800 text-[#1F2937] dark:text-slate-300 border border-[#E5E7EB]'
            }`}
          >
            Giao xong
          </button>
        </div>
      </div>

      {/* Orders List Cards */}
      <div className="space-y-3">
        {filteredOrders.length === 0 ? (
          <p className="text-center py-10 text-[#9CA3AF] text-xs">Không tìm thấy đơn hàng nào</p>
        ) : (
          filteredOrders.map((ord) => {
            const statusMeta = getOrderStatusMeta(ord.status);
            const mapsUrl = buildGoogleMapsUrl(ord.recipientAddress);

            return (
              <div
                key={ord.id}
                className="p-4 bg-white dark:bg-slate-900 rounded-xl border border-[#E5E7EB] dark:border-slate-800 shadow-sm space-y-3"
              >
                {/* Header info */}
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-[10px] text-[#FF6321] font-mono font-bold">{ord.orderCode} • {ord.trackingCode}</span>
                    <h3 className="font-bold text-sm text-[#1F2937] dark:text-white">{ord.recipientName}</h3>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-slate-500 font-medium">Tổng thu khách:</p>
                    <p className="text-base font-mono font-black text-[#FF6321]">{formatVND(ord.codAmount + (ord.shippingFee || 0))}</p>
                    <p className="text-[10px] text-slate-400 font-mono">COD: {formatVND(ord.codAmount)} • Ship: {formatVND(ord.shippingFee || 0)}</p>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold border mt-1 inline-block ${statusMeta.badgeClass}`}>
                      {statusMeta.label}
                    </span>
                  </div>
                </div>

                {/* Address & Quick Actions */}
                <div className="p-3 bg-[#F8F9FA] dark:bg-slate-800/50 rounded-lg space-y-2 text-xs border border-[#E5E7EB] dark:border-slate-800">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-start gap-1.5 text-slate-700 dark:text-slate-300">
                      <MapPin className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
                      <span className="font-semibold">{ord.recipientAddress}</span>
                    </div>
                    <button
                      onClick={() => handleCopyAddress(ord.recipientAddress, ord.id)}
                      className="p-1 text-[#9CA3AF] hover:text-[#FF6321] shrink-0"
                      title="Sao chép địa chỉ"
                    >
                      {copiedId === ord.id ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>

                  {ord.notes && (
                    <p className="text-[11px] text-slate-800 dark:text-amber-300 font-medium italic bg-[#FFF5F1] dark:bg-amber-950/40 p-1.5 rounded border border-[#FF6321]/30">
                      Ghi chú: {ord.notes}
                    </p>
                  )}
                </div>

                {/* One-Tap Phone & Maps Action Buttons */}
                <div className="grid grid-cols-2 gap-2 pt-1">
                  <a
                    href={`tel:${ord.recipientPhone}`}
                    className="py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 shadow-xs"
                  >
                    <Phone className="w-4 h-4" /> Gọi {ord.recipientPhone}
                  </a>

                  <a
                    href={mapsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 shadow-xs"
                  >
                    <Navigation className="w-4 h-4" /> Chỉ đường Google Maps
                  </a>
                </div>

                {/* Status update buttons (if not completed) */}
                {ord.status !== 'GIAO_THANH_CONG' && ord.status !== 'DA_NOP_COD' && (
                  <div className="grid grid-cols-2 gap-2 pt-1">
                    <button
                      onClick={() => handleOpenStatusModal(ord, true)}
                      className="py-2.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs rounded-xl flex items-center justify-center gap-1.5 shadow-md"
                    >
                      <CheckCircle2 className="w-4 h-4" /> GIAO THÀNH CÔNG
                    </button>
                    <button
                      onClick={() => handleOpenStatusModal(ord, false)}
                      className="py-2.5 bg-rose-100 dark:bg-rose-950/60 text-rose-800 dark:text-rose-200 hover:bg-rose-200 font-bold text-xs rounded-xl flex items-center justify-center gap-1.5"
                    >
                      <XCircle className="w-4 h-4" /> Báo Thất Bại / Hẹn Lại
                    </button>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Status Update Modal */}
      <Modal
        isOpen={!!selectedOrder}
        onClose={() => setSelectedOrder(null)}
        title={isSuccessMode ? `Giao Thành Công ${selectedOrder?.orderCode}` : `Báo Thất Bại ${selectedOrder?.orderCode}`}
      >
        <form onSubmit={handleConfirmStatusUpdate} className="space-y-4 text-xs">
          {isSuccessMode ? (
            /* Success Form */
            <div className="space-y-3">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Số tiền thực tế thu từ khách (COD: {formatVND(selectedOrder.codAmount)} + Ship: {formatVND(selectedOrder.shippingFee || 0)}):
                </label>
                <input
                  type="number"
                  required
                  value={collectedCod}
                  onChange={(e) => setCollectedCod(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl font-bold text-amber-600 text-base"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Chụp / Chọn ảnh đối chứng giao hàng:</label>
                <div className="flex items-center gap-3">
                  <img src={proofImage} alt="Ảnh giao hàng" className="w-16 h-16 object-cover rounded-xl border border-slate-300" />
                  <button
                    type="button"
                    onClick={() => {
                      alert('Đã giả lập chụp ảnh bằng camera điện thoại!');
                    }}
                    className="px-3 py-2 bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 font-bold rounded-xl flex items-center gap-1.5"
                  >
                    <Camera className="w-4 h-4 text-amber-500" /> Chụp Ảnh Ngay
                  </button>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Ghi chú giao hàng (Ví dụ: Gửi bảo vệ):</label>
                <input
                  type="text"
                  placeholder="VD: Khách đã nhận tại bảo vệ tầng 1"
                  value={deliveryAddressNote}
                  onChange={(e) => setDeliveryAddressNote(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
                />
              </div>
            </div>
          ) : (
            /* Failure Form */
            <div className="space-y-3">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Lý do giao không thành công:</label>
                <select
                  value={failureReason}
                  onChange={(e) => setFailureReason(e.target.value as OrderStatus)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl font-bold"
                >
                  <option value="KHANG_HEN_GIAO_LAI">Khách hẹn giao lại ca sau</option>
                  <option value="KHANG_KHONG_NGHE">Khách không nghe máy (Gọi 3 cuộc)</option>
                  <option value="SAI_DIA_CHI">Sai địa chỉ / Không tìm thấy số nhà</option>
                  <option value="KHANG_TU_CHOI">Khách từ chối nhận (Báo hoàn)</option>
                  <option value="GIAO_THAT_BAI">Lý do khác</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Chi tiết lý do:</label>
                <textarea
                  rows={3}
                  required
                  placeholder="VD: Khách hẹn 18h tối nay mới về nhà..."
                  value={failureNotes}
                  onChange={(e) => setFailureNotes(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
                />
              </div>
            </div>
          )}

          <div className="pt-3 flex justify-end gap-3">
            <button
              type="button"
              onClick={() => setSelectedOrder(null)}
              className="px-4 py-2 text-slate-600 dark:text-slate-300"
            >
              Hủy
            </button>
            <button
              type="submit"
              className={`px-5 py-2 font-bold text-white rounded-xl shadow-md ${
                isSuccessMode ? 'bg-amber-600 hover:bg-amber-700' : 'bg-rose-600 hover:bg-rose-700'
              }`}
            >
              Xác Nhận Cập Nhật
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
