import React, { useState } from 'react';
import { Shield, Database, GitBranch, Layers, Server, Workflow, CheckCircle, FileCode } from 'lucide-react';
import { Modal } from './Modal';

interface TechDocsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TechDocsModal: React.FC<TechDocsModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'hierarchy' | 'flow' | 'erd' | 'api' | 'process'>('hierarchy');

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Sơ Đồ Hệ Thống & Tài Liệu Kỹ Thuật (System Architecture & Docs)" maxWidth="max-w-4xl">
      <div className="space-y-4">
        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-200 dark:border-slate-800 overflow-x-auto scrollbar-none text-xs font-medium">
          <button
            onClick={() => setActiveTab('hierarchy')}
            className={`flex items-center gap-1.5 px-4 py-2.5 border-b-2 whitespace-nowrap transition-colors ${
              activeTab === 'hierarchy'
                ? 'border-amber-500 text-amber-600 dark:text-amber-400 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <Shield className="w-4 h-4" /> 1. Sơ Đồ Phân Quyền
          </button>
          <button
            onClick={() => setActiveTab('flow')}
            className={`flex items-center gap-1.5 px-4 py-2.5 border-b-2 whitespace-nowrap transition-colors ${
              activeTab === 'flow'
                ? 'border-amber-500 text-amber-600 dark:text-amber-400 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <GitBranch className="w-4 h-4" /> 2. User Flow
          </button>
          <button
            onClick={() => setActiveTab('process')}
            className={`flex items-center gap-1.5 px-4 py-2.5 border-b-2 whitespace-nowrap transition-colors ${
              activeTab === 'process'
                ? 'border-amber-500 text-amber-600 dark:text-amber-400 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <Workflow className="w-4 h-4" /> 3. Quy Trình Bàn Giao & COD
          </button>
          <button
            onClick={() => setActiveTab('erd')}
            className={`flex items-center gap-1.5 px-4 py-2.5 border-b-2 whitespace-nowrap transition-colors ${
              activeTab === 'erd'
                ? 'border-amber-500 text-amber-600 dark:text-amber-400 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <Database className="w-4 h-4" /> 4. Database ERD & Schema
          </button>
          <button
            onClick={() => setActiveTab('api')}
            className={`flex items-center gap-1.5 px-4 py-2.5 border-b-2 whitespace-nowrap transition-colors ${
              activeTab === 'api'
                ? 'border-amber-500 text-amber-600 dark:text-amber-400 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <Server className="w-4 h-4" /> 5. API Backend Spec
          </button>
        </div>

        {/* Tab 1: Hierarchy */}
        {activeTab === 'hierarchy' && (
          <div className="space-y-4 text-xs text-slate-700 dark:text-slate-300">
            <h4 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Shield className="w-4 h-4 text-amber-500" /> Sơ đồ Phân cấp Quyền hạn (Hierarchy Diagram)
            </h4>
            <div className="p-4 bg-slate-50 dark:bg-slate-800/80 rounded-xl border border-slate-200 dark:border-slate-700 space-y-4">
              <div className="flex flex-col items-center">
                <div className="w-64 p-3 bg-amber-600 text-white font-bold text-center rounded-xl shadow-md border border-amber-500">
                  <p className="text-sm">ADMINISTRATOR (Admin)</p>
                  <p className="text-[10px] font-normal text-amber-100">Quản trị toàn hệ thống, Cấu hình, Báo cáo & Nhật ký</p>
                </div>
                <div className="w-0.5 h-6 bg-amber-500 my-1"></div>
                
                <div className="grid grid-cols-2 gap-8 w-full max-w-xl">
                  {/* Manager 1 */}
                  <div className="flex flex-col items-center">
                    <div className="w-full p-2.5 bg-blue-600 text-white font-bold text-center rounded-lg shadow-xs">
                      <p className="text-xs">QUẢN LÝ ĐƠN 1 (Kho Cầu Giấy)</p>
                    </div>
                    <div className="w-0.5 h-4 bg-blue-400 my-1"></div>
                    <div className="w-full space-y-1">
                      <div className="p-2 bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 text-center rounded-md font-medium text-[11px]">
                        Xế 1 (Phạm Văn Xế)
                      </div>
                      <div className="p-2 bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 text-center rounded-md font-medium text-[11px]">
                        Xế 2 (Hoàng Đức Tài)
                      </div>
                    </div>
                  </div>

                  {/* Manager 2 */}
                  <div className="flex flex-col items-center">
                    <div className="w-full p-2.5 bg-blue-600 text-white font-bold text-center rounded-lg shadow-xs">
                      <p className="text-xs">QUẢN LÝ ĐƠN 2 (Kho Hoàn Kiếm)</p>
                    </div>
                    <div className="w-0.5 h-4 bg-blue-400 my-1"></div>
                    <div className="w-full space-y-1">
                      <div className="p-2 bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 text-center rounded-md font-medium text-[11px]">
                        Xế 3 (Lê Minh Tuấn)
                      </div>
                      <div className="p-2 bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 text-center rounded-md font-medium text-[11px]">
                        Xế 4 (Vũ Quốc Anh)
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3 pt-2">
              <div className="p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-lg">
                <span className="font-bold text-amber-800 dark:text-amber-300">ADMIN</span>
                <p className="text-[11px] mt-1 text-slate-600 dark:text-slate-400">
                  Tạo tài khoản, Khóa/mở tài khoản, Đặt mật khẩu, Phân công Xế cho Quản lý, Xem toàn bộ đơn & COD, Xuất báo cáo Excel tổng hợp.
                </p>
              </div>
              <div className="p-3 bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 rounded-lg">
                <span className="font-bold text-blue-800 dark:text-blue-300">QUẢN LÝ ĐƠN</span>
                <p className="text-[11px] mt-1 text-slate-600 dark:text-slate-400">
                  Tạo/nhập đơn Excel, Quét mã, Gom chuyến, Bàn giao đơn cho Xế thuộc kho, Nhận lại đơn hoàn/thất bại, Xác nhận đối soát COD.
                </p>
              </div>
              <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-lg">
                <span className="font-bold text-emerald-800 dark:text-emerald-300">XẾ (DRIVER)</span>
                <p className="text-[11px] mt-1 text-slate-600 dark:text-slate-400">
                  Xác nhận nhận phiếu bàn giao, Gọi điện khách, Mở Google Maps, Cập nhật giao thành công (chụp ảnh + thu COD), Nộp tiền COD.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Flow */}
        {activeTab === 'flow' && (
          <div className="space-y-3 text-xs text-slate-700 dark:text-slate-300">
            <h4 className="text-sm font-bold text-slate-900 dark:text-white">Luồng người dùng chính (User Flow)</h4>
            <div className="space-y-3 font-mono">
              <div className="p-3 bg-slate-900 text-slate-100 rounded-lg text-[11px] space-y-1">
                <p className="text-amber-400 font-bold">[1. Nhập đơn & Bàn giao]:</p>
                <p className="text-slate-300 pl-2">Quản lý -&gt; Nhập đơn/Excel/Scan -&gt; Chọn nhóm đơn -&gt; Chọn Xế -&gt; Tạo Phiếu Bàn Giao (CHO_XE_XAC_NHAN)</p>
              </div>

              <div className="p-3 bg-slate-900 text-slate-100 rounded-lg text-[11px] space-y-1">
                <p className="text-amber-400 font-bold">[2. Xế tiếp nhận]:</p>
                <p className="text-slate-300 pl-2">Xế -&gt; Nhận thông báo -&gt; Kiểm tra số lượng/COD -&gt; Nhấn "Xác nhận đã nhận" -&gt; Đơn chuyển sang XE_DA_NHAN/DANG_DI_GIAO</p>
              </div>

              <div className="p-3 bg-slate-900 text-slate-100 rounded-lg text-[11px] space-y-1">
                <p className="text-amber-400 font-bold">[3. Đi giao & Thu tiền]:</p>
                <p className="text-slate-300 pl-2">Xế -&gt; Mở bản đồ/Gọi điện -&gt; Giao thành công (Chụp ảnh minh chứng + Nhập COD) HOẶC Báo giao thất bại + Lý do</p>
              </div>

              <div className="p-3 bg-slate-900 text-slate-100 rounded-lg text-[11px] space-y-1">
                <p className="text-amber-400 font-bold">[4. Nộp COD & Đối soát]:</p>
                <p className="text-slate-300 pl-2">Xế -&gt; Nhập số tiền nộp COD + Ảnh biên nhận -&gt; Quản lý kiểm tra -&gt; Xác nhận nhận tiền -&gt; Chuyển phiếu bàn giao sang DA_DOI_SOAT</p>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Process */}
        {activeTab === 'process' && (
          <div className="space-y-3 text-xs text-slate-700 dark:text-slate-300">
            <h4 className="text-sm font-bold text-slate-900 dark:text-white">Quy Trình Bàn Giao & Đối Soát COD Minh Bạch</h4>
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2">
                <h5 className="font-bold text-amber-600 dark:text-amber-400">Quy trình bàn giao điện tử</h5>
                <ol className="list-decimal list-inside space-y-1 text-[11px] text-slate-600 dark:text-slate-300">
                  <li>Tạo đơn / Import danh sách từ file Excel.</li>
                  <li>Lọc và chọn các đơn cùng tuyến giao.</li>
                  <li>Phân bổ cho tài khoản Xế tương ứng.</li>
                  <li>Hệ thống chốt số đơn, tổng COD và tạo Mã Phiếu PBG-xxxx.</li>
                  <li>Xế kiểm tra trực quan và bấm Xác Nhận Nhận Đơn.</li>
                  <li>Lưu lại Thời gian, Vị trí GPS và Thiết bị xác nhận.</li>
                </ol>
              </div>

              <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2">
                <h5 className="font-bold text-emerald-600 dark:text-emerald-400">Quy trình nộp & đối soát COD</h5>
                <ol className="list-decimal list-inside space-y-1 text-[11px] text-slate-600 dark:text-slate-300">
                  <li>Xế thu tiền COD từ khách hàng thực tế.</li>
                  <li>Tạo phiếu nộp COD (tiền mặt / chuyển khoản + ảnh biên nhận).</li>
                  <li>Quản lý kiểm tra tiền thực nộp vs tiền COD hệ thống.</li>
                  <li>Quản lý bấm Xác Nhận Thu Tiền.</li>
                  <li>Bàn giao lại các đơn giao thất bại hoặc đơn hoàn.</li>
                  <li>Khoá số liệu đối soát, không cho phép chỉnh sửa sau khi chốt.</li>
                </ol>
              </div>
            </div>
          </div>
        )}

        {/* Tab 4: ERD */}
        {activeTab === 'erd' && (
          <div className="space-y-3 text-xs text-slate-700 dark:text-slate-300">
            <h4 className="text-sm font-bold text-slate-900 dark:text-white">Database Schema & Relational ERD (PostgreSQL / Firestore)</h4>
            <div className="p-4 bg-slate-950 text-slate-200 rounded-xl font-mono text-[11px] overflow-x-auto space-y-3">
              <div>
                <p className="text-amber-400 font-bold">TABLE users (</p>
                <p className="pl-4">id VARCHAR(50) PRIMARY KEY,</p>
                <p className="pl-4">username VARCHAR(50) UNIQUE NOT NULL,</p>
                <p className="pl-4">full_name VARCHAR(100) NOT NULL,</p>
                <p className="pl-4">phone VARCHAR(20),</p>
                <p className="pl-4">role VARCHAR(20) CHECK (role IN ('ADMIN', 'MANAGER', 'DRIVER')),</p>
                <p className="pl-4">manager_id VARCHAR(50) REFERENCES users(id),</p>
                <p className="pl-4">is_locked BOOLEAN DEFAULT FALSE</p>
                <p className="text-amber-400">);</p>
              </div>

              <div>
                <p className="text-amber-400 font-bold">TABLE orders (</p>
                <p className="pl-4">id VARCHAR(50) PRIMARY KEY,</p>
                <p className="pl-4">order_code VARCHAR(50) NOT NULL,</p>
                <p className="pl-4">tracking_code VARCHAR(50) UNIQUE NOT NULL,</p>
                <p className="pl-4">recipient_name VARCHAR(100),</p>
                <p className="pl-4">recipient_phone VARCHAR(20),</p>
                <p className="pl-4">recipient_address TEXT,</p>
                <p className="pl-4">cod_amount NUMERIC(12, 2) DEFAULT 0,</p>
                <p className="pl-4">status VARCHAR(30) NOT NULL,</p>
                <p className="pl-4">manager_id VARCHAR(50) REFERENCES users(id),</p>
                <p className="pl-4">driver_id VARCHAR(50) REFERENCES users(id),</p>
                <p className="pl-4">handover_sheet_id VARCHAR(50) REFERENCES handover_sheets(id)</p>
                <p className="text-amber-400">);</p>
              </div>

              <div>
                <p className="text-amber-400 font-bold">TABLE handover_sheets (</p>
                <p className="pl-4">id VARCHAR(50) PRIMARY KEY,</p>
                <p className="pl-4">sheet_code VARCHAR(50) NOT NULL,</p>
                <p className="pl-4">manager_id VARCHAR(50) REFERENCES users(id),</p>
                <p className="pl-4">driver_id VARCHAR(50) REFERENCES users(id),</p>
                <p className="pl-4">total_orders INT NOT NULL,</p>
                <p className="pl-4">total_cod_amount NUMERIC(12, 2) NOT NULL,</p>
                <p className="pl-4">status VARCHAR(30) NOT NULL</p>
                <p className="text-amber-400">);</p>
              </div>
            </div>
          </div>
        )}

        {/* Tab 5: API */}
        {activeTab === 'api' && (
          <div className="space-y-3 text-xs text-slate-700 dark:text-slate-300">
            <h4 className="text-sm font-bold text-slate-900 dark:text-white">API Endpoints Backend Specifications</h4>
            <div className="space-y-2 text-[11px]">
              <div className="p-2.5 bg-slate-50 dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700 flex items-center justify-between">
                <div><span className="font-bold text-emerald-600">GET</span> <code className="text-slate-800 dark:text-slate-200 font-mono">/api/v1/orders</code></div>
                <span className="text-slate-500">Lấy danh sách đơn hàng (Lọc theo role/trạng thái)</span>
              </div>
              <div className="p-2.5 bg-slate-50 dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700 flex items-center justify-between">
                <div><span className="font-bold text-blue-600">POST</span> <code className="text-slate-800 dark:text-slate-200 font-mono">/api/v1/orders/batch-import</code></div>
                <span className="text-slate-500">Nhập danh sách đơn hàng từ Excel</span>
              </div>
              <div className="p-2.5 bg-slate-50 dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700 flex items-center justify-between">
                <div><span className="font-bold text-blue-600">POST</span> <code className="text-slate-800 dark:text-slate-200 font-mono">/api/v1/handovers/create</code></div>
                <span className="text-slate-500">Tạo phiếu bàn giao đơn hàng cho Xế</span>
              </div>
              <div className="p-2.5 bg-slate-50 dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700 flex items-center justify-between">
                <div><span className="font-bold text-purple-600">PUT</span> <code className="text-slate-800 dark:text-slate-200 font-mono">/api/v1/handovers/:id/accept</code></div>
                <span className="text-slate-500">Xế bấm xác nhận tiếp nhận phiếu bàn giao</span>
              </div>
              <div className="p-2.5 bg-slate-50 dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700 flex items-center justify-between">
                <div><span className="font-bold text-blue-600">POST</span> <code className="text-slate-800 dark:text-slate-200 font-mono">/api/v1/cod/deposit</code></div>
                <span className="text-slate-500">Xế gửi yêu cầu nộp tiền COD</span>
              </div>
              <div className="p-2.5 bg-slate-50 dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700 flex items-center justify-between">
                <div><span className="font-bold text-amber-600">POST</span> <code className="text-slate-800 dark:text-slate-200 font-mono">/api/v1/cod/reconcile</code></div>
                <span className="text-slate-500">Quản lý xác nhận đối soát COD chính thức</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </Modal>
  );
};
