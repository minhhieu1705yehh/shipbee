import React, { useState, useEffect, useRef } from 'react';
import { Camera, QrCode, Search, CheckCircle2, AlertCircle, RefreshCw, Volume2 } from 'lucide-react';
import { Html5Qrcode, Html5QrcodeSupportedFormats } from 'html5-qrcode';
import { Modal } from './Modal';
import { useApp } from '../../context/AppContext';

interface ScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onScanSuccess?: (code: string) => void;
}

export const ScannerModal: React.FC<ScannerModalProps> = ({ isOpen, onClose, onScanSuccess }) => {
  const { orders } = useApp();
  const [manualCode, setManualCode] = useState('');
  const [scannedResult, setScannedResult] = useState<string | null>(null);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const html5QrcodeRef = useRef<Html5Qrcode | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);

  // Audio feedback on successful scan
  const playBeep = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, audioCtx.currentTime); // A5 note
      gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.15);
    } catch {
      // AudioContext might be blocked or unsupported
    }
  };

  const handleProcessCode = (codeRaw: string) => {
    const code = codeRaw.trim().toUpperCase().replace(/[\r\n]/g, '');
    if (!code) return;

    playBeep();
    setScannedResult(code);
    if (onScanSuccess) {
      onScanSuccess(code);
    }
  };

  // Start Real Camera Scanner with 1D Barcode + 2D QR Code support
  const startCameraScanner = async () => {
    setCameraError(null);
    setIsCameraActive(true);

    try {
      setTimeout(async () => {
        try {
          if (html5QrcodeRef.current) {
            await html5QrcodeRef.current.stop().catch(() => {});
          }

          const html5Qrcode = new Html5Qrcode('reader-canvas', {
            formatsToSupport: [
              Html5QrcodeSupportedFormats.CODE_128,
              Html5QrcodeSupportedFormats.CODE_39,
              Html5QrcodeSupportedFormats.EAN_13,
              Html5QrcodeSupportedFormats.EAN_8,
              Html5QrcodeSupportedFormats.UPC_A,
              Html5QrcodeSupportedFormats.UPC_E,
              Html5QrcodeSupportedFormats.QR_CODE,
              Html5QrcodeSupportedFormats.ITF,
            ],
            verbose: false,
          });
          html5QrcodeRef.current = html5Qrcode;

          await html5Qrcode.start(
            { facingMode: 'environment' },
            {
              fps: 20,
              qrbox: (vfWidth, vfHeight) => ({
                width: Math.min(vfWidth * 0.88, 320),
                height: Math.min(vfHeight * 0.55, 160),
              }),
              aspectRatio: 1.333,
            },
            (decodedText) => {
              handleProcessCode(decodedText);
            },
            () => {
              // Frame scan noise - silent ignore
            }
          );
        } catch (err: unknown) {
          console.error('Camera scan error:', err);
          setIsCameraActive(false);
          const msg = err instanceof Error ? err.message : String(err);
          setCameraError(
            msg.includes('NotAllowedError') || msg.includes('Permission')
              ? 'Chưa được cấp quyền truy cập Camera trình duyệt.'
              : 'Không thể khởi động camera. Vui lòng kiểm tra webcam hoặc sử dụng súng quét / nhập mã bên dưới.'
          );
        }
      }, 150);
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : String(e);
      setCameraError(msg);
      setIsCameraActive(false);
    }
  };

  const stopCameraScanner = async () => {
    if (html5QrcodeRef.current) {
      try {
        await html5QrcodeRef.current.stop();
        html5QrcodeRef.current.clear();
      } catch {
        // ignore stop errors
      }
      html5QrcodeRef.current = null;
    }
    setIsCameraActive(false);
  };

  useEffect(() => {
    if (isOpen) {
      setScannedResult(null);
      setCameraError(null);
      // Auto-focus manual input for USB barcode scanner
      setTimeout(() => {
        inputRef.current?.focus();
      }, 200);
    } else {
      stopCameraScanner();
    }

    return () => {
      stopCameraScanner();
    };
  }, [isOpen]);

  // Handle Manual Form Submit or USB Barcode Gun Enter
  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualCode.trim()) return;
    handleProcessCode(manualCode);
    setManualCode('');
  };

  // Find matching order using flexible barcode logic
  const matchedOrder = scannedResult
    ? orders.find((o) => {
        const raw = scannedResult.trim().toUpperCase().replace(/[\r\n]/g, '');
        const rawAlpha = raw.replace(/[^A-Z0-9]/g, '');
        const tCode = o.trackingCode.toUpperCase();
        const oCode = o.orderCode.toUpperCase();
        const tAlpha = tCode.replace(/[^A-Z0-9]/g, '');
        const oAlpha = oCode.replace(/[^A-Z0-9]/g, '');
        const pName = (o.productName || '').toUpperCase();

        return (
          raw === tCode ||
          raw === oCode ||
          (rawAlpha.length > 0 && (rawAlpha === tAlpha || rawAlpha === oAlpha)) ||
          raw.includes(tCode) ||
          raw.includes(oCode) ||
          tCode.includes(raw) ||
          oCode.includes(raw) ||
          (pName.length > 0 && pName.includes(raw))
        );
      })
    : null;

  return (
    <Modal
      isOpen={isOpen}
      onClose={() => {
        stopCameraScanner();
        onClose();
      }}
      title="Quét Mã Vạch / Mã Vận Đơn Bàn Giao"
      maxWidth="max-w-md"
    >
      <div className="space-y-4">
        {/* Camera Container */}
        <div className="relative rounded-2xl overflow-hidden bg-slate-950 aspect-4/3 flex flex-col items-center justify-center text-white border-2 border-slate-800 shadow-inner">
          <div
            id="reader-canvas"
            className={`w-full h-full object-cover ${!isCameraActive ? 'hidden' : 'block'}`}
          ></div>

          {!isCameraActive && (
            <div className="flex flex-col items-center gap-3 p-4 text-center z-10">
              <div className="relative">
                <div className="p-3 bg-[#FF6321]/20 rounded-2xl border border-[#FF6321]/40">
                  <Camera className="w-10 h-10 text-[#FF6321]" />
                </div>
              </div>
              <div>
                <h4 className="text-sm font-bold text-white">Quét Mã Bằng Camera Điện Thoại / Súng Quét USB</h4>
                <p className="text-xs text-slate-400 mt-1 max-w-[260px]">
                  Bật camera điện thoại/máy tính để tự động quét mã vạch 1D/2D hoặc cắm súng quét USB.
                </p>
              </div>

              <button
                type="button"
                onClick={startCameraScanner}
                className="px-4 py-2.5 bg-[#FF6321] hover:bg-[#e05318] text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center gap-2 active:scale-95"
              >
                <Camera className="w-4 h-4" /> Bật Camera Quét Mã (Điện thoại/PC)
              </button>

              {cameraError && (
                <div className="p-2 bg-rose-950/80 border border-rose-800 rounded-lg text-[11px] text-rose-300 flex items-center gap-1.5 mt-1">
                  <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                  <span>{cameraError}</span>
                </div>
              )}
            </div>
          )}

          {isCameraActive && (
            <div className="absolute bottom-3 left-3 right-3 flex justify-between items-center bg-slate-900/80 backdrop-blur-sm px-3 py-1.5 rounded-xl text-xs z-20 border border-slate-700">
              <span className="flex items-center gap-1.5 text-emerald-400 font-bold">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span> Camera đang quét...
              </span>
              <button
                onClick={stopCameraScanner}
                className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-[11px] font-bold"
              >
                Tắt Camera
              </button>
            </div>
          )}
        </div>

        {/* Quick Sample Buttons */}
        <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700">
          <div className="flex justify-between items-center mb-1.5">
            <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 flex items-center gap-1">
              <Volume2 className="w-3.5 h-3.5 text-[#FF6321]" /> Thử quét nhanh mã mẫu đơn hàng:
            </span>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {orders.slice(0, 4).map((ord) => (
              <button
                key={ord.id}
                type="button"
                onClick={() => handleProcessCode(ord.trackingCode)}
                className="text-[11px] bg-white dark:bg-slate-800 hover:bg-[#FF6321] text-slate-700 dark:text-slate-300 hover:text-white px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-700 font-mono font-bold transition-all shadow-2xs"
              >
                {ord.orderCode} ({ord.trackingCode})
              </button>
            ))}
          </div>
        </div>

        {/* Manual Barcode Input / Hardware USB Scanner Input */}
        <form onSubmit={handleManualSubmit} className="space-y-1">
          <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
            Súng quét mã vạch USB / Nhập mã thủ công:
          </label>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <QrCode className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                ref={inputRef}
                type="text"
                placeholder="Dùng súng bắn mã vạch hoặc nhập mã (VD: VND-20260730-001)..."
                value={manualCode}
                onChange={(e) => setManualCode(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 focus:border-[#FF6321] rounded-xl font-mono text-slate-800 dark:text-white focus:outline-hidden"
              />
            </div>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-bold text-white bg-[#FF6321] hover:bg-[#e05318] rounded-xl transition-all shadow-sm flex items-center gap-1 shrink-0"
            >
              <Search className="w-3.5 h-3.5" /> Tra cứu
            </button>
          </div>
        </form>

        {/* Scan Result Info Card */}
        {scannedResult && (
          <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border-2 border-emerald-500/40 space-y-2 animate-fade-in">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-emerald-700 dark:text-emerald-300 font-bold text-xs">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Mã nhận dạng được: <strong className="font-mono text-sm">{scannedResult}</strong></span>
              </div>
            </div>

            {matchedOrder ? (
              <div className="text-xs space-y-1.5 text-slate-700 dark:text-slate-300 pt-2 border-t border-emerald-200 dark:border-emerald-800/60">
                <div className="flex justify-between items-center font-bold">
                  <span className="text-[#FF6321] font-mono text-sm">{matchedOrder.orderCode} ({matchedOrder.trackingCode})</span>
                  <span className="text-emerald-600 font-mono text-sm">
                    {(matchedOrder.codAmount + (matchedOrder.shippingFee || 0)).toLocaleString('vi-VN')}đ
                  </span>
                </div>
                <p>
                  <strong className="text-slate-900 dark:text-white">Tên sản phẩm / Hàng hóa:</strong>{' '}
                  <span className="font-semibold text-emerald-800 dark:text-emerald-300">
                    {matchedOrder.productName || 'Hàng bưu kiện tiêu chuẩn (Đã cập nhật đầy đủ)'}
                  </span>
                </p>
                <p><strong className="text-slate-900 dark:text-white">Người nhận:</strong> {matchedOrder.recipientName} ({matchedOrder.recipientPhone})</p>
                <p><strong className="text-slate-900 dark:text-white">Địa chỉ:</strong> {matchedOrder.recipientAddress}</p>
                <p><strong className="text-slate-900 dark:text-white">Trạng thái:</strong> <span className="px-2 py-0.5 rounded bg-emerald-100 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-200 font-bold">{matchedOrder.status}</span></p>
              </div>
            ) : (
              <p className="text-xs text-rose-600 font-semibold flex items-center gap-1 pt-1">
                <AlertCircle className="w-4 h-4 shrink-0" /> Không tìm thấy thông tin đơn hàng trùng khớp với mã này trên hệ thống.
              </p>
            )}
          </div>
        )}
      </div>
    </Modal>
  );
};

