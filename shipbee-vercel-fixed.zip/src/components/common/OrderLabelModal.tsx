import React from 'react';
import { Modal } from './Modal';
import { BarcodeComponent } from './BarcodeComponent';
import { Order } from '../../types';
import { formatVND, formatDateTime } from '../../utils/helpers';
import { Printer, Download, CheckCircle2, ShieldAlert, Tag, Package, MapPin, Phone, User, Building2 } from 'lucide-react';

interface OrderLabelModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: Order | null;
  isNewCreated?: boolean;
}

export const OrderLabelModal: React.FC<OrderLabelModalProps> = ({
  isOpen,
  onClose,
  order,
  isNewCreated = false,
}) => {
  if (!order) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={isNewCreated ? "🎉 Đã Tạo Đơn Hàng & In Mã Vạch Nhãn Vận Đơn" : "In Nhãn Vận Đơn & Mã Vạch Đơn Hàng"}
      maxWidth="max-w-xl"
    >
      <div className="space-y-5">
        {isNewCreated && (
          <div className="p-3 bg-[#FFF5F1] border border-[#FF6321]/40 rounded-xl flex items-center gap-3 text-xs">
            <CheckCircle2 className="w-5 h-5 text-[#FF6321] shrink-0" />
            <div>
              <p className="font-bold text-[#1F2937]">Tạo đơn thành công!</p>
              <p className="text-slate-600">Mã vận đơn <strong className="font-mono text-[#FF6321]">{order.trackingCode}</strong> đã được khởi tạo. Dưới đây là nhãn mã vạch dán kiện hàng.</p>
            </div>
          </div>
        )}

        {/* PRINTABLE SHIPPING LABEL CONTAINER */}
        <div className="print-area p-5 bg-white border-2 border-slate-900 rounded-xl shadow-inner text-slate-900 font-sans space-y-4">
          {/* Header LOGI-PRO */}
          <div className="flex justify-between items-center pb-3 border-b-2 border-slate-900">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 bg-[#FF6321] text-white rounded flex items-center justify-center font-black text-sm tracking-tighter">
                LP
              </div>
              <div>
                <h4 className="font-black text-base uppercase tracking-tight text-[#1F2937]">LOGI-PRO EXPRESS</h4>
                <p className="text-[10px] text-slate-500 font-semibold">DỊCH VỤ VẬN CHUYỂN TOÀN QUỐC</p>
              </div>
            </div>
            <div className="text-right">
              <span className="px-2 py-1 bg-slate-900 text-white font-black text-xs rounded uppercase tracking-wider">
                {order.area || 'NỘI THÀNH'}
              </span>
              {order.isPriority && (
                <span className="ml-1 px-2 py-1 bg-rose-600 text-white font-black text-xs rounded uppercase tracking-wider animate-pulse">
                  GIAO GẤP
                </span>
              )}
            </div>
          </div>

          {/* Barcode Code128 */}
          <div className="p-2 bg-slate-50 rounded-lg border border-slate-300 flex flex-col items-center justify-center">
            <BarcodeComponent
              value={order.trackingCode || order.orderCode}
              width={2.2}
              height={60}
              fontSize={14}
            />
            <p className="text-[11px] font-mono font-bold text-slate-600 mt-1">
              Mã Đơn: <strong className="text-slate-900">{order.orderCode}</strong>
            </p>
          </div>

          {/* Grid Sender / Recipient */}
          <div className="grid grid-cols-2 gap-3 text-xs border-b border-slate-300 pb-3">
            {/* Sender */}
            <div className="p-2.5 bg-slate-50 rounded border border-slate-200 space-y-1">
              <p className="font-bold uppercase text-[10px] text-slate-500 flex items-center gap-1">
                <Building2 className="w-3 h-3 text-[#FF6321]" /> Từ: KHO TỔNG LOGI-PRO
              </p>
              <p className="font-bold text-slate-800">Kho Hà Nội Hub 01</p>
              <p className="text-[11px] text-slate-600">Hotline: 1900 6868</p>
            </div>

            {/* Recipient */}
            <div className="p-2.5 bg-[#FFF5F1] rounded border border-[#FF6321]/30 space-y-1">
              <p className="font-bold uppercase text-[10px] text-[#FF6321] flex items-center gap-1">
                <User className="w-3 h-3" /> Đến (Người nhận):
              </p>
              <p className="font-extrabold text-[#1F2937] text-sm">{order.recipientName}</p>
              <p className="font-mono font-bold text-slate-800 flex items-center gap-1">
                <Phone className="w-3 h-3 text-slate-500" /> {order.recipientPhone}
              </p>
            </div>
          </div>

          {/* Full Address */}
          <div className="p-3 bg-slate-100 rounded-lg border border-slate-300 text-xs space-y-1">
            <p className="font-bold text-slate-500 uppercase text-[10px] flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5 text-rose-600" /> Địa Chỉ Giao Hàng Chi Tiết:
            </p>
            <p className="font-bold text-slate-900 text-sm leading-snug">
              {order.recipientAddress}
            </p>
          </div>

          {/* Package & COD Section */}
          <div className="grid grid-cols-2 gap-3">
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs space-y-1">
              <p className="font-bold text-slate-500 uppercase text-[10px] flex items-center gap-1">
                <Package className="w-3.5 h-3.5 text-slate-700" /> Nội Dung Hàng Hóa:
              </p>
              <p className="font-bold text-slate-900">{order.productName || 'Hàng hóa bưu gửi'}</p>
              <p className="text-[11px] text-slate-600">Số lượng: <strong>{order.quantity || 1}</strong></p>
              {order.notes && (
                <p className="text-[10px] text-amber-800 bg-amber-50 p-1 rounded border border-amber-200 font-medium italic mt-1">
                  Ghi chú: {order.notes}
                </p>
              )}
            </div>

            {/* COD & Shipping Fee Amount */}
            <div className="p-3 bg-slate-900 text-white rounded-lg flex flex-col justify-center items-center text-center space-y-1">
              <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400">
                TỔNG THU CỦA KHÁCH
              </span>
              <p className="text-xl font-mono font-black text-amber-400 tracking-tight">
                {formatVND(order.codAmount + (order.shippingFee || 0))}
              </p>
              <div className="text-[10px] text-slate-200 font-medium flex flex-col items-center border-t border-slate-700 pt-1 w-full mt-1">
                <p>Tiền hàng COD: <strong className="text-amber-300">{formatVND(order.codAmount)}</strong></p>
                <p>Cước phí ship: <strong className="text-amber-300">{formatVND(order.shippingFee || 0)}</strong></p>
              </div>
              <p className="text-[9px] text-emerald-400 font-extrabold uppercase mt-1">
                {order.codAmount + (order.shippingFee || 0) > 0 ? 'XẾ THU ĐÚNG TỔNG TIỀN TRÊN' : 'ĐÃ THANH TOÁN (KHÔNG THU MẶT)'}
              </p>
            </div>
          </div>

          {/* Footer Warning / QR Note */}
          <div className="flex justify-between items-center text-[10px] text-slate-500 pt-2 border-t border-slate-200">
            <span>Ngày tạo: {formatDateTime(order.createdAt)}</span>
            <span className="font-bold text-slate-700">Quy định: Cho xem hàng, không thử</span>
          </div>
        </div>

        {/* ACTION BUTTONS */}
        <div className="flex items-center justify-between pt-2">
          <p className="text-xs text-slate-500 italic">
            *Nhấn "In Nhãn & Mã Vạch" để mở trình in nhiệt hoặc máy in A6 standard.
          </p>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2.5 text-xs font-bold text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 rounded-lg transition-all"
            >
              Đóng
            </button>
            <button
              onClick={handlePrint}
              className="px-5 py-2.5 text-xs font-bold text-white bg-[#FF6321] hover:bg-[#e05318] rounded-lg shadow-sm transition-all flex items-center gap-1.5"
            >
              <Printer className="w-4 h-4" /> In Nhãn & Mã Vạch
            </button>
          </div>
        </div>
      </div>
    </Modal>
  );
};
