import React, { useState } from 'react';
import {
  Truck,
  Shield,
  UserCheck,
  Bell,
  Sun,
  Moon,
  RotateCcw,
  FileCode2,
  ChevronDown,
  CheckCircle,
  X,
  User as UserIcon,
  QrCode,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { TechDocsModal } from './TechDocsModal';
import { formatDateTime } from '../../utils/helpers';

interface HeaderProps {
  onOpenScanner?: () => void;
  onOpenTechDocs?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenScanner, onOpenTechDocs }) => {
  const {
    currentUser,
    users,
    switchUser,
    notifications,
    markNotificationRead,
    theme,
    toggleTheme,
    resetDemoData,
  } = useApp();

  const [showRoleDropdown, setShowRoleDropdown] = useState(false);
  const [showNotifDrawer, setShowNotifDrawer] = useState(false);
  const [showDocsModal, setShowDocsModal] = useState(false);

  if (!currentUser) return null;

  const userNotifs = notifications.filter(
    (n) => n.userId === currentUser.id || n.userId === 'ALL' || (currentUser.role === 'ADMIN' && n.userId === 'usr_admin')
  );
  const unreadCount = userNotifs.filter((n) => !n.read).length;

  const getRoleBadge = (role: string) => {
    switch (role) {
      case 'ADMIN':
        return { label: 'ADMIN', bg: 'bg-[#1F2937] text-white font-bold' };
      case 'MANAGER':
        return { label: 'QUẢN LÝ', bg: 'bg-[#FF6321] text-white font-bold' };
      case 'DRIVER':
        return { label: 'XẾ', bg: 'bg-emerald-600 text-white font-bold' };
      default:
        return { label: role, bg: 'bg-slate-600 text-white' };
    }
  };

  const activeBadge = getRoleBadge(currentUser.role);

  return (
    <>
      <header className="sticky top-0 z-40 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          {/* Brand Logo */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-[#FF6321] rounded-lg flex items-center justify-center shadow-sm">
              <div className="w-5 h-5 border-2 border-white rounded-sm rotate-45 flex items-center justify-center">
                <Truck className="w-3.5 h-3.5 text-white -rotate-45" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-xl tracking-tight text-[#FF6321]">LOGI-PRO</span>
                <span className="hidden sm:inline-block px-2 py-0.5 text-[10px] font-bold uppercase bg-[#FFF5F1] text-[#FF6321] border border-[#FF6321]/30 rounded-md">
                  GiaoHàng System
                </span>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 hidden md:block">
                Hệ thống Quản lý Bàn giao Đơn hàng & Đối soát COD
              </p>
            </div>
          </div>

          {/* Center Actions / Role Switcher Demo Control */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Demo Account Switcher Dropdown */}
            <div className="relative">
              <button
                onClick={() => setShowRoleDropdown(!showRoleDropdown)}
                className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 text-xs font-semibold transition-colors border border-slate-200 dark:border-slate-700"
              >
                <span className={`px-2 py-0.5 rounded-md text-[10px] ${activeBadge.bg}`}>
                  {activeBadge.label}
                </span>
                <span className="max-w-[100px] sm:max-w-[140px] truncate">{currentUser.fullName}</span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </button>

              {showRoleDropdown && (
                <div
                  className="absolute right-0 mt-2 w-72 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 p-2 z-50 text-xs animate-in fade-in zoom-in-95 duration-100"
                  onClick={() => setShowRoleDropdown(false)}
                >
                  <div className="px-3 py-2 text-[11px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-100 dark:border-slate-800 mb-1">
                    Chuyển tài khoản Demo (Role Switch)
                  </div>
                  <div className="space-y-1 max-h-72 overflow-y-auto">
                    {users.map((u) => {
                      const badge = getRoleBadge(u.role);
                      const isSelected = u.id === currentUser.id;
                      return (
                        <button
                          key={u.id}
                          onClick={() => switchUser(u.id)}
                          className={`w-full flex items-center justify-between p-2 rounded-xl transition-colors text-left ${
                            isSelected
                              ? 'bg-amber-50 dark:bg-amber-950/40 text-amber-900 dark:text-amber-200 font-bold'
                              : 'hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300'
                          }`}
                        >
                          <div className="flex items-center gap-2.5 truncate">
                            <img
                              src={u.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=80'}
                              alt=""
                              className="w-7 h-7 rounded-full object-cover border border-slate-300 dark:border-slate-700"
                            />
                            <div className="truncate">
                              <p className="truncate text-xs font-semibold">{u.fullName}</p>
                              <p className="text-[10px] text-slate-400">@{u.username}</p>
                            </div>
                          </div>
                          <span className={`px-2 py-0.5 rounded text-[9px] ${badge.bg}`}>
                            {badge.label}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            {/* Scan Barcode / Camera Button */}
            {onOpenScanner && (
              <button
                onClick={onOpenScanner}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-[#FF6321] hover:bg-[#e05318] text-white rounded-xl text-xs font-bold shadow-sm transition-all"
                title="Mở Camera điện thoại / máy tính quét mã vạch"
              >
                <QrCode className="w-4 h-4" />
                <span className="hidden sm:inline">Quét Mã</span>
              </button>
            )}

            {/* Docs Button */}
            <button
              onClick={() => onOpenTechDocs ? onOpenTechDocs() : setShowDocsModal(true)}
              className="p-2 text-slate-600 dark:text-slate-300 hover:text-amber-600 dark:hover:text-amber-400 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors hidden md:flex items-center gap-1.5 text-xs font-medium"
              title="Xem Sơ đồ hệ thống & Tài liệu kỹ thuật"
            >
              <FileCode2 className="w-4 h-4 text-amber-500" />
              <span>Sơ đồ hệ thống</span>
            </button>

            {/* Notifications Bell */}
            <div className="relative">
              <button
                onClick={() => setShowNotifDrawer(!showNotifDrawer)}
                className="relative p-2 text-slate-600 dark:text-slate-300 hover:text-amber-600 dark:hover:text-amber-400 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                <Bell className="w-5 h-5" />
                {unreadCount > 0 && (
                  <span className="absolute top-1 right-1 w-4 h-4 bg-rose-500 text-white rounded-full text-[10px] font-black flex items-center justify-center animate-pulse">
                    {unreadCount}
                  </span>
                )}
              </button>

              {/* Notifications Popup Drawer */}
              {showNotifDrawer && (
                <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 p-4 z-50 text-xs">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 mb-2">
                    <h4 className="font-bold text-slate-900 dark:text-white flex items-center gap-2">
                      <Bell className="w-4 h-4 text-amber-500" /> Thông báo ({userNotifs.length})
                    </h4>
                    <button
                      onClick={() => setShowNotifDrawer(false)}
                      className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="space-y-2 max-h-80 overflow-y-auto">
                    {userNotifs.length === 0 ? (
                      <p className="text-center py-6 text-slate-400">Không có thông báo mới</p>
                    ) : (
                      userNotifs.map((n) => (
                        <div
                          key={n.id}
                          onClick={() => markNotificationRead(n.id)}
                          className={`p-3 rounded-xl border transition-colors cursor-pointer ${
                            !n.read
                              ? 'bg-amber-50/60 dark:bg-amber-950/30 border-amber-200 dark:border-amber-800/50'
                              : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800'
                          }`}
                        >
                          <div className="flex justify-between items-start">
                            <span className="font-bold text-slate-900 dark:text-white">{n.title}</span>
                            <span className="text-[10px] text-slate-400">{formatDateTime(n.createdAt)}</span>
                          </div>
                          <p className="text-[11px] text-slate-600 dark:text-slate-300 mt-1">{n.message}</p>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Theme Toggle */}
            <button
              onClick={toggleTheme}
              className="p-2 text-slate-600 dark:text-slate-300 hover:text-amber-600 dark:hover:text-amber-400 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              title="Thao tác chuyển Chế độ Sáng / Tối"
            >
              {theme === 'dark' ? <Sun className="w-5 h-5 text-amber-400" /> : <Moon className="w-5 h-5 text-slate-600" />}
            </button>

            {/* Reset Data Button */}
            <button
              onClick={() => {
                if (confirm('Khôi phục dữ liệu mẫu ban đầu (Reset Demo Data)?')) {
                  resetDemoData();
                }
              }}
              className="p-2 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              title="Reset dữ liệu demo ban đầu"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Tech Docs Modal */}
      <TechDocsModal isOpen={showDocsModal} onClose={() => setShowDocsModal(false)} />
    </>
  );
};
