import React, { useEffect, useRef, useState } from 'react';
import JsBarcode from 'jsbarcode';

interface BarcodeComponentProps {
  value: string;
  format?: string;
  width?: number;
  height?: number;
  fontSize?: number;
  displayValue?: boolean;
  className?: string;
}

export const BarcodeComponent: React.FC<BarcodeComponentProps> = ({
  value,
  format = 'CODE128',
  width = 2,
  height = 60,
  fontSize = 14,
  displayValue = true,
  className = '',
}) => {
  const svgRef = useRef<SVGSVGElement | null>(null);
  const [hasError, setHasError] = useState(false);

  useEffect(() => {
    setHasError(false);
    if (svgRef.current && value) {
      try {
        // Sanitize string for CODE128
        const sanitized = value.trim().replace(/[^\x00-\x7F]/g, '');
        JsBarcode(svgRef.current, sanitized || value, {
          format: format,
          width: width,
          height: height,
          displayValue: displayValue,
          fontSize: fontSize,
          font: 'monospace',
          fontOptions: 'bold',
          textMargin: 6,
          margin: 12, // Sufficient quiet zone for 1D optical scanners
          background: '#ffffff',
          lineColor: '#000000',
          valid: (valid) => {
            if (!valid) setHasError(true);
          },
        });
      } catch (err) {
        console.error('Error rendering barcode:', err);
        setHasError(true);
      }
    }
  }, [value, format, width, height, fontSize, displayValue]);

  return (
    <div className={`flex flex-col items-center justify-center p-1 bg-white rounded-lg border border-slate-200 shadow-2xs ${className}`}>
      <svg ref={svgRef} className="max-w-full h-auto block"></svg>
      {hasError && (
        <span className="text-xs font-mono font-bold text-slate-800 mt-1 px-2 py-0.5 bg-slate-100 rounded">
          {value}
        </span>
      )}
    </div>
  );
};

