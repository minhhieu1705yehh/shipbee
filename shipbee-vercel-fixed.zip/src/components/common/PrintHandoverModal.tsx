import React from 'react';
import { Printer, Download, CheckCircle, Clock, AlertTriangle } from 'lucide-react';
import { Modal } from './Modal';
import { HandoverSheet } from '../../types';
import { useApp } from '../../context/AppContext';
import { formatVND, formatDateTime, getHandoverSheetStatusMeta } from '../../utils/helpers';
import { exportHandoverSheetToExcel } from '../../utils/export';

interface PrintHandoverModalProps {
  sheet: HandoverSheet | null;
  isOpen: boolean;
  onClose: () => void;
}

export const PrintHandoverModal: React.FC<PrintHandoverModalProps> = ({ sheet, isOpen, onClose }) => {
  const { orders } = useApp();

  if (!sheet) return null;

  const sheetOrders = orders.filter((o) => sheet.orderIds.includes(o.id));
  const statusMeta = getHandoverSheetStatusMeta(sheet.status);

  const handlePrint = () => {
    window.print();
  };

  const handleExportExcel = () => {
    exportHandoverSheetToExcel(sheet, orders);
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={`Phiếu Bàn Giao Điện Tử ${sheet.sheetCode}`} maxWidth="max-w-3xl">
      <div className="space-y-6">
        {/* Printable Area */}
        <div id="printable-sheet" className="p-6 bg-white text-slate-900 border border-slate-300 rounded-xl space-y-5">
          {/* Header */}
          <div className="flex justify-between items-start border-b border-slate-200 pb-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="bg-amber-600 text-white font-black text-xs px-2 py-0.5 rounded-sm">GHPRO</span>
                <h2 className="text-xl font-bold tracking-tight text-slate-900">PHIẾU BÀN GIAO ĐƠN HÀNG</h2>
              </div>
              <p className="text-xs text-slate-500 mt-1">Hệ thống bàn giao & đối soát nội bộ - Đơn vị vận chuyển</p>
            </div>
            <div className="text-right">
              <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold border ${statusMeta.badgeClass}`}>
                {statusMeta.label}
              </span>
              <p className="text-xs text-slate-500 mt-1">Mã phiếu: <strong className="text-slate-800">{sheet.sheetCode}</strong></p>
            </div>
          </div>

          {/* Info grid */}
          <div className="grid grid-cols-2 gap-4 text-xs bg-slate-50 p-4 rounded-lg border border-slate-200">
            <div>
              <p><span className="text-slate-500">Quản lý bàn giao:</span> <strong>{sheet.managerName}</strong></p>
              <p><span className="text-slate-500">Xế tiếp nhận:</span> <strong>{sheet.driverName}</strong></p>
              <p><span className="text-slate-500">Thời gian khởi tạo:</span> {formatDateTime(sheet.createdAt)}</p>
            </div>
            <div>
              <p><span className="text-slate-500">Tổng số đơn:</span> <strong className="text-amber-700">{sheet.totalOrders} đơn</strong></p>
              <p><span className="text-slate-500">Tổng tiền COD:</span> <strong className="text-emerald-700">{formatVND(sheet.totalCodAmount)}</strong></p>
              <p><span className="text-slate-500">Thời gian Xế xác nhận:</span> {sheet.acceptedAt ? formatDateTime(sheet.acceptedAt) : 'Chờ xác nhận'}</p>
            </div>
          </div>

          {/* Digital Signature Audit */}
          {sheet.acceptedAt && (
            <div className="text-xs p-3 bg-emerald-50 border border-emerald-200 rounded-lg flex items-center justify-between text-emerald-800">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-600" />
                <span>Đã xác thực chữ ký điện tử Xế</span>
              </div>
              <span className="text-[11px] text-emerald-700">Thiết bị: {sheet.acceptanceDevice || 'Mobile'}</span>
            </div>
          )}

          {/* Discrepancy Note */}
          {sheet.hasDiscrepancy && (
            <div className="text-xs p-3 bg-rose-50 border border-rose-200 rounded-lg flex items-center gap-2 text-rose-800">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
              <span><strong>Cảnh báo sai lệch:</strong> {sheet.discrepancyNote}</span>
            </div>
          )}

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="bg-slate-100 text-slate-700 border-b border-slate-200">
                  <th className="py-2 px-2 border-r border-slate-200 w-8">STT</th>
                  <th className="py-2 px-2 border-r border-slate-200">Mã đơn / Vận đơn</th>
                  <th className="py-2 px-2 border-r border-slate-200">Khách hàng & SĐT</th>
                  <th className="py-2 px-2 border-r border-slate-200">Địa chỉ giao hàng</th>
                  <th className="py-2 px-2 border-r border-slate-200 text-right">COD</th>
                  <th className="py-2 px-2 border-r border-slate-200 text-right">Phí Ship</th>
                  <th className="py-2 px-2 border-r border-slate-200 text-right">Tổng Cần Thu</th>
                  <th className="py-2 px-2">Xác nhận</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {sheetOrders.map((ord, idx) => (
                  <tr key={ord.id} className="hover:bg-slate-50">
                    <td className="py-2 px-2 border-r border-slate-200 text-center font-medium">{idx + 1}</td>
                    <td className="py-2 px-2 border-r border-slate-200">
                      <p className="font-bold text-slate-900">{ord.orderCode}</p>
                      <p className="text-[10px] text-slate-500">{ord.trackingCode}</p>
                    </td>
                    <td className="py-2 px-2 border-r border-slate-200">
                      <p className="font-medium text-slate-900">{ord.recipientName}</p>
                      <p className="text-slate-500">{ord.recipientPhone}</p>
                    </td>
                    <td className="py-2 px-2 border-r border-slate-200 max-w-[180px] truncate">{ord.recipientAddress}</td>
                    <td className="py-2 px-2 border-r border-slate-200 text-right font-medium text-slate-700">
                      {formatVND(ord.codAmount)}
                    </td>
                    <td className="py-2 px-2 border-r border-slate-200 text-right font-medium text-slate-700">
                      {formatVND(ord.shippingFee || 0)}
                    </td>
                    <td className="py-2 px-2 border-r border-slate-200 text-right font-bold text-slate-900">
                      {formatVND(ord.codAmount + (ord.shippingFee || 0))}
                    </td>
                    <td className="py-2 px-2 text-center text-slate-400">
                      [ &nbsp; ]
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="bg-amber-50 font-bold text-slate-900 border-t-2 border-amber-300">
                  <td colSpan={4} className="py-2 px-3 text-right">TỔNG CỘNG ({sheetOrders.length} ĐƠN):</td>
                  <td className="py-2 px-2 text-right text-slate-800">{formatVND(sheetOrders.reduce((sum, o) => sum + o.codAmount, 0))}</td>
                  <td className="py-2 px-2 text-right text-slate-800">{formatVND(sheetOrders.reduce((sum, o) => sum + (o.shippingFee || 0), 0))}</td>
                  <td className="py-2 px-2 text-right text-amber-800 font-extrabold">{formatVND(sheet.totalCodAmount)}</td>
                  <td></td>
                </tr>
              </tfoot>
            </table>
          </div>

          {/* Signatures */}
          <div className="grid grid-cols-2 gap-8 text-center text-xs pt-4 border-t border-slate-200">
            <div>
              <p className="font-bold text-slate-800 uppercase">Quản lý bàn giao</p>
              <p className="text-[11px] text-slate-400 italic">(Ký & ghi rõ họ tên)</p>
              <div className="h-16 flex items-center justify-center font-serif text-slate-600 italic">{sheet.managerName}</div>
            </div>
            <div>
              <p className="font-bold text-slate-800 uppercase">Xế tiếp nhận</p>
              <p className="text-[11px] text-slate-400 italic">(Ký & ghi rõ họ tên)</p>
              <div className="h-16 flex items-center justify-center font-serif text-slate-600 italic">
                {sheet.acceptedAt ? `${sheet.driverName} (Đã xác nhận e-sign)` : 'Chờ Xế xác nhận'}
              </div>
            </div>
          </div>
        </div>

        {/* Modal Action buttons */}
        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            onClick={handleExportExcel}
            className="px-4 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors flex items-center gap-1.5"
          >
            <Download className="w-4 h-4" /> Xuất Excel Phiếu
          </button>
          <button
            onClick={handlePrint}
            className="px-5 py-2 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-lg transition-colors flex items-center gap-1.5 shadow-sm"
          >
            <Printer className="w-4 h-4" /> In Phiếu Bàn Giao
          </button>
        </div>
      </div>
    </Modal>
  );
};
