import React, { useState } from 'react';
import { DollarSign, CheckCircle2, RotateCcw, ShieldCheck, AlertCircle, Eye, FileCheck } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { formatVND, formatDateTime } from '../../utils/helpers';
import { Modal } from '../common/Modal';

export const DriverReconciliation: React.FC = () => {
  const { currentUser, codDeposits, confirmCodDeposit, handoverSheets, reconcileHandoverSheet, orders, users } = useApp();

  const [selectedProofUrl, setSelectedProofUrl] = useState<string | null>(null);

  const myDeposits = codDeposits.filter((d) => d.managerId === currentUser?.id || currentUser?.role === 'ADMIN');
  const mySheets = handoverSheets.filter((s) => s.managerId === currentUser?.id || currentUser?.role === 'ADMIN');

  const pendingDeposits = myDeposits.filter((d) => d.status === 'CHO_XAC_NHAN');
  const confirmedDeposits = myDeposits.filter((d) => d.status === 'DA_XAC_NHAN');

  const pendingReconcileSheets = mySheets.filter((s) => s.status === 'CHO_DOI_SOAT' || s.status === 'DANG_GIAO_HANG');

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Header */}
      <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <ShieldCheck className="w-6 h-6 text-emerald-500" /> Quản Lý Tiền COD & Đối Soát Cuối Ca
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          Xác nhận các khoản nộp tiền COD từ Xế, đối soát đơn hoàn/giao thất bại và chốt số liệu không thể sửa đổi.
        </p>
      </div>

      {/* Grid: COD Deposits list & Handover Sheets Reconciliation */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: Pending COD Deposit Confirmation */}
        <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-amber-500" /> Xác Nhận Phiếu Nộp COD Từ Xế ({pendingDeposits.length})
            </h3>
            <span className="px-2 py-0.5 bg-amber-100 text-amber-800 text-[10px] font-bold rounded-md">
              Chờ Quản Lý duyệt
            </span>
          </div>

          <div className="space-y-3 max-h-96 overflow-y-auto">
            {pendingDeposits.length === 0 ? (
              <p className="text-center py-8 text-slate-400 text-xs">Không có yêu cầu nộp tiền COD nào đang chờ duyệt</p>
            ) : (
              pendingDeposits.map((dep) => (
                <div key={dep.id} className="p-4 bg-amber-50/60 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-2xl space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-bold text-slate-900 dark:text-white text-sm">{dep.driverName}</p>
                      <p className="text-[10px] text-slate-400">Mã nộp: {dep.depositCode} • {formatDateTime(dep.createdAt)}</p>
                    </div>
                    <span className="text-lg font-black text-emerald-600 dark:text-emerald-400">
                      {formatVND(dep.amount)}
                    </span>
                  </div>

                  {dep.note && (
                    <p className="text-xs text-slate-600 dark:text-slate-300 italic">
                      "Ghi chú Xế: {dep.note}"
                    </p>
                  )}

                  <div className="flex items-center justify-between pt-2 border-t border-amber-200/60 dark:border-amber-800/60">
                    {dep.proofImageUrl ? (
                      <button
                        onClick={() => setSelectedProofUrl(dep.proofImageUrl!)}
                        className="text-xs text-blue-600 dark:text-blue-400 font-semibold hover:underline flex items-center gap-1"
                      >
                        <Eye className="w-3.5 h-3.5" /> Xem biên nhận
                      </button>
                    ) : (
                      <span className="text-[11px] text-slate-400 italic">Nộp tiền mặt</span>
                    )}

                    <button
                      onClick={() => {
                        confirmCodDeposit(dep.id);
                        alert(`Đã xác nhận thu ${formatVND(dep.amount)} từ Xế ${dep.driverName}!`);
                      }}
                      className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center gap-1.5"
                    >
                      <CheckCircle2 className="w-4 h-4" /> Xác Nhận Đã Nhận Tiền
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Right: Handover Sheets Final Reconciliation */}
        <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <FileCheck className="w-5 h-5 text-amber-500" /> Đối Soát Chốt Phiếu Bàn Giao
            </h3>
          </div>

          <div className="space-y-3 max-h-96 overflow-y-auto">
            {pendingReconcileSheets.length === 0 ? (
              <p className="text-center py-8 text-slate-400 text-xs">Không có phiếu bàn giao nào chờ đối soát</p>
            ) : (
              pendingReconcileSheets.map((sheet) => {
                const sheetOrders = orders.filter((o) => sheet.orderIds.includes(o.id));
                const delivered = sheetOrders.filter((o) => o.status === 'GIAO_THANH_CONG' || o.status === 'DA_NOP_COD');
                const failed = sheetOrders.filter((o) => ['GIAO_THAT_BAI', 'KHANG_HEN_GIAO_LAI', 'KHANG_KHONG_NGHE', 'SAI_DIA_CHI', 'KHANG_TU_CHOI', 'DON_HOAN'].includes(o.status));

                return (
                  <div key={sheet.id} className="p-4 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-2xl space-y-3">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-bold text-slate-900 dark:text-white">{sheet.sheetCode}</p>
                        <p className="text-xs text-slate-500">Xế: <strong>{sheet.driverName}</strong></p>
                      </div>
                      <span className="text-xs font-black text-amber-600">{formatVND(sheet.totalCodAmount)}</span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs text-slate-600 dark:text-slate-300 bg-white dark:bg-slate-800 p-2 rounded-lg border border-slate-200 dark:border-slate-700">
                      <div>Giao xong: <strong className="text-emerald-600">{delivered.length}/{sheet.totalOrders} đơn</strong></div>
                      <div>Trả hàng / Thất bại: <strong className="text-rose-600">{failed.length} đơn</strong></div>
                    </div>

                    <button
                      onClick={() => {
                        reconcileHandoverSheet(sheet.id);
                        alert(`Đã hoàn tất đối soát và khóa số liệu cho phiếu ${sheet.sheetCode}!`);
                      }}
                      className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl transition-all shadow-md"
                    >
                      Xác Nhận Hoàn Tất Đối Soát Phiếu
                    </button>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>

      {/* Proof Image Modal */}
      <Modal isOpen={!!selectedProofUrl} onClose={() => setSelectedProofUrl(null)} title="Ảnh Biên Nhận Chuyển Khoản / Tiền Mặt">
        <div className="p-2 text-center space-y-3">
          <img src={selectedProofUrl || ''} alt="Biên nhận COD" className="max-h-96 mx-auto rounded-xl border border-slate-300 shadow-md" />
          <button
            onClick={() => setSelectedProofUrl(null)}
            className="px-5 py-2 bg-slate-800 text-white font-bold text-xs rounded-xl"
          >
            Đóng
          </button>
        </div>
      </Modal>
    </div>
  );
};
