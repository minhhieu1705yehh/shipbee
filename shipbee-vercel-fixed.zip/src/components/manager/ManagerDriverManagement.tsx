import React, { useState } from 'react';
import { UserPlus, Lock, Unlock, Key, Shield, User, Smartphone, PlusCircle, Check, Users, Truck } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Modal } from '../common/Modal';

export const ManagerDriverManagement: React.FC = () => {
  const { currentUser, users, createAccount, toggleLockAccount, orders, addActivityLog } = useApp();

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [fullName, setFullName] = useState('');
  const [username, setUsername] = useState('');
  const [phone, setPhone] = useState('');

  if (!currentUser) return null;

  // Get drivers managed by current Manager
  const myDrivers = users.filter((u) => u.role === 'DRIVER' && u.managerId === currentUser.id);

  const handleCreateDriver = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName || !username || !phone) {
      alert('Vui lòng điền đầy đủ Họ tên, Username và Số điện thoại');
      return;
    }

    // Check existing username
    if (users.some((u) => u.username.toLowerCase() === username.trim().toLowerCase())) {
      alert('Tên đăng nhập này đã tồn tại trong hệ thống!');
      return;
    }

    createAccount({
      username: username.trim(),
      fullName: fullName.trim(),
      phone: phone.trim(),
      role: 'DRIVER',
      managerId: currentUser.id,
      avatarUrl: `https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80`,
    });

    setIsAddModalOpen(false);
    setFullName('');
    setUsername('');
    setPhone('');
    alert(`Đã tạo tài khoản Xế "${fullName}" thành công! Mật khẩu mặc định: 123456`);
  };

  const handleResetPassword = (driverId: string, driverName: string) => {
    addActivityLog('Đặt lại mật khẩu Xế', 'USER', driverId, `Quản lý ${currentUser.fullName} đặt lại mật khẩu cho Xế ${driverName} thành "123456"`);
    alert(`Đã đặt lại mật khẩu cho tài khoản Xế ${driverName} thành "123456"`);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-[#E5E7EB] dark:border-slate-800 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Users className="w-6 h-6 text-[#FF6321]" />
            <h2 className="text-xl font-bold text-[#1F2937] dark:text-white">Quản Lý Đội Ngũ Xế Giao Hàng</h2>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Quản lý tự tạo tài khoản Xế, cấp mật khẩu, khóa/mở khóa tài khoản Xế trực thuộc kho.
          </p>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="px-4 py-2.5 bg-[#FF6321] hover:bg-[#e05318] text-white font-bold text-xs rounded-xl transition-all shadow-sm flex items-center gap-2 shrink-0 active:scale-98"
        >
          <UserPlus className="w-4 h-4" /> Thêm Xế Giao Hàng Mới
        </button>
      </div>

      {/* Driver List Table */}
      <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-[#E5E7EB] dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-[#E5E7EB] dark:border-slate-800">
          <h3 className="font-bold text-sm text-[#1F2937] dark:text-white flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#FF6321]"></span> Danh Sách Xế Trực Thuộc ({myDrivers.length})
          </h3>
          <span className="text-xs text-slate-500 font-medium">Kho phụ trách: {currentUser.fullName}</span>
        </div>

        {myDrivers.length === 0 ? (
          <div className="py-12 text-center text-slate-400 text-xs space-y-2">
            <Truck className="w-10 h-10 mx-auto text-slate-300 dark:text-slate-700" />
            <p className="font-bold">Bạn chưa có Xế giao hàng nào trực thuộc.</p>
            <p>Bấm nút "Thêm Xế Giao Hàng Mới" ở trên để khởi tạo tài khoản cho Xế.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="border-b border-[#E5E7EB] dark:border-slate-800 text-slate-400 font-semibold uppercase text-[10px]">
                  <th className="py-3 px-3">Xế Giao Hàng</th>
                  <th className="py-3 px-3">Tài khoản & SĐT</th>
                  <th className="py-3 px-3 text-center">Đơn Đang Phụ Trách</th>
                  <th className="py-3 px-3 text-center">Đã Giao Xong</th>
                  <th className="py-3 px-3 text-center">Trạng Thái</th>
                  <th className="py-3 px-3 text-right">Thao Tác</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {myDrivers.map((driver) => {
                  const driverOrders = orders.filter((o) => o.driverId === driver.id);
                  const activeOrders = driverOrders.filter((o) => ['XE_DA_NHAN', 'DANG_DI_GIAO'].includes(o.status));
                  const completedOrders = driverOrders.filter((o) => o.status === 'GIAO_THANH_CONG' || o.status === 'DA_NOP_COD');

                  return (
                    <tr key={driver.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                      <td className="py-3 px-3">
                        <div className="flex items-center gap-3">
                          <img
                            src={driver.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150'}
                            alt=""
                            className="w-9 h-9 rounded-full object-cover border border-[#FF6321]/40"
                          />
                          <div>
                            <p className="font-bold text-[#1F2937] dark:text-white">{driver.fullName}</p>
                            <span className="text-[10px] text-slate-400">ID: {driver.id}</span>
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-3">
                        <div className="space-y-0.5">
                          <p className="font-mono font-bold text-[#FF6321]">@{driver.username}</p>
                          <p className="text-[#1F2937] dark:text-slate-300 font-medium">{driver.phone}</p>
                        </div>
                      </td>
                      <td className="py-3 px-3 text-center font-bold text-amber-600">
                        {activeOrders.length} đơn
                      </td>
                      <td className="py-3 px-3 text-center font-bold text-emerald-600">
                        {completedOrders.length} đơn
                      </td>
                      <td className="py-3 px-3 text-center">
                        {driver.isLocked ? (
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-100 text-rose-700 border border-rose-300">
                            Bị Khóa
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-700 border border-emerald-300">
                            Hoạt Động
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-3 text-right space-x-1">
                        <button
                          onClick={() => handleResetPassword(driver.id, driver.fullName)}
                          className="px-2.5 py-1 text-[11px] font-bold text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 rounded-lg transition-all"
                          title="Đặt lại mật khẩu thành 123456"
                        >
                          Reset Pass
                        </button>
                        <button
                          onClick={() => toggleLockAccount(driver.id)}
                          className={`px-2.5 py-1 text-[11px] font-bold rounded-lg transition-all ${
                            driver.isLocked
                              ? 'bg-emerald-600 text-white hover:bg-emerald-700'
                              : 'bg-rose-100 text-rose-700 hover:bg-rose-200'
                          }`}
                        >
                          {driver.isLocked ? 'Mở Khóa' : 'Khóa'}
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Modal Add New Driver */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title="Thêm Xế Giao Hàng Mới (Trực Thuộc Kho)"
        maxWidth="max-w-md"
      >
        <form onSubmit={handleCreateDriver} className="space-y-4 text-xs">
          <div className="p-3 bg-[#FFF5F1] rounded-xl border border-[#FF6321]/30 text-slate-700">
            <p className="font-bold text-[#FF6321] text-xs mb-1">Ghi chú quản lý:</p>
            <p>Tài khoản Xế được tạo ở đây sẽ tự động liên kết trực tiếp dưới sự quản lý của <strong>{currentUser.fullName}</strong>. Mật khẩu mặc định khởi tạo là: <strong className="font-mono text-[#FF6321]">123456</strong>.</p>
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Họ và Tên Xế (*)</label>
            <input
              type="text"
              required
              placeholder="VD: Nguyễn Văn Nam (Đội Xế Lộc Hà)"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              className="w-full px-3 py-2 border border-[#E5E7EB] rounded-lg focus:outline-none focus:border-[#FF6321] dark:bg-slate-800 dark:text-white"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Tên Đăng Nhập / Username (*)</label>
            <input
              type="text"
              required
              placeholder="VD: xelocha1"
              value={username}
              onChange={(e) => setUsername(e.target.value.toLowerCase().replace(/\s+/g, ''))}
              className="w-full px-3 py-2 border border-[#E5E7EB] rounded-lg focus:outline-none focus:border-[#FF6321] font-mono dark:bg-slate-800 dark:text-white"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Số Điện Thoại (*)</label>
            <input
              type="text"
              required
              placeholder="VD: 0987654321"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full px-3 py-2 border border-[#E5E7EB] rounded-lg focus:outline-none focus:border-[#FF6321] font-mono dark:bg-slate-800 dark:text-white"
            />
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-[#E5E7EB]">
            <button
              type="button"
              onClick={() => setIsAddModalOpen(false)}
              className="px-4 py-2 text-slate-600 bg-slate-100 hover:bg-slate-200 font-bold rounded-lg"
            >
              Hủy
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-white bg-[#FF6321] hover:bg-[#e05318] font-bold rounded-lg shadow-sm"
            >
              Tạo Tài Khoản Xế
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
