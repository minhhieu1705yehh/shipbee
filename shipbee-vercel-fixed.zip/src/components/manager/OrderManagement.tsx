import React, { useState } from 'react';
import {
  Plus,
  FileSpreadsheet,
  QrCode,
  Search,
  Trash2,
  Edit,
  CheckSquare,
  Square,
  Package,
  Layers,
  MapPin,
  Upload,
  AlertCircle,
  Truck,
  Eye,
  Printer,
  Barcode,
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { useApp } from '../../context/AppContext';
import { Modal } from '../common/Modal';
import { ScannerModal } from '../common/ScannerModal';
import { OrderLabelModal } from '../common/OrderLabelModal';
import { formatVND, formatDateTime, getOrderStatusMeta, buildGoogleMapsUrl } from '../../utils/helpers';
import { Order, OrderStatus } from '../../types';

interface OrderManagementProps {
  onGoToHandoverWithOrders?: (orderIds: string[]) => void;
}

export const OrderManagement: React.FC<OrderManagementProps> = ({ onGoToHandoverWithOrders }) => {
  const { currentUser, orders, createOrder, batchCreateOrders, updateOrder, deleteOrder } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');
  const [selectedArea, setSelectedArea] = useState<string>('ALL');

  const [selectedOrderIds, setSelectedOrderIds] = useState<string[]>([]);

  // Modals
  const [isSingleModalOpen, setIsSingleModalOpen] = useState(false);
  const [isExcelModalOpen, setIsExcelModalOpen] = useState(false);
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [editingOrder, setEditingOrder] = useState<Order | null>(null);

  // Barcode Label Modal State
  const [labelModalOrder, setLabelModalOrder] = useState<Order | null>(null);
  const [isLabelModalNewCreated, setIsLabelModalNewCreated] = useState(false);

  // Single Order Form State
  const [orderCode, setOrderCode] = useState('');
  const [trackingCode, setTrackingCode] = useState('');
  const [recipientName, setRecipientName] = useState('');
  const [recipientPhone, setRecipientPhone] = useState('');
  const [recipientAddress, setRecipientAddress] = useState('');
  const [area, setArea] = useState('Cầu Giấy');
  const [codAmount, setCodAmount] = useState<number>(350000);
  const [shippingFee, setShippingFee] = useState<number>(30000);
  const [productName, setProductName] = useState('');
  const [quantity, setQuantity] = useState<number>(1);
  const [notes, setNotes] = useState('');
  const [labelImageUrl, setLabelImageUrl] = useState('https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=400&auto=format&fit=crop&q=80');
  const [isPriority, setIsPriority] = useState(false);

  // Excel Upload state
  const [excelDataPreview, setExcelDataPreview] = useState<any[]>([]);

  // Filter orders for current manager
  const myOrders = orders.filter((o) => o.managerId === currentUser?.id || currentUser?.role === 'ADMIN');

  // Unique areas
  const areasList = Array.from(new Set(myOrders.map((o) => o.area || 'Khác')));

  const filteredOrders = myOrders.filter((o) => {
    const matchesSearch =
      o.orderCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
      o.trackingCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
      o.recipientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      o.recipientPhone.includes(searchTerm) ||
      o.recipientAddress.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = selectedStatus === 'ALL' || o.status === selectedStatus;
    const matchesArea = selectedArea === 'ALL' || (o.area || 'Khác') === selectedArea;

    return matchesSearch && matchesStatus && matchesArea;
  });

  const handleSelectAll = () => {
    if (selectedOrderIds.length === filteredOrders.length) {
      setSelectedOrderIds([]);
    } else {
      setSelectedOrderIds(filteredOrders.map((o) => o.id));
    }
  };

  const handleToggleSelect = (id: string) => {
    if (selectedOrderIds.includes(id)) {
      setSelectedOrderIds(selectedOrderIds.filter((item) => item !== id));
    } else {
      setSelectedOrderIds([...selectedOrderIds, id]);
    }
  };

  const handleSingleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!recipientName || !recipientPhone || !recipientAddress) {
      alert('Vui lòng điền đầy đủ Tên, SĐT và Địa chỉ người nhận');
      return;
    }

    if (editingOrder) {
      updateOrder(editingOrder.id, {
        orderCode,
        trackingCode,
        recipientName,
        recipientPhone,
        recipientAddress,
        area,
        googleMapsUrl: buildGoogleMapsUrl(recipientAddress),
        codAmount,
        shippingFee,
        productName,
        quantity,
        notes,
        labelImageUrl,
        isPriority,
      });
      alert('Đã cập nhật đơn hàng!');
      resetSingleForm();
      setIsSingleModalOpen(false);
    } else {
      const newOrderCreated = createOrder({
        orderCode,
        trackingCode,
        recipientName,
        recipientPhone,
        recipientAddress,
        area,
        googleMapsUrl: buildGoogleMapsUrl(recipientAddress),
        codAmount,
        shippingFee,
        productName,
        quantity,
        notes,
        labelImageUrl,
        isPriority,
      });

      resetSingleForm();
      setIsSingleModalOpen(false);

      // Open Barcode Label Print Modal automatically for newly created order
      setLabelModalOrder(newOrderCreated);
      setIsLabelModalNewCreated(true);
    }
  };

  const resetSingleForm = () => {
    setEditingOrder(null);
    setOrderCode('');
    setTrackingCode('');
    setRecipientName('');
    setRecipientPhone('');
    setRecipientAddress('');
    setArea('Cầu Giấy');
    setCodAmount(350000);
    setShippingFee(30000);
    setProductName('');
    setQuantity(1);
    setNotes('');
    setIsPriority(false);
  };

  const handleOpenEdit = (ord: Order) => {
    setEditingOrder(ord);
    setOrderCode(ord.orderCode);
    setTrackingCode(ord.trackingCode);
    setRecipientName(ord.recipientName);
    setRecipientPhone(ord.recipientPhone);
    setRecipientAddress(ord.recipientAddress);
    setArea(ord.area || 'Cầu Giấy');
    setCodAmount(ord.codAmount);
    setShippingFee(ord.shippingFee);
    setProductName(ord.productName);
    setQuantity(ord.quantity);
    setNotes(ord.notes || '');
    setLabelImageUrl(ord.labelImageUrl || '');
    setIsPriority(ord.isPriority || false);
    setIsSingleModalOpen(true);
  };

  // Excel File Read
  const handleExcelFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      const bstr = evt.target?.result;
      const wb = XLSX.read(bstr, { type: 'binary' });
      const wsname = wb.SheetNames[0];
      const ws = wb.Sheets[wsname];
      const data = XLSX.utils.sheet_to_json(ws);
      setExcelDataPreview(data);
    };
    reader.readAsBinaryString(file);
  };

  const handleConfirmBatchUpload = () => {
    if (excelDataPreview.length === 0) {
      alert('Không có dữ liệu trong file Excel!');
      return;
    }

    const mappedOrders: Partial<Order>[] = excelDataPreview.map((row) => ({
      orderCode: row['Mã đơn'] || row['MaDon'] || `DH-${Math.floor(Math.random() * 8000 + 1000)}`,
      trackingCode: row['Mã vận đơn'] || row['MaVanDon'] || `VND-${Date.now()}`,
      recipientName: row['Tên người nhận'] || row['TenKhach'] || 'Khách Excel',
      recipientPhone: String(row['Số điện thoại'] || row['SDT'] || '0900000000'),
      recipientAddress: row['Địa chỉ'] || row['DiaChi'] || 'Hà Nội',
      area: row['Khu vực'] || row['KhuVuc'] || 'Cầu Giấy',
      productName: row['Sản phẩm'] || row['SanPham'] || 'Hàng hóa',
      codAmount: Number(row['Tiền COD'] || row['COD']) || 0,
      shippingFee: Number(row['Phí giao hàng'] || row['PhiShip']) || 30000,
      quantity: Number(row['Số lượng'] || row['SoLuong']) || 1,
      notes: row['Ghi chú'] || row['GhiChu'] || '',
    }));

    batchCreateOrders(mappedOrders);
    setIsExcelModalOpen(false);
    setExcelDataPreview([]);
    alert(`Đã nhập thành công ${mappedOrders.length} đơn hàng vào hệ thống!`);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Action Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Package className="w-6 h-6 text-amber-500" /> Quản Lý & Nhập Đơn Hàng ({myOrders.length})
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Tạo đơn thủ công, nhập lô file Excel, quét mã nhãn và chọn nhiều đơn để gom chuyến bàn giao.
          </p>
        </div>

        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setIsScannerOpen(true)}
            className="px-3.5 py-2.5 bg-white dark:bg-slate-800 hover:bg-gray-100 text-[#1F2937] dark:text-slate-100 font-bold text-xs rounded-lg transition-all flex items-center gap-1.5 border border-[#E5E7EB] dark:border-slate-700 shadow-sm"
          >
            <QrCode className="w-4 h-4 text-[#FF6321]" /> Quét Mã QR
          </button>
          <button
            onClick={() => setIsExcelModalOpen(true)}
            className="px-3.5 py-2.5 bg-white dark:bg-slate-800 hover:bg-gray-100 text-[#1F2937] font-bold text-xs rounded-lg transition-all border border-[#E5E7EB] shadow-sm flex items-center gap-1.5"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" /> Nhập Excel Lô Đơn
          </button>
          <button
            onClick={() => {
              resetSingleForm();
              setIsSingleModalOpen(true);
            }}
            className="px-4 py-2.5 bg-[#FF6321] hover:bg-[#e05318] text-white font-bold text-xs rounded-lg transition-all shadow-sm flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" /> + Tạo Đơn Thủ Công
          </button>
        </div>
      </div>

      {/* Selected Items Batch Action Bar */}
      {selectedOrderIds.length > 0 && (
        <div className="p-4 bg-[#FFF5F1] dark:bg-amber-950/50 border-2 border-[#FF6321] rounded-xl flex items-center justify-between text-xs font-semibold text-[#1F2937] dark:text-amber-200 shadow-md animate-in fade-in slide-in-from-top-2">
          <div className="flex items-center gap-2">
            <CheckSquare className="w-5 h-5 text-[#FF6321]" />
            <span>Đã chọn <strong className="text-[#FF6321]">{selectedOrderIds.length}</strong> đơn hàng</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                if (onGoToHandoverWithOrders) {
                  onGoToHandoverWithOrders(selectedOrderIds);
                } else {
                  alert('Vui lòng chuyển sang tab "Bàn giao" để tiến hành phân xế!');
                }
              }}
              className="px-4 py-2 bg-[#FF6321] hover:bg-[#e05318] text-white font-bold rounded-lg shadow-sm flex items-center gap-1.5"
            >
              <Truck className="w-4 h-4" /> Bàn Giao Cho Xế
            </button>
          </div>
        </div>
      )}

      {/* Search and Filters */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-3 text-[#9CA3AF]" />
          <input
            type="text"
            placeholder="Tìm theo mã đơn, vận đơn, tên khách, SĐT, địa chỉ..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2.5 text-xs bg-white dark:bg-slate-900 border border-[#E5E7EB] dark:border-slate-800 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-[#FF6321]"
          />
        </div>

        <select
          value={selectedStatus}
          onChange={(e) => setSelectedStatus(e.target.value)}
          className="px-3 py-2.5 text-xs bg-white dark:bg-slate-900 border border-[#E5E7EB] dark:border-slate-800 rounded-lg font-medium focus:outline-hidden"
        >
          <option value="ALL">-- Tất cả trạng thái đơn --</option>
          <option value="CHO_BAN_GIAO">Chờ bàn giao</option>
          <option value="DA_BAN_GIAO">Đã bàn giao</option>
          <option value="XE_DA_NHAN">Xế đã nhận</option>
          <option value="DANG_DI_GIAO">Đang đi giao</option>
          <option value="GIAO_THANH_CONG">Giao thành công</option>
          <option value="GIAO_THAT_BAI">Giao thất bại</option>
          <option value="KHANG_HEN_GIAO_LAI">Khách hẹn giao lại</option>
          <option value="DON_HOAN">Đơn hoàn</option>
        </select>

        <select
          value={selectedArea}
          onChange={(e) => setSelectedArea(e.target.value)}
          className="px-3 py-2.5 text-xs bg-white dark:bg-slate-900 border border-[#E5E7EB] dark:border-slate-800 rounded-lg font-medium focus:outline-hidden"
        >
          <option value="ALL">-- Tất cả khu vực --</option>
          {areasList.map((a) => (
            <option key={a} value={a}>
              Khu vực: {a}
            </option>
          ))}
        </select>
      </div>

      {/* Orders Table */}
      <div className="p-0 bg-white dark:bg-slate-900 rounded-xl border border-[#E5E7EB] dark:border-slate-800 shadow-sm overflow-x-auto">
        <table className="w-full text-xs text-left border-collapse">
          <thead>
            <tr className="bg-gray-50 dark:bg-slate-800 border-b border-[#E5E7EB] text-[#9CA3AF] uppercase font-bold text-[10px] tracking-wider">
              <th className="p-3.5 w-12 text-center">
                <button onClick={handleSelectAll} className="text-slate-500 hover:text-[#FF6321]">
                  {selectedOrderIds.length === filteredOrders.length && filteredOrders.length > 0 ? (
                    <CheckSquare className="w-4 h-4 text-[#FF6321]" />
                  ) : (
                    <Square className="w-4 h-4" />
                  )}
                </button>
              </th>
              <th className="p-3.5">Mã đơn / Vận đơn</th>
              <th className="p-3.5">Khách hàng & Địa chỉ</th>
              <th className="p-3.5">Khu vực</th>
              <th className="p-3.5">Sản phẩm</th>
              <th className="p-3.5 text-right">Tiền COD</th>
              <th className="p-3.5 text-center">Trạng thái</th>
              <th className="p-3.5 text-right">Thao tác</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#F3F4F6] dark:divide-slate-800 font-medium">
            {filteredOrders.length === 0 ? (
              <tr>
                <td colSpan={8} className="text-center py-8 text-[#9CA3AF]">
                  Không có đơn hàng nào
                </td>
              </tr>
            ) : (
              filteredOrders.map((ord) => {
                const isChecked = selectedOrderIds.includes(ord.id);
                const statusMeta = getOrderStatusMeta(ord.status);

                return (
                  <tr
                    key={ord.id}
                    className={`hover:bg-orange-50/60 dark:hover:bg-slate-800/40 transition-colors ${
                      isChecked ? 'bg-[#FFF5F1] dark:bg-amber-950/20' : ''
                    }`}
                  >
                    <td className="p-3.5 text-center">
                      <button onClick={() => handleToggleSelect(ord.id)} className="text-slate-500">
                        {isChecked ? (
                          <CheckSquare className="w-4 h-4 text-[#FF6321]" />
                        ) : (
                          <Square className="w-4 h-4" />
                        )}
                      </button>
                    </td>
                    <td className="p-3.5">
                      <p className="font-mono text-xs font-bold text-[#FF6321] flex items-center gap-1">
                        {ord.orderCode}
                        {ord.isPriority && (
                          <span className="px-1.5 py-0.2 bg-rose-500 text-white font-bold text-[9px] rounded-sm">Gấp</span>
                        )}
                      </p>
                      <p className="text-[10px] text-[#9CA3AF] font-mono">{ord.trackingCode}</p>
                    </td>
                    <td className="py-3 px-3 max-w-xs">
                      <p className="font-bold text-slate-800 dark:text-slate-200">{ord.recipientName} ({ord.recipientPhone})</p>
                      <p className="text-[11px] text-slate-500 truncate flex items-center gap-1">
                        <MapPin className="w-3 h-3 shrink-0 text-slate-400" />
                        {ord.recipientAddress}
                      </p>
                    </td>
                    <td className="py-3 px-3 font-semibold text-slate-700 dark:text-slate-300">
                      {ord.area || 'Cầu Giấy'}
                    </td>
                    <td className="py-3 px-3 max-w-xs truncate text-slate-600 dark:text-slate-400">
                      {ord.productName} (x{ord.quantity})
                    </td>
                    <td className="py-3 px-3 text-right font-black text-slate-900 dark:text-white">
                      {formatVND(ord.codAmount)}
                    </td>
                    <td className="py-3 px-3">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${statusMeta.badgeClass}`}>
                        {statusMeta.label}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right space-x-1">
                      <button
                        onClick={() => {
                          setLabelModalOrder(ord);
                          setIsLabelModalNewCreated(false);
                        }}
                        className="p-1.5 text-slate-500 hover:text-[#FF6321] rounded-lg hover:bg-orange-50 dark:hover:bg-slate-800 transition-colors"
                        title="In mã vạch / Nhãn bưu gửi"
                      >
                        <Printer className="w-3.5 h-3.5 text-[#FF6321]" />
                      </button>
                      <button
                        onClick={() => handleOpenEdit(ord)}
                        className="p-1.5 text-slate-500 hover:text-amber-600 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
                        title="Chỉnh sửa đơn"
                      >
                        <Edit className="w-3.5 h-3.5" />
                      </button>
                      {ord.status === 'CHO_BAN_GIAO' && (
                        <button
                          onClick={() => {
                            if (confirm(`Xóa đơn hàng ${ord.orderCode}?`)) {
                              deleteOrder(ord.id);
                            }
                          }}
                          className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
                          title="Xóa đơn"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Modal Single Order Create/Edit */}
      <Modal
        isOpen={isSingleModalOpen}
        onClose={() => setIsSingleModalOpen(false)}
        title={editingOrder ? `Sửa Đơn Hàng ${editingOrder.orderCode}` : 'Tạo Đơn Hàng Mới'}
      >
        <form onSubmit={handleSingleSubmit} className="space-y-4 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Tên khách người nhận:</label>
              <input
                type="text"
                required
                placeholder="VD: Nguyễn Văn An"
                value={recipientName}
                onChange={(e) => setRecipientName(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Số điện thoại liên hệ:</label>
              <input
                type="text"
                required
                placeholder="VD: 0912345678"
                value={recipientPhone}
                onChange={(e) => setRecipientPhone(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Địa chỉ giao hàng chi tiết:</label>
            <input
              type="text"
              required
              placeholder="VD: Số 123 Phố Xuân Thủy, Cầu Giấy, Hà Nội"
              value={recipientAddress}
              onChange={(e) => setRecipientAddress(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500"
            />
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Khu vực / Quận:</label>
              <select
                value={area}
                onChange={(e) => setArea(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:outline-hidden"
              >
                <option value="Cầu Giấy">Cầu Giấy</option>
                <option value="Thanh Xuân">Thanh Xuân</option>
                <option value="Hoàn Kiếm">Hoàn Kiếm</option>
                <option value="Hai Bà Trưng">Hai Bà Trưng</option>
                <option value="Đống Đa">Đống Đa</option>
                <option value="Ba Đình">Ba Đình</option>
                <option value="Tây Hồ">Tây Hồ</option>
              </select>
            </div>
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Tiền COD (VNĐ):</label>
              <input
                type="number"
                required
                value={codAmount}
                onChange={(e) => setCodAmount(Number(e.target.value))}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl font-bold text-amber-600 focus:outline-hidden focus:ring-2 focus:ring-amber-500"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Phí cước (VNĐ):</label>
              <input
                type="number"
                value={shippingFee}
                onChange={(e) => setShippingFee(Number(e.target.value))}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:outline-hidden"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Tên sản phẩm hàng hóa:</label>
              <input
                type="text"
                placeholder="VD: Quần jean nam x1"
                value={productName}
                onChange={(e) => setProductName(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:outline-hidden"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Số lượng:</label>
              <input
                type="number"
                value={quantity}
                onChange={(e) => setQuantity(Number(e.target.value))}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:outline-hidden"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Ghi chú giao hàng:</label>
            <input
              type="text"
              placeholder="VD: Cho kiểm tra hàng, gọi trước 10 phút"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:outline-hidden"
            />
          </div>

          <div className="flex items-center gap-2 pt-2">
            <input
              type="checkbox"
              id="priority-check"
              checked={isPriority}
              onChange={(e) => setIsPriority(e.target.checked)}
              className="w-4 h-4 text-amber-600 rounded-sm focus:ring-amber-500"
            />
            <label htmlFor="priority-check" className="font-semibold text-slate-800 dark:text-slate-200">
              Đánh dấu Đơn Hàng Ưu Tiên (Giao gấp trong ca)
            </label>
          </div>

          <div className="pt-3 flex justify-end gap-3">
            <button
              type="button"
              onClick={() => setIsSingleModalOpen(false)}
              className="px-4 py-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl"
            >
              Hủy
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl shadow-md"
            >
              {editingOrder ? 'Lưu Thay Đổi' : 'Tạo Đơn Hàng'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Modal Excel Batch Import */}
      <Modal isOpen={isExcelModalOpen} onClose={() => setIsExcelModalOpen(false)} title="Nhập Đơn Hàng Bằng File Excel">
        <div className="space-y-4 text-xs">
          <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-2xl space-y-2">
            <p className="font-bold text-emerald-900 dark:text-emerald-200 flex items-center gap-2">
              <FileSpreadsheet className="w-5 h-5 text-emerald-600" /> Hướng dẫn chuẩn hóa cột file Excel
            </p>
            <p className="text-slate-600 dark:text-slate-300 text-[11px]">
              Các cột tiêu đề được chấp nhận: <code className="bg-white dark:bg-slate-800 px-1 py-0.5 rounded border border-slate-200 dark:border-slate-700">Tên người nhận</code>, <code className="bg-white dark:bg-slate-800 px-1 py-0.5 rounded border border-slate-200 dark:border-slate-700">Số điện thoại</code>, <code className="bg-white dark:bg-slate-800 px-1 py-0.5 rounded border border-slate-200 dark:border-slate-700">Địa chỉ</code>, <code className="bg-white dark:bg-slate-800 px-1 py-0.5 rounded border border-slate-200 dark:border-slate-700">Tiền COD</code>, <code className="bg-white dark:bg-slate-800 px-1 py-0.5 rounded border border-slate-200 dark:border-slate-700">Sản phẩm</code>.
            </p>
          </div>

          <div className="p-6 border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-2xl text-center bg-slate-50 dark:bg-slate-800/40 space-y-3">
            <Upload className="w-10 h-10 mx-auto text-amber-500" />
            <p className="font-semibold text-slate-800 dark:text-slate-200">Chọn hoặc Kéo thả file Excel (.xlsx / .xls) vào đây</p>
            <input
              type="file"
              accept=".xlsx, .xls"
              onChange={handleExcelFileUpload}
              className="block w-full text-xs text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-amber-600 file:text-white hover:file:bg-amber-700 cursor-pointer"
            />
          </div>

          {/* Excel Preview */}
          {excelDataPreview.length > 0 && (
            <div className="space-y-2">
              <p className="font-bold text-slate-900 dark:text-white">Xem trước {excelDataPreview.length} đơn hàng sẽ import:</p>
              <div className="max-h-48 overflow-y-auto border border-slate-200 dark:border-slate-700 rounded-xl p-2 bg-white dark:bg-slate-800">
                <table className="w-full text-[11px] text-left">
                  <thead>
                    <tr className="border-b border-slate-200 dark:border-slate-700 font-bold text-slate-500">
                      <th className="py-1">STT</th>
                      <th className="py-1">Tên khách</th>
                      <th className="py-1">SĐT</th>
                      <th className="py-1">Địa chỉ</th>
                      <th className="py-1 text-right">Tiền COD</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-700">
                    {excelDataPreview.slice(0, 5).map((row, idx) => (
                      <tr key={idx}>
                        <td className="py-1 text-slate-400">{idx + 1}</td>
                        <td className="py-1 font-semibold">{row['Tên người nhận'] || row['TenKhach'] || 'Khách'}</td>
                        <td className="py-1">{row['Số điện thoại'] || row['SDT']}</td>
                        <td className="py-1 truncate max-w-xs">{row['Địa chỉ'] || row['DiaChi']}</td>
                        <td className="py-1 text-right font-bold text-amber-600">{formatVND(Number(row['Tiền COD'] || row['COD']) || 0)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          <div className="pt-3 flex justify-end gap-3">
            <button
              onClick={() => setIsExcelModalOpen(false)}
              className="px-4 py-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl"
            >
              Hủy
            </button>
            <button
              onClick={handleConfirmBatchUpload}
              disabled={excelDataPreview.length === 0}
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold rounded-xl shadow-md"
            >
              Nhập {excelDataPreview.length} Đơn Vào Hệ Thống
            </button>
          </div>
        </div>
      </Modal>

      {/* Scanner Modal */}
      <ScannerModal isOpen={isScannerOpen} onClose={() => setIsScannerOpen(false)} />

      {/* Order Label & Barcode Modal */}
      <OrderLabelModal
        isOpen={!!labelModalOrder}
        onClose={() => setLabelModalOrder(null)}
        order={labelModalOrder}
        isNewCreated={isLabelModalNewCreated}
      />
    </div>
  );
};
