import React from 'react';
import { Package, Truck, Clock, CheckCircle2, AlertTriangle, Users, DollarSign, PlusCircle, ArrowUpRight } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { formatVND } from '../../utils/helpers';

interface ManagerDashboardProps {
  onNavigateTab: (tabKey: string) => void;
}

export const ManagerDashboard: React.FC<ManagerDashboardProps> = ({ onNavigateTab }) => {
  const { currentUser, orders, users, handoverSheets, codDeposits } = useApp();

  if (!currentUser) return null;

  // Filter orders managed by this Manager
  const myOrders = orders.filter((o) => o.managerId === currentUser.id);
  const pendingHandover = myOrders.filter((o) => o.status === 'CHO_BAN_GIAO');
  const handedOver = myOrders.filter((o) => o.status === 'DA_BAN_GIAO' || o.status === 'XE_DA_NHAN');
  const delivering = myOrders.filter((o) => o.status === 'DANG_DI_GIAO' || o.status === 'DA_LIEN_HE_KHACH');
  const success = myOrders.filter((o) => o.status === 'GIAO_THANH_CONG' || o.status === 'DA_NOP_COD' || o.status === 'DA_DOI_SOAT');
  const failed = myOrders.filter((o) => ['GIAO_THAT_BAI', 'KHANG_HEN_GIAO_LAI', 'KHANG_KHONG_NGHE', 'SAI_DIA_CHI', 'KHANG_TU_CHOI', 'DON_HOAN'].includes(o.status));

  // Managed Drivers
  const myDrivers = users.filter((u) => u.role === 'DRIVER' && u.managerId === currentUser.id);

  // COD Calculations
  const totalCodCollected = success.reduce((sum, o) => sum + (o.collectedCodAmount || o.codAmount || 0), 0);
  const confirmedDeposits = codDeposits
    .filter((d) => d.managerId === currentUser.id && d.status === 'DA_XAC_NHAN')
    .reduce((sum, d) => sum + d.amount, 0);
  const unsubmittedCod = totalCodCollected - confirmedDeposits;

  const pendingDeposits = codDeposits.filter((d) => d.managerId === currentUser.id && d.status === 'CHO_XAC_NHAN');

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Welcome Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between p-6 bg-[#1F2937] rounded-xl text-white shadow-lg border border-slate-700 gap-4">
        <div>
          <span className="text-[10px] font-bold uppercase tracking-widest text-[#FF6321] bg-[#FFF5F1]/10 px-2.5 py-1 rounded border border-[#FF6321]/30">
            Khu vực Quản lý Đơn Kho
          </span>
          <h2 className="text-2xl font-black mt-2.5 tracking-tight text-white">Xin chào, {currentUser.fullName}!</h2>
          <p className="text-xs text-slate-300 mt-1 max-w-xl">
            Quản lý kho hàng, tạo đơn mới, gom chuyến bàn giao điện tử cho Xế và thực hiện đối soát COD.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => onNavigateTab('create_order')}
            className="px-3.5 py-2 text-xs font-bold bg-[#FF6321] text-white hover:bg-[#e05318] rounded-md transition-all shadow-sm flex items-center gap-1.5"
          >
            <PlusCircle className="w-4 h-4" /> + Tạo Đơn Mới
          </button>
          <button
            onClick={() => onNavigateTab('inter_transfer')}
            className="px-3.5 py-2 text-xs font-bold bg-amber-600 text-white hover:bg-amber-700 rounded-md transition-all shadow-sm flex items-center gap-1.5"
          >
            <ArrowUpRight className="w-4 h-4" /> Chuyển Lô Kho
          </button>
          <button
            onClick={() => onNavigateTab('my_drivers')}
            className="px-3.5 py-2 text-xs font-bold bg-white text-[#1F2937] hover:bg-gray-100 rounded-md transition-all shadow-sm border border-[#E5E7EB] flex items-center gap-1.5"
          >
            <Users className="w-4 h-4 text-[#FF6321]" /> Quản Lý Xế
          </button>
        </div>
      </div>

      {/* Pending Deposit Notification Banner */}
      {pendingDeposits.length > 0 && (
        <div className="p-4 bg-orange-50/80 dark:bg-orange-950/40 border border-[#FF6321]/30 rounded-xl flex items-center justify-between text-xs text-slate-800 dark:text-slate-200">
          <div className="flex items-center gap-3">
            <Clock className="w-6 h-6 text-[#FF6321] shrink-0" />
            <div>
              <p className="font-bold text-sm text-[#FF6321]">Có {pendingDeposits.length} khoản nộp COD cần đối soát xác nhận!</p>
              <p className="text-slate-600 dark:text-slate-300">
                Xế đã gửi phiếu nộp tiền COD. Vui lòng kiểm tra tiền mặt / chuyển khoản và bấm xác nhận.
              </p>
            </div>
          </div>
          <button
            onClick={() => onNavigateTab('reconcile')}
            className="px-3.5 py-1.5 bg-[#FF6321] text-white font-bold rounded-md hover:bg-[#e05318] transition-colors shrink-0 text-xs shadow-sm"
          >
            Đối soát ngay
          </button>
        </div>
      )}

      {/* Stats Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="p-4 bg-white dark:bg-slate-900 rounded-xl border border-[#E5E7EB] dark:border-slate-800 shadow-sm space-y-1">
          <span className="text-[10px] font-bold text-[#9CA3AF] uppercase tracking-wider">Tổng đơn quản lý</span>
          <p className="text-2xl font-black text-[#1F2937] dark:text-white">{myOrders.length}</p>
        </div>

        <div className="p-4 bg-white dark:bg-slate-900 rounded-xl border border-[#E5E7EB] dark:border-slate-800 shadow-sm space-y-1">
          <span className="text-[10px] font-bold text-[#9CA3AF] uppercase tracking-wider">Chưa bàn giao</span>
          <p className="text-2xl font-black text-[#FF6321]">{pendingHandover.length}</p>
        </div>

        <div className="p-4 bg-white dark:bg-slate-900 rounded-xl border border-[#E5E7EB] dark:border-slate-800 shadow-sm space-y-1">
          <span className="text-[10px] font-bold text-[#9CA3AF] uppercase tracking-wider">Đã bàn giao</span>
          <p className="text-2xl font-black text-blue-600">{handedOver.length}</p>
        </div>

        <div className="p-4 bg-white dark:bg-slate-900 rounded-xl border border-[#E5E7EB] dark:border-slate-800 shadow-sm space-y-1">
          <span className="text-[10px] font-bold text-[#9CA3AF] uppercase tracking-wider">Đang đi giao</span>
          <p className="text-2xl font-black text-blue-500">{delivering.length}</p>
        </div>

        <div className="p-4 bg-white dark:bg-slate-900 rounded-xl border border-[#E5E7EB] dark:border-slate-800 shadow-sm space-y-1">
          <span className="text-[10px] font-bold text-[#9CA3AF] uppercase tracking-wider">Giao thành công</span>
          <p className="text-2xl font-black text-emerald-600">{success.length}</p>
        </div>

        <div className="p-4 bg-white dark:bg-slate-900 rounded-xl border border-[#E5E7EB] dark:border-slate-800 shadow-sm space-y-1">
          <span className="text-[10px] font-bold text-[#9CA3AF] uppercase tracking-wider">Thất bại / Hoàn</span>
          <p className="text-2xl font-black text-rose-600">{failed.length}</p>
        </div>
      </div>

      {/* COD Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase">Tổng COD Xế Đã Thu Thực Tế</p>
            <p className="text-2xl font-black text-emerald-600 dark:text-emerald-400 mt-1">{formatVND(totalCodCollected)}</p>
            <p className="text-[11px] text-slate-500 mt-1">
              Đã xác nhận nộp kho: <strong className="text-slate-800 dark:text-slate-200">{formatVND(confirmedDeposits)}</strong>
            </p>
          </div>
          <div className="p-3 bg-emerald-100 dark:bg-emerald-900/40 text-emerald-600 rounded-2xl">
            <DollarSign className="w-8 h-8" />
          </div>
        </div>

        <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase">Tiền COD Xế Chưa Nộp (Nợ Dư)</p>
            <p className={`text-2xl font-black mt-1 ${unsubmittedCod > 0 ? 'text-rose-600 dark:text-rose-400' : 'text-slate-800 dark:text-slate-200'}`}>
              {formatVND(unsubmittedCod)}
            </p>
            <p className="text-[11px] text-slate-500 mt-1">
              {unsubmittedCod > 0 ? 'Yêu cầu Xế nộp tiền tại quầy hoặc chuyển khoản' : 'Xế đã nộp đủ 100% COD'}
            </p>
          </div>
          <div className="p-3 bg-rose-100 dark:bg-rose-900/40 text-rose-600 rounded-2xl">
            <AlertTriangle className="w-8 h-8" />
          </div>
        </div>
      </div>

      {/* Managed Drivers List & Progress */}
      <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
          <h3 className="font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Users className="w-5 h-5 text-amber-500" /> Danh Sách Xế Trực Thuộc Quản Lý ({myDrivers.length})
          </h3>
          <button
            onClick={() => onNavigateTab('handover')}
            className="text-xs text-amber-600 dark:text-amber-400 font-semibold hover:underline flex items-center gap-1"
          >
            Bàn giao cho Xế <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {myDrivers.map((d) => {
            const dOrders = myOrders.filter((o) => o.driverId === d.id);
            const dDelivered = dOrders.filter((o) => o.status === 'GIAO_THANH_CONG' || o.status === 'DA_NOP_COD');
            const dCodToCollect = dOrders.reduce((sum, o) => sum + (o.codAmount || 0), 0);
            const dCodCollected = dDelivered.reduce((sum, o) => sum + (o.collectedCodAmount || o.codAmount || 0), 0);

            const percent = dOrders.length > 0 ? Math.round((dDelivered.length / dOrders.length) * 100) : 0;

            return (
              <div key={d.id} className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-200 dark:border-slate-700/60 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <img src={d.avatarUrl} alt="" className="w-10 h-10 rounded-full object-cover border-2 border-emerald-500" />
                    <div>
                      <p className="font-bold text-sm text-slate-900 dark:text-white">{d.fullName}</p>
                      <p className="text-xs text-slate-500">SĐT: {d.phone}</p>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 dark:bg-emerald-900/50 dark:text-emerald-300 font-bold rounded-lg text-xs">
                    {dDelivered.length}/{dOrders.length} Đơn
                  </span>
                </div>

                {/* Progress bar */}
                <div className="space-y-1">
                  <div className="flex justify-between text-[11px] text-slate-500">
                    <span>Tiến độ giao:</span>
                    <span className="font-bold text-slate-800 dark:text-slate-200">{percent}%</span>
                  </div>
                  <div className="w-full bg-slate-200 dark:bg-slate-700 h-2 rounded-full overflow-hidden">
                    <div className="bg-emerald-500 h-full transition-all duration-300" style={{ width: `${percent}%` }}></div>
                  </div>
                </div>

                <div className="flex justify-between text-xs pt-1 border-t border-slate-200/60 dark:border-slate-700/60 text-slate-600 dark:text-slate-300">
                  <span>COD cần thu: <strong>{formatVND(dCodToCollect)}</strong></span>
                  <span>Đã thu: <strong className="text-emerald-600">{formatVND(dCodCollected)}</strong></span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
