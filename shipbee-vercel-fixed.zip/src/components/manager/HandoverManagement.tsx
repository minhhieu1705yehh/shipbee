import React, { useState } from 'react';
import { Truck, CheckCircle2, Clock, AlertTriangle, Printer, Download, UserCheck, ShieldAlert, FileText } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { PrintHandoverModal } from '../common/PrintHandoverModal';
import { formatVND, formatDateTime, getHandoverSheetStatusMeta } from '../../utils/helpers';
import { HandoverSheet, Order } from '../../types';

interface HandoverManagementProps {
  initialSelectedOrderIds?: string[];
}

export const HandoverManagement: React.FC<HandoverManagementProps> = ({ initialSelectedOrderIds = [] }) => {
  const { currentUser, orders, users, handoverSheets, createHandoverSheet } = useApp();

  const [selectedOrderIds, setSelectedOrderIds] = useState<string[]>(initialSelectedOrderIds);
  const [selectedDriverId, setSelectedDriverId] = useState<string>('');
  const [previewSheet, setPreviewSheet] = useState<HandoverSheet | null>(null);

  // Managed Drivers
  const myDrivers = users.filter((u) => u.role === 'DRIVER' && u.managerId === currentUser?.id);

  // Unassigned / Pending Handover Orders for this Manager
  const unassignedOrders = orders.filter(
    (o) => (o.managerId === currentUser?.id || currentUser?.role === 'ADMIN') && o.status === 'CHO_BAN_GIAO'
  );

  // My Handover Sheets
  const mySheets = handoverSheets.filter(
    (s) => s.managerId === currentUser?.id || currentUser?.role === 'ADMIN'
  );

  const selectedOrders = orders.filter((o) => selectedOrderIds.includes(o.id));
  const totalCodSelected = selectedOrders.reduce((sum, o) => sum + (o.codAmount || 0), 0);
  const totalShippingSelected = selectedOrders.reduce((sum, o) => sum + (o.shippingFee || 0), 0);
  const totalCollectableSelected = totalCodSelected + totalShippingSelected;

  const handleToggleSelectOrder = (id: string) => {
    if (selectedOrderIds.includes(id)) {
      setSelectedOrderIds(selectedOrderIds.filter((item) => item !== id));
    } else {
      setSelectedOrderIds([...selectedOrderIds, id]);
    }
  };

  const handleSelectAllUnassigned = () => {
    if (selectedOrderIds.length === unassignedOrders.length) {
      setSelectedOrderIds([]);
    } else {
      setSelectedOrderIds(unassignedOrders.map((o) => o.id));
    }
  };

  const handleCreateHandover = () => {
    if (selectedOrderIds.length === 0) {
      alert('Vui lòng chọn ít nhất 1 đơn hàng để bàn giao!');
      return;
    }
    if (!selectedDriverId) {
      alert('Vui lòng chọn Xế tiếp nhận bàn giao!');
      return;
    }

    const created = createHandoverSheet(selectedDriverId, selectedOrderIds);
    if (created) {
      alert(`Tạo thành công Phiếu Bàn Giao ${created.sheetCode}! Hệ thống đã gửi thông báo đến ứng dụng của Xế.`);
      setSelectedOrderIds([]);
      setPreviewSheet(created);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Header */}
      <div className="p-6 bg-[#1F2937] rounded-xl border border-slate-700 shadow-lg text-white">
        <span className="text-[10px] font-bold uppercase tracking-widest text-[#FF6321] bg-[#FFF5F1]/10 px-2.5 py-1 rounded border border-[#FF6321]/30">
          Quy trình bàn giao kho
        </span>
        <h2 className="text-xl font-bold mt-2 text-white flex items-center gap-2">
          <Truck className="w-5 h-5 text-[#FF6321]" /> Bàn Giao Đơn Hàng & Lập Phiếu Điện Tử
        </h2>
        <p className="text-xs text-slate-300 mt-1">
          Chọn đơn hàng chờ bàn giao trong kho &rarr; Phân cho Xế phụ trách &rarr; Tạo phiếu điện tử minh bạch &rarr; Xế nhận thông báo và bấm xác nhận tiếp nhận.
        </p>
      </div>

      {/* Step 1 & 2: Order Selection & Driver Assign Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Unassigned Orders Selection */}
        <div className="lg:col-span-2 p-6 bg-white dark:bg-slate-900 rounded-xl border border-[#E5E7EB] dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#E5E7EB] dark:border-slate-800">
            <h3 className="font-bold text-sm text-[#1F2937] dark:text-white flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#FF6321]"></span> 1. Chọn Đơn Chờ Bàn Giao ({unassignedOrders.length} đơn)
            </h3>
            <button
              onClick={handleSelectAllUnassigned}
              className="text-xs text-[#FF6321] font-bold hover:underline"
            >
              {selectedOrderIds.length === unassignedOrders.length && unassignedOrders.length > 0 ? 'Bỏ chọn tất cả' : 'Chọn tất cả'}
            </button>
          </div>

          <div className="space-y-2 max-h-96 overflow-y-auto">
            {unassignedOrders.length === 0 ? (
              <p className="text-center py-8 text-[#9CA3AF] text-xs">Không có đơn hàng nào chờ bàn giao trong kho</p>
            ) : (
              unassignedOrders.map((ord) => {
                const isSelected = selectedOrderIds.includes(ord.id);
                return (
                  <div
                    key={ord.id}
                    onClick={() => handleToggleSelectOrder(ord.id)}
                    className={`p-3 rounded-lg border text-xs cursor-pointer transition-all flex items-center justify-between ${
                      isSelected
                        ? 'bg-[#FFF5F1] dark:bg-amber-950/40 border-[#FF6321] shadow-xs'
                        : 'bg-white dark:bg-slate-800/40 border-[#E5E7EB] dark:border-slate-800 hover:bg-orange-50/50'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-4 h-4 rounded border flex items-center justify-center ${isSelected ? 'bg-[#FF6321] border-[#FF6321] text-white' : 'border-slate-400'}`}>
                        {isSelected && <CheckCircle2 className="w-3.5 h-3.5" />}
                      </div>
                      <div>
                        <p className="font-bold text-slate-900 dark:text-white">
                          <span className="font-mono text-[#FF6321]">{ord.orderCode}</span> <span className="text-[10px] text-[#9CA3AF] font-mono">({ord.trackingCode})</span>
                        </p>
                        <p className="text-slate-600 dark:text-slate-300 font-medium">{ord.recipientName} • {ord.recipientPhone}</p>
                        <p className="text-[11px] text-slate-500 truncate max-w-xs">{ord.recipientAddress}</p>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <p className="font-mono font-bold text-[#FF6321] text-sm">{formatVND(ord.codAmount)}</p>
                      <p className="text-[10px] text-[#9CA3AF]">Khu vực: {ord.area || 'Cầu Giấy'}</p>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right 1 Col: Step 3 & 4 Summary & Driver Assign */}
        <div className="p-6 bg-white dark:bg-slate-900 rounded-xl border border-[#E5E7EB] dark:border-slate-800 shadow-sm space-y-5 flex flex-col justify-between">
          <div className="space-y-4">
            <h3 className="font-bold text-sm text-[#1F2937] dark:text-white pb-2 border-b border-[#E5E7EB] dark:border-slate-800">
              2. Xác Nhận Bàn Giao Cho Xế
            </h3>

            {/* Driver Select */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Chọn Xế tiếp nhận:
              </label>
              <select
                value={selectedDriverId}
                onChange={(e) => setSelectedDriverId(e.target.value)}
                className="w-full px-3 py-2.5 text-xs bg-[#F8F9FA] dark:bg-slate-800 border border-[#E5E7EB] dark:border-slate-700 rounded-lg font-bold text-[#1F2937] dark:text-slate-100 focus:outline-hidden focus:ring-2 focus:ring-[#FF6321]"
              >
                <option value="">-- Chọn Xế giao hàng --</option>
                {myDrivers.map((d) => (
                  <option key={d.id} value={d.id}>
                    Xế: {d.fullName} ({d.phone})
                  </option>
                ))}
              </select>
            </div>

            {/* Handover Summary Card */}
            <div className="p-4 bg-[#FFF5F1]/60 dark:bg-slate-800/60 rounded-lg border border-[#FF6321]/30 text-xs space-y-2">
              <div className="flex justify-between">
                <span className="text-slate-500">Số lượng đơn chọn:</span>
                <strong className="text-[#FF6321] text-sm">{selectedOrderIds.length} đơn</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Tiền hàng COD:</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">{formatVND(totalCodSelected)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Cước phí ship:</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">{formatVND(totalShippingSelected)}</span>
              </div>
              <div className="flex justify-between pt-1 border-t border-[#E5E7EB] dark:border-slate-700 font-bold">
                <span className="text-slate-700 dark:text-slate-300">Tổng tiền thu hộ (COD + Ship):</span>
                <strong className="text-emerald-600 text-sm">{formatVND(totalCollectableSelected)}</strong>
              </div>
              <div className="flex justify-between pt-1 border-t border-[#E5E7EB] dark:border-slate-700">
                <span className="text-slate-500">Người bàn giao:</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">{currentUser?.fullName}</span>
              </div>
            </div>
          </div>

          <button
            onClick={handleCreateHandover}
            disabled={selectedOrderIds.length === 0 || !selectedDriverId}
            className="w-full py-3 bg-[#FF6321] hover:bg-[#e05318] disabled:opacity-50 text-white font-bold text-xs rounded-lg shadow-sm transition-all flex items-center justify-center gap-2"
          >
            <Truck className="w-4 h-4" /> BÀN GIAO ĐƠN NGAY
          </button>
        </div>
      </div>

      {/* Handover Sheets List */}
      <div className="p-0 bg-white dark:bg-slate-900 rounded-xl border border-[#E5E7EB] dark:border-slate-800 shadow-sm overflow-hidden space-y-0">
        <div className="p-4 bg-gray-50 dark:bg-slate-800/80 border-b border-[#E5E7EB] dark:border-slate-800 flex items-center justify-between">
          <h3 className="font-bold text-sm text-[#1F2937] dark:text-white flex items-center gap-2">
            <FileText className="w-5 h-5 text-[#FF6321]" /> Danh Sách Phiếu Bàn Giao Điện Tử ({mySheets.length})
          </h3>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="bg-gray-50 dark:bg-slate-800 border-b border-[#E5E7EB] text-[#9CA3AF] uppercase font-bold text-[10px] tracking-wider">
                <th className="p-3.5">Mã phiếu PBG</th>
                <th className="p-3.5">Xế tiếp nhận</th>
                <th className="p-3.5 text-center">Số đơn</th>
                <th className="p-3.5 text-right">Tổng COD</th>
                <th className="p-3.5">Trạng thái phiếu</th>
                <th className="p-3.5">Thời gian tạo</th>
                <th className="p-3.5 text-right">Thao tác</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#F3F4F6] dark:divide-slate-800 font-medium">
              {mySheets.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-8 text-[#9CA3AF]">
                    Chưa có phiếu bàn giao nào
                  </td>
                </tr>
              ) : (
                mySheets.map((sheet) => {
                  const statusMeta = getHandoverSheetStatusMeta(sheet.status);
                  return (
                    <tr key={sheet.id} className="hover:bg-orange-50/60 dark:hover:bg-slate-800/40 transition-colors">
                      <td className="p-3.5 font-mono font-bold text-[#FF6321]">
                        {sheet.sheetCode}
                      </td>
                      <td className="p-3.5 font-semibold text-slate-800 dark:text-slate-200">
                        {sheet.driverName}
                      </td>
                      <td className="p-3.5 text-center font-bold">
                        {sheet.totalOrders} đơn
                      </td>
                      <td className="p-3.5 text-right font-mono font-bold text-emerald-600 dark:text-emerald-400">
                        {formatVND(sheet.totalCodAmount)}
                      </td>
                      <td className="p-3.5">
                        <span className={`px-2.5 py-0.5 rounded text-[10px] font-bold border ${statusMeta.badgeClass}`}>
                          {statusMeta.label}
                        </span>
                      </td>
                      <td className="p-3.5 text-slate-400 text-[11px] font-mono">
                        {formatDateTime(sheet.createdAt)}
                      </td>
                      <td className="p-3.5 text-right space-x-2">
                        <button
                          onClick={() => setPreviewSheet(sheet)}
                          className="px-3 py-1 bg-white dark:bg-slate-800 hover:bg-gray-100 text-[#1F2937] dark:text-slate-200 font-semibold rounded border border-[#E5E7EB] transition-colors inline-flex items-center gap-1 text-[11px] shadow-xs"
                        >
                          <Printer className="w-3.5 h-3.5 text-[#FF6321]" /> In / Xem Phiếu
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Print Modal */}
      <PrintHandoverModal sheet={previewSheet} isOpen={!!previewSheet} onClose={() => setPreviewSheet(null)} />
    </div>
  );
};
