import React, { useState } from 'react';
import {
  ArrowRightLeft,
  Truck,
  QrCode,
  Scan,
  CheckCircle2,
  AlertCircle,
  FileText,
  DollarSign,
  Search,
  Check,
  Building2,
  MapPin,
  Clock,
  Printer,
  ChevronRight,
  Filter,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Modal } from '../common/Modal';
import { ManagerTransferBatch, Order } from '../../types';

export const InterManagerTransfer: React.FC = () => {
  const {
    currentUser,
    users,
    orders,
    transferBatches,
    createTransferBatch,
    scanOrderInBatch,
    acceptTransferBatch,
    settleBatchCod,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'create' | 'receive' | 'settlement'>('create');

  // Tab 1: Create Batch states
  const [selectedAreaFilter, setSelectedAreaFilter] = useState<string>('ALL');
  const [targetManagerId, setTargetManagerId] = useState<string>('');
  const [selectedOrderIds, setSelectedOrderIds] = useState<string[]>([]);
  const [batchNote, setBatchNote] = useState<string>('');
  const [createdBatch, setCreatedBatch] = useState<ManagerTransferBatch | null>(null);

  // Tab 2: Receive & Scan states
  const [activeScanningBatchId, setActiveScanningBatchId] = useState<string | null>(null);
  const activeScanningBatch = transferBatches.find((b) => b.id === activeScanningBatchId) || null;
  const [scanInput, setScanInput] = useState<string>('');
  const [scanMessage, setScanMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Tab 3: Settlement modal
  const [settleModalBatch, setSettleModalBatch] = useState<ManagerTransferBatch | null>(null);
  const [settleAmount, setSettleAmount] = useState<number>(0);

  if (!currentUser) return null;

  // Other managers in system
  const otherManagers = users.filter((u) => u.role === 'MANAGER' && u.id !== currentUser.id);

  // Orders available for transfer at current manager's warehouse
  const myWarehouseOrders = orders.filter(
    (o) => o.managerId === currentUser.id && o.status === 'CHO_BAN_GIAO'
  );

  // Unique areas from available orders
  const availableAreas = Array.from(new Set(myWarehouseOrders.map((o) => o.area || 'Khác'))).filter(Boolean);

  // Filtered orders for selection
  const filteredWarehouseOrders = myWarehouseOrders.filter((o) => {
    if (selectedAreaFilter !== 'ALL' && (o.area || 'Khác') !== selectedAreaFilter) return false;
    return true;
  });

  // Handle select all filtered
  const handleSelectAll = () => {
    if (selectedOrderIds.length === filteredWarehouseOrders.length) {
      setSelectedOrderIds([]);
    } else {
      setSelectedOrderIds(filteredWarehouseOrders.map((o) => o.id));
    }
  };

  const handleToggleSelectOrder = (orderId: string) => {
    if (selectedOrderIds.includes(orderId)) {
      setSelectedOrderIds(selectedOrderIds.filter((id) => id !== orderId));
    } else {
      setSelectedOrderIds([...selectedOrderIds, orderId]);
    }
  };

  const handleCreateBatch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetManagerId) {
      alert('Vui lòng chọn Quản lý kho tiếp nhận!');
      return;
    }
    if (selectedOrderIds.length === 0) {
      alert('Vui lòng chọn ít nhất 1 đơn hàng để lập lô chuyển!');
      return;
    }

    const areaName = selectedAreaFilter !== 'ALL' ? selectedAreaFilter : 'Nhiều khu vực';
    const batch = createTransferBatch(targetManagerId, selectedOrderIds, areaName, batchNote);

    if (batch) {
      setCreatedBatch(batch);
      setSelectedOrderIds([]);
      setBatchNote('');
      alert(`Đã tạo phiếu chuyển lô ${batch.batchCode} thành công!`);
    }
  };

  // Batches sent to current manager
  const incomingBatches = transferBatches.filter((b) => b.receiverManagerId === currentUser.id);

  // Batches sent by current manager
  const outgoingBatches = transferBatches.filter((b) => b.senderManagerId === currentUser.id);

  // Scan order handler
  const handleScanSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeScanningBatch || !scanInput.trim()) return;

    const res = scanOrderInBatch(activeScanningBatch.id, scanInput.trim());
    if (res.success) {
      setScanMessage({ type: 'success', text: res.message });
    } else {
      setScanMessage({ type: 'error', text: res.message });
    }
    setScanInput('');
  };

  const handleConfirmReceiveBatch = (batch: ManagerTransferBatch) => {
    if (batch.scannedOrderIds.length < batch.totalOrders) {
      const confirmUnscanned = window.confirm(
        `Cảnh báo: Bạn mới quét kiểm đếm ${batch.scannedOrderIds.length}/${batch.totalOrders} đơn. Bạn có chắc chắn muốn xác nhận tiếp nhận toàn bộ lô đơn này?`
      );
      if (!confirmUnscanned) return;
    }

    acceptTransferBatch(batch.id);
    setActiveScanningBatchId(null);
    alert(`Đã tiếp nhận lô hàng ${batch.batchCode} thành công! Đơn hàng đã về kho của bạn.`);
  };

  const handleOpenSettleModal = (batch: ManagerTransferBatch) => {
    setSettleModalBatch(batch);
    setSettleAmount(batch.totalCodAmount);
  };

  const handleSettleBatch = () => {
    if (!settleModalBatch) return;
    settleBatchCod(settleModalBatch.id, settleAmount);
    setSettleModalBatch(null);
    alert(`Đã hoàn tất đối soát và trả tiền COD lô ${settleModalBatch.batchCode}!`);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header Banner */}
      <div className="p-6 bg-gradient-to-r from-[#FF6321] to-[#e05318] text-white rounded-2xl shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <ArrowRightLeft className="w-6 h-6 text-white" />
            <h2 className="text-xl font-bold">Bàn Giao & Chuyển Lô Đơn Hàng Liên Quản Lý</h2>
          </div>
          <p className="text-xs text-amber-100 mt-1">
            Bàn giao hàng theo lô khu vực (Lộc Hà, Can Lộc, Hương Sơn, Hồng Lĩnh...), quét mã vạch đối soát theo từng đơn và đối soát thanh toán COD theo lô.
          </p>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center bg-white/10 p-1 rounded-xl gap-1 shrink-0">
          <button
            onClick={() => setActiveTab('create')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'create'
                ? 'bg-white text-[#FF6321] shadow-sm'
                : 'text-white hover:bg-white/10'
            }`}
          >
            <FileText className="w-3.5 h-3.5" /> Lập Lô Chuyển
          </button>
          <button
            onClick={() => setActiveTab('receive')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 relative ${
              activeTab === 'receive'
                ? 'bg-white text-[#FF6321] shadow-sm'
                : 'text-white hover:bg-white/10'
            }`}
          >
            <Scan className="w-3.5 h-3.5" /> Nhận Lô & Quét Mã
            {incomingBatches.filter((b) => b.status === 'CHO_TIEP_NHAN').length > 0 && (
              <span className="w-2 h-2 rounded-full bg-yellow-300 animate-ping absolute -top-0.5 -right-0.5"></span>
            )}
          </button>
          <button
            onClick={() => setActiveTab('settlement')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'settlement'
                ? 'bg-white text-[#FF6321] shadow-sm'
                : 'text-white hover:bg-white/10'
            }`}
          >
            <DollarSign className="w-3.5 h-3.5" /> Trả Tiền / Đối Soát Lô
          </button>
        </div>
      </div>

      {/* TAB 1: CREATE TRANSFER BATCH */}
      {activeTab === 'create' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Order Selection Panel */}
          <div className="lg:col-span-2 p-6 bg-white dark:bg-slate-900 rounded-2xl border border-[#E5E7EB] dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#E5E7EB] dark:border-slate-800">
              <h3 className="font-bold text-sm text-[#1F2937] dark:text-white flex items-center gap-2">
                <Truck className="w-4 h-4 text-[#FF6321]" /> Chọn Đơn Trong Kho Để Bàn Giao
              </h3>

              {/* Area Filter */}
              <div className="flex items-center gap-2">
                <Filter className="w-3.5 h-3.5 text-slate-400" />
                <select
                  value={selectedAreaFilter}
                  onChange={(e) => setSelectedAreaFilter(e.target.value)}
                  className="px-2.5 py-1 text-xs border border-[#E5E7EB] dark:border-slate-700 rounded-lg bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-white font-bold"
                >
                  <option value="ALL">-- Tất cả khu vực ({myWarehouseOrders.length} đơn) --</option>
                  {availableAreas.map((area) => (
                    <option key={area} value={area}>
                      Khu vực: {area}
                    </option>
                  ))}
                  <option value="Lộc Hà">Khu vực: Lộc Hà</option>
                  <option value="Can Lộc">Khu vực: Can Lộc</option>
                  <option value="Hương Sơn">Khu vực: Hương Sơn</option>
                  <option value="Hồng Lĩnh">Khu vực: Hồng Lĩnh</option>
                  <option value="Cẩm Xuyên">Khu vực: Cẩm Xuyên</option>
                </select>
              </div>
            </div>

            {filteredWarehouseOrders.length === 0 ? (
              <div className="py-12 text-center text-slate-400 text-xs">
                Không có đơn hàng chờ bàn giao nào phù hợp trong kho.
              </div>
            ) : (
              <div className="space-y-3">
                <div className="flex items-center justify-between px-2 text-xs font-semibold text-slate-500">
                  <button
                    type="button"
                    onClick={handleSelectAll}
                    className="text-[#FF6321] hover:underline font-bold"
                  >
                    {selectedOrderIds.length === filteredWarehouseOrders.length
                      ? 'Bỏ chọn tất cả'
                      : 'Chọn tất cả đơn hiển thị'}
                  </button>
                  <span>Đã chọn: <strong className="text-[#FF6321]">{selectedOrderIds.length}</strong> / {filteredWarehouseOrders.length} đơn</span>
                </div>

                <div className="overflow-x-auto max-h-[380px] overflow-y-auto pr-1">
                  <table className="w-full text-xs text-left">
                    <thead className="sticky top-0 bg-slate-50 dark:bg-slate-800 text-slate-500 text-[10px] uppercase font-bold">
                      <tr>
                        <th className="p-2.5 text-center">Chọn</th>
                        <th className="p-2.5">Mã đơn & Vận đơn</th>
                        <th className="p-2.5">Người nhận & Địa chỉ</th>
                        <th className="p-2.5">Khu vực</th>
                        <th className="p-2.5 text-right">Tiền COD</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {filteredWarehouseOrders.map((o) => {
                        const isSelected = selectedOrderIds.includes(o.id);
                        return (
                          <tr
                            key={o.id}
                            onClick={() => handleToggleSelectOrder(o.id)}
                            className={`cursor-pointer transition-all ${
                              isSelected
                                ? 'bg-[#FFF5F1] dark:bg-[#FF6321]/10 font-medium'
                                : 'hover:bg-slate-50 dark:hover:bg-slate-800/40'
                            }`}
                          >
                            <td className="p-2.5 text-center">
                              <input
                                type="checkbox"
                                checked={isSelected}
                                onChange={() => {}}
                                className="w-4 h-4 text-[#FF6321] rounded focus:ring-0 cursor-pointer"
                              />
                            </td>
                            <td className="p-2.5">
                              <p className="font-bold text-[#FF6321] font-mono">{o.orderCode}</p>
                              <span className="text-[10px] text-slate-400 font-mono">{o.trackingCode}</span>
                            </td>
                            <td className="p-2.5">
                              <p className="font-bold text-slate-800 dark:text-white">{o.recipientName}</p>
                              <p className="text-[10px] text-slate-500 truncate max-w-[200px]">
                                {o.recipientAddress}
                              </p>
                            </td>
                            <td className="p-2.5">
                              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-200">
                                {o.area || 'Khác'}
                              </span>
                            </td>
                            <td className="p-2.5 text-right font-bold text-slate-900 dark:text-white font-mono">
                              {o.codAmount.toLocaleString('vi-VN')}đ
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>

          {/* Transfer Target & Confirmation Box */}
          <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-[#E5E7EB] dark:border-slate-800 shadow-sm flex flex-col justify-between space-y-4">
            <div>
              <h3 className="font-bold text-sm text-[#1F2937] dark:text-white pb-3 border-b border-[#E5E7EB] dark:border-slate-800 flex items-center gap-2">
                <Building2 className="w-4 h-4 text-[#FF6321]" /> Thông Tin Lô Bàn Giao
              </h3>

              <form onSubmit={handleCreateBatch} className="space-y-4 text-xs mt-4">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Quản Lý / Kho Tiếp Nhận (*)
                  </label>
                  <select
                    required
                    value={targetManagerId}
                    onChange={(e) => setTargetManagerId(e.target.value)}
                    className="w-full px-3 py-2 border border-[#E5E7EB] dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 font-bold text-slate-800 dark:text-white focus:outline-none focus:border-[#FF6321]"
                  >
                    <option value="">-- Chọn Quản lý kho tiếp nhận --</option>
                    {otherManagers.map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.fullName} ({m.phone})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Ghi Chú Bàn Giao Lô
                  </label>
                  <textarea
                    rows={3}
                    placeholder="VD: Lô hàng gửi đi kho Lộc Hà ca sáng 30/07. Giao nhận tiền theo lô."
                    value={batchNote}
                    onChange={(e) => setBatchNote(e.target.value)}
                    className="w-full px-3 py-2 border border-[#E5E7EB] dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 text-slate-800 dark:text-white focus:outline-none focus:border-[#FF6321]"
                  />
                </div>

                {/* Batch Summary */}
                <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-500 font-medium">Tổng số đơn trong lô:</span>
                    <strong className="font-bold text-[#FF6321] text-sm">{selectedOrderIds.length} đơn</strong>
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-500 font-medium">Tiền hàng COD:</span>
                    <span className="font-bold text-slate-700 dark:text-slate-200 font-mono">
                      {orders
                        .filter((o) => selectedOrderIds.includes(o.id))
                        .reduce((sum, o) => sum + o.codAmount, 0)
                        .toLocaleString('vi-VN')}
                      đ
                    </span>
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-500 font-medium">Cước phí ship:</span>
                    <span className="font-bold text-slate-700 dark:text-slate-200 font-mono">
                      {orders
                        .filter((o) => selectedOrderIds.includes(o.id))
                        .reduce((sum, o) => sum + (o.shippingFee || 0), 0)
                        .toLocaleString('vi-VN')}
                      đ
                    </span>
                  </div>
                  <div className="flex justify-between items-center text-xs pt-1 border-t border-slate-200 dark:border-slate-700">
                    <span className="text-slate-700 dark:text-slate-300 font-bold">Tổng tiền thu hộ (COD + Ship):</span>
                    <strong className="font-bold text-emerald-600 text-sm font-mono">
                      {orders
                        .filter((o) => selectedOrderIds.includes(o.id))
                        .reduce((sum, o) => sum + o.codAmount + (o.shippingFee || 0), 0)
                        .toLocaleString('vi-VN')}
                      đ
                    </strong>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={selectedOrderIds.length === 0 || !targetManagerId}
                  className="w-full py-3 bg-[#FF6321] hover:bg-[#e05318] disabled:bg-slate-300 text-white font-bold text-xs rounded-xl transition-all shadow-sm flex items-center justify-center gap-2"
                >
                  <FileText className="w-4 h-4" /> Lập Phiếu Chuyển Lô Kho
                </button>
              </form>
            </div>

            {/* Created Batch Receipt Modal/Card */}
            {createdBatch && (
              <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 rounded-xl text-xs space-y-2">
                <div className="flex items-center justify-between text-emerald-800 dark:text-emerald-300 font-bold">
                  <span className="flex items-center gap-1">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" /> Đã lập lô: {createdBatch.batchCode}
                  </span>
                  <button
                    onClick={() => window.print()}
                    className="p-1 hover:bg-emerald-100 rounded text-slate-700"
                    title="In phiếu bàn giao lô"
                  >
                    <Printer className="w-4 h-4" />
                  </button>
                </div>
                <p className="text-[#1F2937] dark:text-emerald-200">
                  Chuyển tới: <strong>{createdBatch.receiverManagerName}</strong>
                </p>
                <div className="pt-2 border-t border-emerald-200 dark:border-emerald-800 flex justify-between font-mono">
                  <span>{createdBatch.totalOrders} đơn hàng</span>
                  <span className="font-bold">{createdBatch.totalCodAmount.toLocaleString('vi-VN')}đ COD</span>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: RECEIVE BATCH & BARCODE SCANNING */}
      {activeTab === 'receive' && (
        <div className="space-y-6">
          <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-[#E5E7EB] dark:border-slate-800 shadow-sm space-y-4">
            <h3 className="font-bold text-sm text-[#1F2937] dark:text-white pb-3 border-b border-[#E5E7EB] dark:border-slate-800 flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Scan className="w-5 h-5 text-[#FF6321]" /> Các Lô Hàng Chuyển Đến Kho Của Bạn
              </span>
              <span className="text-xs font-normal text-slate-500">
                Nhận lô & quét mã vạch kiểm đếm đối soát theo từng đơn
              </span>
            </h3>

            {incomingBatches.length === 0 ? (
              <div className="py-12 text-center text-slate-400 text-xs">
                Hiện chưa có lô đơn hàng nào chuyển đến kho của bạn.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {incomingBatches.map((batch) => {
                  const isAccepted = batch.status === 'DA_TIEP_NHAN' || batch.status === 'DA_THANH_TOAN_COD';
                  return (
                    <div
                      key={batch.id}
                      className={`p-4 rounded-xl border transition-all space-y-3 ${
                        activeScanningBatch?.id === batch.id
                          ? 'border-[#FF6321] bg-[#FFF5F1] dark:bg-[#FF6321]/10 ring-2 ring-[#FF6321]/30'
                          : 'border-[#E5E7EB] dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 hover:border-slate-300'
                      }`}
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold font-mono bg-[#FF6321]/10 text-[#FF6321] border border-[#FF6321]/30">
                            {batch.batchCode}
                          </span>
                          <h4 className="font-bold text-xs text-[#1F2937] dark:text-white mt-1">
                            Khu vực: {batch.areaName}
                          </h4>
                        </div>
                        {isAccepted ? (
                          <span className="px-2 py-0.5 text-[10px] font-bold rounded bg-emerald-100 text-emerald-800 border border-emerald-300">
                            Đã Tiếp Nhận
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 text-[10px] font-bold rounded bg-amber-100 text-amber-800 border border-amber-300 animate-pulse">
                            Chờ Quét Nhận
                          </span>
                        )}
                      </div>

                      <div className="text-xs text-slate-600 dark:text-slate-300 space-y-1">
                        <p>Từ Quản lý: <strong>{batch.senderManagerName}</strong></p>
                        <p>Số đơn trong lô: <strong className="text-[#FF6321]">{batch.totalOrders} đơn</strong></p>
                        <p>Tổng tiền COD: <strong className="text-emerald-600 font-mono">{batch.totalCodAmount.toLocaleString('vi-VN')}đ</strong></p>
                        <p className="text-[10px] text-slate-400">Đã quét kiểm đếm: {batch.scannedOrderIds.length}/{batch.totalOrders} đơn</p>
                      </div>

                      <div className="pt-2 border-t border-slate-200 dark:border-slate-700 flex gap-2">
                        <button
                          onClick={() => {
                            setActiveScanningBatchId(batch.id);
                            setScanMessage(null);
                          }}
                          className="flex-1 py-1.5 bg-[#FF6321] hover:bg-[#e05318] text-white font-bold text-xs rounded-lg transition-all flex items-center justify-center gap-1"
                        >
                          <Scan className="w-3.5 h-3.5" /> Quét Đối Soát Lô
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* ACTIVE BARCODE SCANNING INSPECTOR PANEL */}
          {activeScanningBatch && (
            <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border-2 border-[#FF6321] shadow-lg space-y-4 animate-fade-in">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#E5E7EB] dark:border-slate-800">
                <div>
                  <div className="flex items-center gap-2">
                    <QrCode className="w-6 h-6 text-[#FF6321]" />
                    <h3 className="font-bold text-base text-[#1F2937] dark:text-white">
                      Kiểm Đếm Đối Soát Mã Vạch Lô: {activeScanningBatch.batchCode}
                    </h3>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    Gửi từ Quản lý {activeScanningBatch.senderManagerName} • Khu vực {activeScanningBatch.areaName}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <span className="px-3 py-1 bg-amber-100 text-amber-800 font-bold text-xs rounded-lg border border-amber-300">
                    Đã quét: {activeScanningBatch.scannedOrderIds.length} / {activeScanningBatch.totalOrders} đơn
                  </span>
                  <button
                    onClick={() => handleConfirmReceiveBatch(activeScanningBatch)}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-sm flex items-center gap-1.5"
                  >
                    <CheckCircle2 className="w-4 h-4" /> Xác Nhận Đã Nhận Đủ Lô
                  </button>
                </div>
              </div>

              {/* Barcode / Tracking Code Input Scanner */}
              <form onSubmit={handleScanSubmit} className="flex gap-2">
                <div className="relative flex-1">
                  <Scan className="w-5 h-5 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    autoFocus
                    placeholder="Dùng súng bắn mã vạch USB hoặc nhập Mã vận đơn (VD: VND-20260730-008)..."
                    value={scanInput}
                    onChange={(e) => setScanInput(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 text-sm border-2 border-[#FF6321] rounded-xl font-mono text-[#1F2937] dark:text-white bg-slate-50 dark:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-[#FF6321]"
                  />
                </div>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-[#FF6321] hover:bg-[#e05318] text-white font-bold text-xs rounded-xl transition-all shadow-sm flex items-center gap-1 shrink-0"
                >
                  <Scan className="w-4 h-4" /> Bắn Mã
                </button>
              </form>

              {/* Scan Message */}
              {scanMessage && (
                <div
                  className={`p-3 rounded-xl text-xs font-bold flex items-center gap-2 ${
                    scanMessage.type === 'success'
                      ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                      : 'bg-rose-100 text-rose-800 border border-rose-300'
                  }`}
                >
                  {scanMessage.type === 'success' ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  )}
                  <span>{scanMessage.text}</span>
                </div>
              )}

              {/* Itemized Order List inside Batch */}
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left">
                  <thead>
                    <tr className="border-b border-[#E5E7EB] dark:border-slate-800 text-slate-400 font-bold uppercase text-[10px]">
                      <th className="py-2.5 px-3 text-center">Kiểm Đếm</th>
                      <th className="py-2.5 px-3">Mã đơn & Vận đơn</th>
                      <th className="py-2.5 px-3">Người Nhận & Số Điện Thoại</th>
                      <th className="py-2.5 px-3">Sản Phẩm</th>
                      <th className="py-2.5 px-3 text-right">Tiền COD</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {orders
                      .filter((o) => activeScanningBatch.orderIds.includes(o.id))
                      .map((o) => {
                        const isScanned = activeScanningBatch.scannedOrderIds.includes(o.id);
                        return (
                          <tr
                            key={o.id}
                            className={`transition-all ${
                              isScanned
                                ? 'bg-emerald-50/60 dark:bg-emerald-950/20 font-medium'
                                : 'hover:bg-slate-50 dark:hover:bg-slate-800/40'
                            }`}
                          >
                            <td className="py-2.5 px-3 text-center">
                              {isScanned ? (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                                  <Check className="w-3 h-3 text-emerald-600" /> Đã quét
                                </span>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => {
                                    const res = scanOrderInBatch(activeScanningBatch.id, o.trackingCode);
                                    if (res.success) {
                                      setScanMessage({ type: 'success', text: res.message });
                                    } else {
                                      setScanMessage({ type: 'error', text: res.message });
                                    }
                                  }}
                                  className="px-2 py-1 rounded text-[10px] font-bold bg-[#FF6321]/10 hover:bg-[#FF6321] text-[#FF6321] hover:text-white border border-[#FF6321]/30 transition-all flex items-center gap-1 mx-auto"
                                  title="Bấm để mô phỏng quét mã này"
                                >
                                  <Scan className="w-3 h-3" /> Quét mã
                                </button>
                              )}
                            </td>
                            <td className="py-2.5 px-3 font-mono">
                              <p className="font-bold text-[#FF6321]">{o.orderCode}</p>
                              <p className="text-[10px] text-slate-400">{o.trackingCode}</p>
                            </td>
                            <td className="py-2.5 px-3">
                              <p className="font-bold text-[#1F2937] dark:text-white">{o.recipientName}</p>
                              <p className="text-[10px] text-slate-500">{o.recipientPhone} - {o.recipientAddress}</p>
                            </td>
                            <td className="py-2.5 px-3 text-slate-700 dark:text-slate-300">
                              {o.productName} (x{o.quantity})
                            </td>
                            <td className="py-2.5 px-3 text-right font-bold font-mono text-emerald-600">
                              {o.codAmount.toLocaleString('vi-VN')}đ
                            </td>
                          </tr>
                        );
                      })}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: BATCH COD SETTLEMENT */}
      {activeTab === 'settlement' && (
        <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-[#E5E7EB] dark:border-slate-800 shadow-sm space-y-4">
          <h3 className="font-bold text-sm text-[#1F2937] dark:text-white pb-3 border-b border-[#E5E7EB] dark:border-slate-800 flex items-center justify-between">
            <span className="flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-emerald-600" /> Trả Tiền & Đối Soát COD Theo Lô Cho Quản Lý
            </span>
            <span className="text-xs font-normal text-slate-500">
              Đối soát tài chính liên kho theo từng đợt lô hàng
            </span>
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="border-b border-[#E5E7EB] dark:border-slate-800 text-slate-400 font-bold uppercase text-[10px]">
                  <th className="py-3 px-3">Mã Lô</th>
                  <th className="py-3 px-3">Quản Lý Gửi / Nhận</th>
                  <th className="py-3 px-3">Khu Vực</th>
                  <th className="py-3 px-3 text-center">Số Đơn</th>
                  <th className="py-3 px-3 text-right">Tổng COD Lô</th>
                  <th className="py-3 px-3 text-center">Trạng Thái Thanh Toán</th>
                  <th className="py-3 px-3 text-right">Thao Tác</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {transferBatches.map((batch) => {
                  const isSettled = batch.status === 'DA_THANH_TOAN_COD';
                  return (
                    <tr key={batch.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                      <td className="py-3 px-3 font-mono font-bold text-[#FF6321]">
                        {batch.batchCode}
                      </td>
                      <td className="py-3 px-3">
                        <p className="font-semibold text-[#1F2937] dark:text-white">Từ: {batch.senderManagerName}</p>
                        <p className="text-[10px] text-slate-400">Đến: {batch.receiverManagerName}</p>
                      </td>
                      <td className="py-3 px-3">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-200">
                          {batch.areaName}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-center font-bold">{batch.totalOrders} đơn</td>
                      <td className="py-3 px-3 text-right font-bold text-emerald-600 font-mono">
                        {batch.totalCodAmount.toLocaleString('vi-VN')}đ
                      </td>
                      <td className="py-3 px-3 text-center">
                        {isSettled ? (
                          <span className="px-2.5 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                            Đã Thanh Toán COD
                          </span>
                        ) : (
                          <span className="px-2.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-300">
                            Chờ Thanh Toán
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-3 text-right">
                        {!isSettled ? (
                          <button
                            onClick={() => handleOpenSettleModal(batch)}
                            className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] rounded-lg transition-all shadow-sm"
                          >
                            Xác Nhận Trả Tiền Lô
                          </button>
                        ) : (
                          <span className="text-[10px] text-slate-400 italic">Đã đối soát</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Modal Settlement */}
      <Modal
        isOpen={!!settleModalBatch}
        onClose={() => setSettleModalBatch(null)}
        title={`Xác Nhận Trả Tiền COD Lô: ${settleModalBatch?.batchCode}`}
        maxWidth="max-w-md"
      >
        {settleModalBatch && (
          <div className="space-y-4 text-xs">
            <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 rounded-xl space-y-2">
              <p className="text-slate-700 dark:text-emerald-200">
                Kho nhận: <strong>{settleModalBatch.receiverManagerName}</strong>
              </p>
              <p className="text-slate-700 dark:text-emerald-200">
                Kho gửi: <strong>{settleModalBatch.senderManagerName}</strong>
              </p>
              <p className="text-slate-700 dark:text-emerald-200">
                Khu vực: <strong>{settleModalBatch.areaName}</strong> ({settleModalBatch.totalOrders} đơn)
              </p>
              <div className="pt-2 border-t border-emerald-200 flex justify-between items-center text-sm">
                <span className="font-bold text-slate-800 dark:text-white">Tổng tiền COD thu theo lô:</span>
                <strong className="font-bold text-emerald-600 font-mono text-base">
                  {settleModalBatch.totalCodAmount.toLocaleString('vi-VN')}đ
                </strong>
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                Số Tiền Thanh Toán Đối Soát (*):
              </label>
              <input
                type="number"
                value={settleAmount}
                onChange={(e) => setSettleAmount(Number(e.target.value))}
                className="w-full px-3 py-2 border border-[#E5E7EB] dark:border-slate-700 rounded-lg font-mono font-bold text-[#FF6321] dark:bg-slate-800"
              />
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-[#E5E7EB]">
              <button
                onClick={() => setSettleModalBatch(null)}
                className="px-4 py-2 bg-slate-100 text-slate-600 font-bold rounded-lg"
              >
                Hủy
              </button>
              <button
                onClick={handleSettleBatch}
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg shadow-sm"
              >
                Xác Nhận Hoàn Tất
              </button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};
