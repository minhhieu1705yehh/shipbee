import React from 'react';
import { DollarSign, Download, TrendingUp, AlertTriangle, ShieldCheck } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { formatVND } from '../../utils/helpers';
import { exportCodReportToExcel } from '../../utils/export';

export const CODReportView: React.FC = () => {
  const { users, orders, codDeposits } = useApp();

  const drivers = users.filter((u) => u.role === 'DRIVER');

  const handleExportCodReport = () => {
    exportCodReportToExcel(drivers, orders, codDeposits);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <DollarSign className="w-6 h-6 text-emerald-500" /> Báo Cáo & Đối Soát Tiền COD
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Theo dõi chi tiết số tiền COD cần thu, số tiền đã nộp và số tiền chênh lệch của từng Xế.
          </p>
        </div>
        <button
          onClick={handleExportCodReport}
          className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl transition-all shadow-md flex items-center gap-2 shrink-0"
        >
          <Download className="w-4 h-4" /> Xuất Excel Báo Cáo COD
        </button>
      </div>

      {/* Driver Breakdown Table */}
      <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-x-auto">
        <table className="w-full text-xs text-left">
          <thead>
            <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 font-semibold uppercase text-[10px]">
              <th className="py-3 px-3">Họ tên & SĐT Xế</th>
              <th className="py-3 px-3 text-center">Số đơn phân công</th>
              <th className="py-3 px-3 text-right">Tổng COD cần thu</th>
              <th className="py-3 px-3 text-right">Tổng COD đã thu thực tế</th>
              <th className="py-3 px-3 text-right">Tổng COD đã nộp kho</th>
              <th className="py-3 px-3 text-right">COD chưa nộp / Chênh lệch</th>
              <th className="py-3 px-3 text-center">Trạng thái</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
            {drivers.map((d) => {
              const driverOrders = orders.filter((o) => o.driverId === d.id);
              const deliveredOrders = driverOrders.filter((o) => ['GIAO_THANH_CONG', 'DA_NOP_COD', 'DA_DOI_SOAT'].includes(o.status));
              
              const codToCollect = driverOrders.reduce((sum, o) => sum + (o.codAmount || 0), 0);
              const codCollected = deliveredOrders.reduce((sum, o) => sum + (o.collectedCodAmount || o.codAmount || 0), 0);

              const driverDeposits = codDeposits.filter((dep) => dep.driverId === d.id && dep.status === 'DA_XAC_NHAN');
              const codDeposited = driverDeposits.reduce((sum, dep) => sum + dep.amount, 0);

              const codUnsubmitted = codCollected - codDeposited;

              return (
                <tr key={d.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                  <td className="py-3 px-3">
                    <div className="flex items-center gap-3">
                      <img src={d.avatarUrl} alt="" className="w-8 h-8 rounded-full object-cover border border-emerald-500" />
                      <div>
                        <p className="font-bold text-slate-900 dark:text-white">{d.fullName}</p>
                        <p className="text-[10px] text-slate-400">{d.phone}</p>
                      </div>
                    </div>
                  </td>
                  <td className="py-3 px-3 text-center font-bold text-slate-800 dark:text-slate-200">
                    {driverOrders.length} <span className="text-[10px] font-normal text-slate-400">({deliveredOrders.length} xong)</span>
                  </td>
                  <td className="py-3 px-3 text-right font-semibold text-slate-700 dark:text-slate-300">
                    {formatVND(codToCollect)}
                  </td>
                  <td className="py-3 px-3 text-right font-bold text-emerald-600 dark:text-emerald-400">
                    {formatVND(codCollected)}
                  </td>
                  <td className="py-3 px-3 text-right font-bold text-blue-600 dark:text-blue-400">
                    {formatVND(codDeposited)}
                  </td>
                  <td className="py-3 px-3 text-right">
                    <span className={`font-black text-xs ${codUnsubmitted > 0 ? 'text-rose-600 dark:text-rose-400' : 'text-slate-400'}`}>
                      {formatVND(codUnsubmitted)}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-center">
                    {codUnsubmitted === 0 ? (
                      <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300 font-bold rounded-md text-[10px]">
                        Đã khớp COD
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 bg-rose-100 text-rose-800 dark:bg-rose-900/40 dark:text-rose-300 font-bold rounded-md text-[10px]">
                        Còn đọng COD
                      </span>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
