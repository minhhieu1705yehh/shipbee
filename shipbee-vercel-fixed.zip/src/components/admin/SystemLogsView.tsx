import React, { useState } from 'react';
import { Clock, Search, Filter, Shield } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { formatDateTime } from '../../utils/helpers';

export const SystemLogsView: React.FC = () => {
  const { activityLogs, currentUser } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedEntity, setSelectedEntity] = useState<string>('ALL');

  const visibleLogs = activityLogs.filter((log) => {
    // Permission filter
    if (currentUser?.role === 'MANAGER') {
      // Manager sees logs related to manager
    } else if (currentUser?.role === 'DRIVER') {
      if (log.userId !== currentUser.id) return false;
    }

    const matchesSearch =
      log.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.action.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.details.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesEntity = selectedEntity === 'ALL' || log.entityType === selectedEntity;

    return matchesSearch && matchesEntity;
  });

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Clock className="w-6 h-6 text-amber-500" /> Nhật Ký Hoạt Động & Audit Log ({visibleLogs.length})
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Ghi nhận chính xác mọi thao tác tạo đơn, bàn giao, nhận đơn, đối soát và thu tiền. Không thể tự ý chỉnh sửa hay xóa logs.
          </p>
        </div>
      </div>

      {/* Filter controls */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
          <input
            type="text"
            placeholder="Tìm theo tên người thực hiện, hành động, chi tiết..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2.5 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500"
          />
        </div>

        <select
          value={selectedEntity}
          onChange={(e) => setSelectedEntity(e.target.value)}
          className="px-3 py-2.5 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl font-medium focus:outline-hidden"
        >
          <option value="ALL">-- Tất cả đối tượng thao tác --</option>
          <option value="ORDER">Đơn hàng (Order)</option>
          <option value="HANDOVER">Phiếu Bàn Giao (Handover)</option>
          <option value="COD">Nộp tiền COD</option>
          <option value="USER">Tài khoản (User)</option>
        </select>
      </div>

      {/* Logs Table */}
      <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-x-auto">
        <table className="w-full text-xs text-left">
          <thead>
            <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 font-semibold uppercase text-[10px]">
              <th className="py-3 px-3">Thời gian</th>
              <th className="py-3 px-3">Người thực hiện</th>
              <th className="py-3 px-3">Hành động</th>
              <th className="py-3 px-3">Chi tiết ghi nhận</th>
              <th className="py-3 px-3 text-right">Phân loại</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
            {visibleLogs.length === 0 ? (
              <tr>
                <td colSpan={5} className="text-center py-8 text-slate-400">
                  Không tìm thấy nhật ký thao tác
                </td>
              </tr>
            ) : (
              visibleLogs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                  <td className="py-3 px-3 whitespace-nowrap text-slate-400 font-mono text-[11px]">
                    {formatDateTime(log.timestamp)}
                  </td>
                  <td className="py-3 px-3 font-bold text-slate-900 dark:text-white whitespace-nowrap">
                    {log.userName} <span className="text-[10px] font-normal text-slate-400">({log.userRole})</span>
                  </td>
                  <td className="py-3 px-3 font-semibold text-amber-600 dark:text-amber-400 whitespace-nowrap">
                    {log.action}
                  </td>
                  <td className="py-3 px-3 text-slate-700 dark:text-slate-300">
                    {log.details}
                  </td>
                  <td className="py-3 px-3 text-right">
                    <span className="px-2 py-0.5 bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 rounded-md font-mono text-[10px]">
                      {log.entityType}
                    </span>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
