import React from 'react';
import {
  Users,
  PackageCheck,
  Truck,
  TrendingUp,
  AlertTriangle,
  DollarSign,
  CheckCircle2,
  XCircle,
  Clock,
  ArrowUpRight,
  ShieldAlert,
  RotateCcw,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { formatVND, formatDateTime } from '../../utils/helpers';

interface AdminDashboardProps {
  onNavigateTab: (tabKey: string) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onNavigateTab }) => {
  const { users, orders, handoverSheets, codDeposits, activityLogs } = useApp();

  const managers = users.filter((u) => u.role === 'MANAGER');
  const drivers = users.filter((u) => u.role === 'DRIVER');

  const totalOrders = orders.length;
  const deliveringOrders = orders.filter((o) => o.status === 'DANG_DI_GIAO' || o.status === 'DA_LIEN_HE_KHACH' || o.status === 'XE_DA_NHAN');
  const successOrders = orders.filter((o) => o.status === 'GIAO_THANH_CONG' || o.status === 'DA_NOP_COD' || o.status === 'DA_DOI_SOAT');
  const failedOrders = orders.filter((o) => ['GIAO_THAT_BAI', 'KHANG_HEN_GIAO_LAI', 'KHANG_KHONG_NGHE', 'SAI_DIA_CHI', 'KHANG_TU_CHOI'].includes(o.status));
  const returnedOrders = orders.filter((o) => o.status === 'DON_HOAN');

  const totalCodCollected = successOrders.reduce((sum, o) => sum + (o.collectedCodAmount || o.codAmount || 0), 0);
  const confirmedCodDeposits = codDeposits
    .filter((d) => d.status === 'DA_XAC_NHAN')
    .reduce((sum, d) => sum + d.amount, 0);
  const unsubmittedCod = totalCodCollected - confirmedCodDeposits;

  const discrepancyHandovers = handoverSheets.filter((s) => s.hasDiscrepancy || s.status === 'CO_SAI_LECH');

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between p-6 bg-[#1F2937] rounded-xl text-white shadow-lg border border-slate-700 gap-4">
        <div>
          <span className="text-[10px] font-bold uppercase tracking-widest text-[#FF6321] bg-[#FFF5F1]/10 px-2.5 py-1 rounded border border-[#FF6321]/30">
            Hệ thống Quản trị Admin
          </span>
          <h2 className="text-2xl font-black mt-2.5 tracking-tight text-white">Tổng Quan Bàn Giao & Đối Soát COD</h2>
          <p className="text-xs text-slate-300 mt-1 max-w-xl">
            Giám sát thời gian thực toàn bộ đơn hàng, phân cấp quản lý, dòng tiền COD và nhật ký đối soát toàn hệ thống.
          </p>
        </div>
        <div className="flex gap-2.5">
          <button
            onClick={() => onNavigateTab('accounts')}
            className="px-4 py-2.5 text-xs font-bold bg-[#FF6321] text-white hover:bg-[#e05318] rounded-md transition-all shadow-sm"
          >
            Quản Lý Tài Khoản
          </button>
          <button
            onClick={() => onNavigateTab('cod_report')}
            className="px-4 py-2.5 text-xs font-bold bg-white text-[#1F2937] hover:bg-gray-100 rounded-md transition-all shadow-sm border border-[#E5E7EB]"
          >
            Báo Cáo Đối Soát COD
          </button>
        </div>
      </div>

      {/* Discrepancy Alert Banner */}
      {discrepancyHandovers.length > 0 && (
        <div className="p-4 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 rounded-xl flex items-center justify-between text-xs text-rose-800 dark:text-rose-200">
          <div className="flex items-center gap-3">
            <ShieldAlert className="w-6 h-6 text-rose-600 dark:text-rose-400 shrink-0" />
            <div>
              <p className="font-bold text-sm">Cảnh báo sai lệch bàn giao ({discrepancyHandovers.length} phiếu)!</p>
              <p className="text-rose-600 dark:text-rose-300">
                Phát hiện phản hồi sai lệch đơn/COD từ Xế. Vui lòng kiểm tra các phiếu {discrepancyHandovers.map((s) => s.sheetCode).join(', ')}.
              </p>
            </div>
          </div>
          <button
            onClick={() => onNavigateTab('all_orders')}
            className="px-3 py-1.5 bg-rose-600 text-white font-bold rounded-md hover:bg-rose-700 transition-colors shrink-0 text-xs"
          >
            Xem ngay
          </button>
        </div>
      )}

      {/* Key Metrics Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1 */}
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-[#E5E7EB] dark:border-slate-800 shadow-sm space-y-1">
          <div className="text-[#9CA3AF] text-[10px] font-bold uppercase tracking-widest">Đội ngũ Nhân sự</div>
          <div className="text-2xl font-black text-[#1F2937] dark:text-white mt-1">{users.length} <span className="text-xs font-normal text-[#9CA3AF]">tài khoản</span></div>
          <div className="text-xs text-[#FF6321] font-medium mt-1">
            <strong>{managers.length}</strong> Quản lý • <strong>{drivers.length}</strong> Xế
          </div>
        </div>

        {/* Metric 2 */}
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-[#E5E7EB] dark:border-slate-800 shadow-sm space-y-1">
          <div className="text-[#9CA3AF] text-[10px] font-bold uppercase tracking-widest">Tổng Đơn Hàng</div>
          <div className="text-2xl font-black text-[#1F2937] dark:text-white mt-1">{totalOrders} <span className="text-xs font-normal text-[#9CA3AF]">đơn</span></div>
          <div className="text-xs text-blue-600 font-medium mt-1">
            {deliveringOrders.length} đang giao • {successOrders.length} xong
          </div>
        </div>

        {/* Metric 3 */}
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-[#E5E7EB] dark:border-slate-800 shadow-sm space-y-1">
          <div className="text-[#9CA3AF] text-[10px] font-bold uppercase tracking-widest">Tổng COD Đã Thu</div>
          <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400 mt-1">{formatVND(totalCodCollected)}</div>
          <div className="text-xs text-slate-500 font-medium mt-1">
            Đã nộp kho: {formatVND(confirmedCodDeposits)}
          </div>
        </div>

        {/* Metric 4 */}
        <div className="bg-[#1F2937] p-4 rounded-xl shadow-lg border border-slate-700 space-y-1">
          <div className="text-white opacity-60 text-[10px] font-bold uppercase tracking-widest">COD Chưa Nộp (Dư Xế)</div>
          <div className={`text-2xl font-black mt-1 ${unsubmittedCod > 0 ? 'text-[#FF6321]' : 'text-white'}`}>
            {formatVND(unsubmittedCod)}
          </div>
          <div className="text-xs text-green-400 font-medium mt-1">
            {unsubmittedCod > 0 ? 'Cần yêu cầu Xế nộp quầy' : 'Đã cân bằng 100%'}
          </div>
        </div>
      </div>

      {/* Detailed Order Status Breakdown Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/50 rounded-xl text-xs space-y-1">
          <span className="text-emerald-800 dark:text-emerald-300 font-bold flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4" /> Thành công
          </span>
          <p className="text-lg font-black text-emerald-900 dark:text-emerald-100">{successOrders.length} đơn</p>
        </div>

        <div className="p-4 bg-orange-50 dark:bg-orange-950/30 border border-orange-200 dark:border-orange-800/50 rounded-xl text-xs space-y-1">
          <span className="text-orange-800 dark:text-orange-300 font-bold flex items-center gap-1.5">
            <Truck className="w-4 h-4" /> Đang đi giao
          </span>
          <p className="text-lg font-black text-orange-900 dark:text-orange-100">{deliveringOrders.length} đơn</p>
        </div>

        <div className="p-4 bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-800/50 rounded-xl text-xs space-y-1">
          <span className="text-rose-800 dark:text-rose-300 font-bold flex items-center gap-1.5">
            <XCircle className="w-4 h-4" /> Giao thất bại
          </span>
          <p className="text-lg font-black text-rose-900 dark:text-rose-100">{failedOrders.length} đơn</p>
        </div>

        <div className="p-4 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs space-y-1">
          <span className="text-slate-800 dark:text-slate-300 font-bold flex items-center gap-1.5">
            <RotateCcw className="w-4 h-4" /> Đơn hoàn
          </span>
          <p className="text-lg font-black text-slate-900 dark:text-slate-100">{returnedOrders.length} đơn</p>
        </div>
      </div>

      {/* Two columns: Active Accounts & System Activity Feed */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Active Accounts list */}
        <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <h3 className="font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Users className="w-5 h-5 text-amber-500" /> Danh Sách Cấu Trúc Quản Lý & Xế
            </h3>
            <button
              onClick={() => onNavigateTab('accounts')}
              className="text-xs text-amber-600 dark:text-amber-400 font-semibold hover:underline flex items-center gap-1"
            >
              Quản lý tài khoản <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-4 max-h-96 overflow-y-auto">
            {managers.map((m) => {
              const managedDrivers = drivers.filter((d) => d.managerId === m.id);
              return (
                <div key={m.id} className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-700/60 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <img src={m.avatarUrl} alt="" className="w-8 h-8 rounded-full object-cover border border-blue-400" />
                      <div>
                        <p className="font-bold text-xs text-slate-900 dark:text-white">{m.fullName}</p>
                        <p className="text-[10px] text-slate-400">Quản lý • SĐT: {m.phone}</p>
                      </div>
                    </div>
                    <span className="px-2 py-0.5 bg-blue-100 text-blue-800 dark:bg-blue-900/50 dark:text-blue-300 text-[10px] font-extrabold rounded-md">
                      {managedDrivers.length} Xế phụ trách
                    </span>
                  </div>

                  {/* Sub-drivers list */}
                  <div className="pl-4 border-l-2 border-slate-200 dark:border-slate-700 space-y-2">
                    {managedDrivers.map((d) => {
                      const dOrders = orders.filter((o) => o.driverId === d.id);
                      const dDelivered = dOrders.filter((o) => o.status === 'GIAO_THANH_CONG' || o.status === 'DA_NOP_COD');
                      return (
                        <div key={d.id} className="flex items-center justify-between text-xs p-2 bg-white dark:bg-slate-800 rounded-lg border border-slate-100 dark:border-slate-700">
                          <span className="font-semibold text-slate-800 dark:text-slate-200">{d.fullName} ({d.phone})</span>
                          <span className="text-[11px] text-slate-500">
                            {dOrders.length} đơn ({dDelivered.length} xong)
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Real-time Activity Audit Feed */}
        <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <h3 className="font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Clock className="w-5 h-5 text-amber-500" /> Nhật Ký Thao Tác Hệ Thống
            </h3>
            <button
              onClick={() => onNavigateTab('logs')}
              className="text-xs text-amber-600 dark:text-amber-400 font-semibold hover:underline flex items-center gap-1"
            >
              Xem tất cả <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3 max-h-96 overflow-y-auto">
            {activityLogs.slice(0, 7).map((log) => (
              <div key={log.id} className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-slate-800 text-xs space-y-1">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-bold text-amber-600 dark:text-amber-400">{log.userName} ({log.userRole})</span>
                  <span className="text-slate-400">{formatDateTime(log.timestamp)}</span>
                </div>
                <p className="font-medium text-slate-800 dark:text-slate-200">{log.action}</p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">{log.details}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
