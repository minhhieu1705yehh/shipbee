import React, { useState } from 'react';
import { UserPlus, Lock, Unlock, Key, Shield, User, Smartphone, PlusCircle, Check } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Modal } from '../common/Modal';
import { UserRole } from '../../types';

export const AccountManagement: React.FC = () => {
  const { users, createAccount, toggleLockAccount, assignDriverToManager, addActivityLog } = useApp();

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [fullName, setFullName] = useState('');
  const [username, setUsername] = useState('');
  const [phone, setPhone] = useState('');
  const [role, setRole] = useState<UserRole>('MANAGER');
  const [selectedManagerId, setSelectedManagerId] = useState('');

  const [resetPassUser, setResetPassUser] = useState<string | null>(null);
  const [newPassword, setNewPassword] = useState('123456');

  const managers = users.filter((u) => u.role === 'MANAGER');
  const drivers = users.filter((u) => u.role === 'DRIVER');

  const handleCreateAccount = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName || !username || !phone) {
      alert('Vui lòng điền đầy đủ Họ tên, Username và SĐT');
      return;
    }

    createAccount({
      username,
      fullName,
      phone,
      role,
      managerId: role === 'DRIVER' ? selectedManagerId || managers[0]?.id : undefined,
      avatarUrl: `https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80`,
    });

    setIsAddModalOpen(false);
    setFullName('');
    setUsername('');
    setPhone('');
    alert('Tạo tài khoản thành công!');
  };

  const handleResetPassword = (userId: string) => {
    const target = users.find((u) => u.id === userId);
    if (target) {
      addActivityLog('Đặt lại mật khẩu', 'USER', userId, `Admin đặt lại mật khẩu cho ${target.fullName} thành "123456"`);
      alert(`Đã đặt lại mật khẩu cho tài khoản ${target.fullName} thành "123456"`);
      setResetPassUser(null);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Shield className="w-6 h-6 text-amber-500" /> Quản Lý Hệ Thống & Quản Lý Kho
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Admin quản lý chung & tạo Quản lý các khu vực. Mỗi Quản lý tự thêm & quản lý danh sách Xế trực thuộc.
          </p>
        </div>
        <button
          onClick={() => setIsAddModalOpen(true)}
          className="px-4 py-2.5 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-xl transition-all shadow-md flex items-center gap-2 shrink-0"
        >
          <UserPlus className="w-4 h-4" /> Tạo Tài Khoản Mới
        </button>
      </div>

      {/* Account Tables grouped by Role */}
      <div className="space-y-6">
        {/* Managers Section */}
        <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
          <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-600"></span> Danh Sách Quản Lý Đơn ({managers.length})
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 font-semibold uppercase text-[10px]">
                  <th className="py-3 px-3">Tài khoản & Họ tên</th>
                  <th className="py-3 px-3">Số điện thoại</th>
                  <th className="py-3 px-3">Xế trực thuộc</th>
                  <th className="py-3 px-3">Trạng thái</th>
                  <th className="py-3 px-3 text-right">Thao tác Admin</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {managers.map((m) => {
                  const subDrivers = drivers.filter((d) => d.managerId === m.id);
                  return (
                    <tr key={m.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                      <td className="py-3 px-3">
                        <div className="flex items-center gap-3">
                          <img src={m.avatarUrl} alt="" className="w-8 h-8 rounded-full object-cover border border-blue-500" />
                          <div>
                            <p className="font-bold text-slate-900 dark:text-white">{m.fullName}</p>
                            <p className="text-[10px] text-slate-400">@{m.username}</p>
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-3 font-semibold text-slate-700 dark:text-slate-300">{m.phone}</td>
                      <td className="py-3 px-3">
                        <span className="px-2 py-0.5 bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-300 rounded font-bold">
                          {subDrivers.length} Xế
                        </span>
                      </td>
                      <td className="py-3 px-3">
                        {m.isLocked ? (
                          <span className="px-2 py-0.5 bg-rose-100 text-rose-800 dark:bg-rose-900/40 dark:text-rose-300 rounded-md font-bold">Bị khóa</span>
                        ) : (
                          <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300 rounded-md font-bold">Đang hoạt động</span>
                        )}
                      </td>
                      <td className="py-3 px-3 text-right space-x-2">
                        <button
                          onClick={() => handleResetPassword(m.id)}
                          className="px-2.5 py-1 text-[11px] font-semibold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 rounded-lg transition-colors"
                          title="Đặt lại mật khẩu"
                        >
                          <Key className="w-3.5 h-3.5 inline mr-1" /> Reset Pass
                        </button>
                        <button
                          onClick={() => toggleLockAccount(m.id)}
                          className={`px-2.5 py-1 text-[11px] font-semibold rounded-lg transition-colors ${
                            m.isLocked
                              ? 'bg-emerald-600 text-white hover:bg-emerald-700'
                              : 'bg-rose-100 text-rose-800 dark:bg-rose-950/50 dark:text-rose-300 hover:bg-rose-200'
                          }`}
                        >
                          {m.isLocked ? <Unlock className="w-3.5 h-3.5 inline mr-1" /> : <Lock className="w-3.5 h-3.5 inline mr-1" />}
                          {m.isLocked ? 'Mở khóa' : 'Khóa'}
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Drivers Section */}
        <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
          <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-600"></span> Danh Sách Xế / Giao Hàng ({drivers.length})
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 font-semibold uppercase text-[10px]">
                  <th className="py-3 px-3">Tài khoản & Họ tên Xế</th>
                  <th className="py-3 px-3">Số điện thoại</th>
                  <th className="py-3 px-3">Quản lý trực thuộc</th>
                  <th className="py-3 px-3">Trạng thái</th>
                  <th className="py-3 px-3 text-right">Thao tác Admin</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {drivers.map((d) => {
                  const m = managers.find((mgr) => mgr.id === d.managerId);
                  return (
                    <tr key={d.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                      <td className="py-3 px-3">
                        <div className="flex items-center gap-3">
                          <img src={d.avatarUrl} alt="" className="w-8 h-8 rounded-full object-cover border border-emerald-500" />
                          <div>
                            <p className="font-bold text-slate-900 dark:text-white">{d.fullName}</p>
                            <p className="text-[10px] text-slate-400">@{d.username}</p>
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-3 font-semibold text-slate-700 dark:text-slate-300">{d.phone}</td>
                      <td className="py-3 px-3">
                        {/* Manager assign dropdown */}
                        <select
                          value={d.managerId || ''}
                          onChange={(e) => assignDriverToManager(d.id, e.target.value)}
                          className="px-2 py-1 text-xs bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg font-semibold text-slate-800 dark:text-slate-200 focus:outline-hidden"
                        >
                          {managers.map((mgr) => (
                            <option key={mgr.id} value={mgr.id}>
                              QL: {mgr.fullName}
                            </option>
                          ))}
                        </select>
                      </td>
                      <td className="py-3 px-3">
                        {d.isLocked ? (
                          <span className="px-2 py-0.5 bg-rose-100 text-rose-800 dark:bg-rose-900/40 dark:text-rose-300 rounded-md font-bold">Bị khóa</span>
                        ) : (
                          <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300 rounded-md font-bold">Hoạt động</span>
                        )}
                      </td>
                      <td className="py-3 px-3 text-right space-x-2">
                        <button
                          onClick={() => handleResetPassword(d.id)}
                          className="px-2.5 py-1 text-[11px] font-semibold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 rounded-lg transition-colors"
                          title="Đặt lại mật khẩu"
                        >
                          <Key className="w-3.5 h-3.5 inline mr-1" /> Reset Pass
                        </button>
                        <button
                          onClick={() => toggleLockAccount(d.id)}
                          className={`px-2.5 py-1 text-[11px] font-semibold rounded-lg transition-colors ${
                            d.isLocked
                              ? 'bg-emerald-600 text-white hover:bg-emerald-700'
                              : 'bg-rose-100 text-rose-800 dark:bg-rose-950/50 dark:text-rose-300 hover:bg-rose-200'
                          }`}
                        >
                          {d.isLocked ? <Unlock className="w-3.5 h-3.5 inline mr-1" /> : <Lock className="w-3.5 h-3.5 inline mr-1" />}
                          {d.isLocked ? 'Mở khóa' : 'Khóa'}
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Modal Add Account */}
      <Modal isOpen={isAddModalOpen} onClose={() => setIsAddModalOpen(false)} title="Tạo Tài Khoản Mới">
        <form onSubmit={handleCreateAccount} className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Loại tài khoản:</label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setRole('MANAGER')}
                className={`p-3 rounded-xl border text-center font-bold transition-all ${
                  role === 'MANAGER'
                    ? 'border-blue-600 bg-blue-50 text-blue-900 dark:bg-blue-950/50 dark:text-blue-200'
                    : 'border-slate-200 dark:border-slate-700 text-slate-600'
                }`}
              >
                Quản lý đơn
              </button>
              <button
                type="button"
                onClick={() => setRole('DRIVER')}
                className={`p-3 rounded-xl border text-center font-bold transition-all ${
                  role === 'DRIVER'
                    ? 'border-emerald-600 bg-emerald-50 text-emerald-900 dark:bg-emerald-950/50 dark:text-emerald-200'
                    : 'border-slate-200 dark:border-slate-700 text-slate-600'
                }`}
              >
                Xế giao hàng
              </button>
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Họ và tên đầy đủ:</label>
            <input
              type="text"
              required
              placeholder="VD: Nguyễn Văn A"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Tên đăng nhập (Username):</label>
              <input
                type="text"
                required
                placeholder="VD: quanly_caugiay"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Số điện thoại liên hệ:</label>
              <input
                type="text"
                required
                placeholder="0987654321"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500"
              />
            </div>
          </div>

          {role === 'DRIVER' && (
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Phân thuộc Quản lý đơn nào:</label>
              <select
                value={selectedManagerId}
                onChange={(e) => setSelectedManagerId(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500"
              >
                {managers.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.fullName} ({m.username})
                  </option>
                ))}
              </select>
            </div>
          )}

          <div className="pt-3 flex justify-end gap-3">
            <button
              type="button"
              onClick={() => setIsAddModalOpen(false)}
              className="px-4 py-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl"
            >
              Hủy
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl shadow-md"
            >
              Tạo Tài Khoản
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
