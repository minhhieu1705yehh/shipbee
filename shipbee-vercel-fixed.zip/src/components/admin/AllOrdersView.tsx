import React, { useState } from 'react';
import { Search, Download, Filter, MapPin, Phone, Package, Eye } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { formatVND, formatDateTime, getOrderStatusMeta, buildGoogleMapsUrl } from '../../utils/helpers';
import { exportOrdersToExcel } from '../../utils/export';
import { OrderStatus } from '../../types';

export const AllOrdersView: React.FC = () => {
  const { orders, users } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');
  const [selectedManager, setSelectedManager] = useState<string>('ALL');

  const managers = users.filter((u) => u.role === 'MANAGER');
  const drivers = users.filter((u) => u.role === 'DRIVER');

  const filteredOrders = orders.filter((o) => {
    const matchesSearch =
      o.orderCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
      o.trackingCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
      o.recipientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      o.recipientPhone.includes(searchTerm) ||
      o.recipientAddress.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = selectedStatus === 'ALL' || o.status === selectedStatus;
    const matchesManager = selectedManager === 'ALL' || o.managerId === selectedManager;

    return matchesSearch && matchesStatus && matchesManager;
  });

  const handleExport = () => {
    exportOrdersToExcel(filteredOrders, 'Toan_bo_don_hang_he_thong.xlsx');
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Package className="w-6 h-6 text-amber-500" /> Danh Sách Toàn Bộ Đơn Hàng ({filteredOrders.length})
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Xem và kiểm tra toàn bộ dữ liệu đơn hàng hệ thống theo thời gian thực.
          </p>
        </div>
        <button
          onClick={handleExport}
          className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl transition-all shadow-md flex items-center gap-2 shrink-0"
        >
          <Download className="w-4 h-4" /> Xuất File Excel Đơn Hàng
        </button>
      </div>

      {/* Filter controls */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
          <input
            type="text"
            placeholder="Tìm theo mã đơn, mã vận đơn, tên khách, SĐT..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2.5 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-amber-500"
          />
        </div>

        <select
          value={selectedStatus}
          onChange={(e) => setSelectedStatus(e.target.value)}
          className="px-3 py-2.5 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl font-medium focus:outline-hidden"
        >
          <option value="ALL">-- Tất cả trạng thái --</option>
          <option value="CHO_BAN_GIAO">Chờ bàn giao</option>
          <option value="DA_BAN_GIAO">Đã bàn giao</option>
          <option value="XE_DA_NHAN">Xế đã nhận</option>
          <option value="DANG_DI_GIAO">Đang đi giao</option>
          <option value="GIAO_THANH_CONG">Giao thành công</option>
          <option value="GIAO_THAT_BAI">Giao thất bại</option>
          <option value="KHANG_HEN_GIAO_LAI">Khách hẹn giao lại</option>
          <option value="DON_HOAN">Đơn hoàn</option>
          <option value="DA_NOP_COD">Đã nộp COD</option>
          <option value="DA_DOI_SOAT">Đã đối soát</option>
        </select>

        <select
          value={selectedManager}
          onChange={(e) => setSelectedManager(e.target.value)}
          className="px-3 py-2.5 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl font-medium focus:outline-hidden"
        >
          <option value="ALL">-- Tất cả Quản lý kho --</option>
          {managers.map((m) => (
            <option key={m.id} value={m.id}>
              Kho: {m.fullName}
            </option>
          ))}
        </select>
      </div>

      {/* Orders Table */}
      <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-x-auto">
        <table className="w-full text-xs text-left">
          <thead>
            <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 font-semibold uppercase text-[10px]">
              <th className="py-3 px-3">Mã đơn / Vận đơn</th>
              <th className="py-3 px-3">Người nhận & Địa chỉ</th>
              <th className="py-3 px-3">Tiền COD</th>
              <th className="py-3 px-3">Trạng thái</th>
              <th className="py-3 px-3">Quản lý kho</th>
              <th className="py-3 px-3">Xế phụ trách</th>
              <th className="py-3 px-3 text-right">Thời gian</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
            {filteredOrders.length === 0 ? (
              <tr>
                <td colSpan={7} className="text-center py-8 text-slate-400">
                  Không tìm thấy đơn hàng phù hợp
                </td>
              </tr>
            ) : (
              filteredOrders.map((ord) => {
                const statusMeta = getOrderStatusMeta(ord.status);
                const manager = managers.find((m) => m.id === ord.managerId);
                const driver = drivers.find((d) => d.id === ord.driverId);

                return (
                  <tr key={ord.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <td className="py-3 px-3">
                      <p className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                        {ord.orderCode}
                        {ord.isPriority && (
                          <span className="px-1.5 py-0.2 bg-rose-500 text-white font-black text-[9px] rounded-sm">Ưu tiên</span>
                        )}
                      </p>
                      <p className="text-[10px] text-slate-400">{ord.trackingCode}</p>
                    </td>
                    <td className="py-3 px-3 max-w-xs">
                      <p className="font-semibold text-slate-800 dark:text-slate-200">{ord.recipientName} ({ord.recipientPhone})</p>
                      <p className="text-[11px] text-slate-500 truncate">{ord.recipientAddress}</p>
                    </td>
                    <td className="py-3 px-3 font-bold text-slate-900 dark:text-white">
                      {formatVND(ord.codAmount)}
                    </td>
                    <td className="py-3 px-3">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${statusMeta.badgeClass}`}>
                        {statusMeta.label}
                      </span>
                    </td>
                    <td className="py-3 px-3 font-medium text-slate-700 dark:text-slate-300">
                      {manager?.fullName || 'N/A'}
                    </td>
                    <td className="py-3 px-3 font-medium text-slate-700 dark:text-slate-300">
                      {driver ? driver.fullName : <span className="text-slate-400 italic">Chưa gán</span>}
                    </td>
                    <td className="py-3 px-3 text-right text-[11px] text-slate-400">
                      {formatDateTime(ord.createdAt)}
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
