import { User, Order, HandoverSheet, CODDeposit, ActivityLog, NotificationItem, ManagerTransferBatch } from '../types';
import {
  INITIAL_USERS,
  INITIAL_ORDERS,
  INITIAL_HANDOVER_SHEETS,
  INITIAL_COD_DEPOSITS,
  INITIAL_ACTIVITY_LOGS,
  INITIAL_NOTIFICATIONS,
  INITIAL_TRANSFER_BATCHES,
} from '../mockData';

const KEYS = {
  USERS: 'ghpro_users_v1',
  ORDERS: 'ghpro_orders_v1',
  HANDOVERS: 'ghpro_handovers_v1',
  COD_DEPOSITS: 'ghpro_cod_deposits_v1',
  LOGS: 'ghpro_activity_logs_v1',
  NOTIFS: 'ghpro_notifications_v1',
  TRANSFER_BATCHES: 'ghpro_transfer_batches_v1',
  CURRENT_USER_ID: 'ghpro_current_user_id_v1',
  THEME: 'ghpro_theme_v1',
};

export const Storage = {
  getUsers(): User[] {
    const raw = localStorage.getItem(KEYS.USERS);
    if (!raw) {
      localStorage.setItem(KEYS.USERS, JSON.stringify(INITIAL_USERS));
      return INITIAL_USERS;
    }
    try {
      return JSON.parse(raw);
    } catch {
      return INITIAL_USERS;
    }
  },

  saveUsers(users: User[]) {
    localStorage.setItem(KEYS.USERS, JSON.stringify(users));
  },

  getOrders(): Order[] {
    const raw = localStorage.getItem(KEYS.ORDERS);
    if (!raw) {
      localStorage.setItem(KEYS.ORDERS, JSON.stringify(INITIAL_ORDERS));
      return INITIAL_ORDERS;
    }
    try {
      return JSON.parse(raw);
    } catch {
      return INITIAL_ORDERS;
    }
  },

  saveOrders(orders: Order[]) {
    localStorage.setItem(KEYS.ORDERS, JSON.stringify(orders));
  },

  getHandovers(): HandoverSheet[] {
    const raw = localStorage.getItem(KEYS.HANDOVERS);
    if (!raw) {
      localStorage.setItem(KEYS.HANDOVERS, JSON.stringify(INITIAL_HANDOVER_SHEETS));
      return INITIAL_HANDOVER_SHEETS;
    }
    try {
      return JSON.parse(raw);
    } catch {
      return INITIAL_HANDOVER_SHEETS;
    }
  },

  saveHandovers(sheets: HandoverSheet[]) {
    localStorage.setItem(KEYS.HANDOVERS, JSON.stringify(sheets));
  },

  getCodDeposits(): CODDeposit[] {
    const raw = localStorage.getItem(KEYS.COD_DEPOSITS);
    if (!raw) {
      localStorage.setItem(KEYS.COD_DEPOSITS, JSON.stringify(INITIAL_COD_DEPOSITS));
      return INITIAL_COD_DEPOSITS;
    }
    try {
      return JSON.parse(raw);
    } catch {
      return INITIAL_COD_DEPOSITS;
    }
  },

  saveCodDeposits(deposits: CODDeposit[]) {
    localStorage.setItem(KEYS.COD_DEPOSITS, JSON.stringify(deposits));
  },

  getActivityLogs(): ActivityLog[] {
    const raw = localStorage.getItem(KEYS.LOGS);
    if (!raw) {
      localStorage.setItem(KEYS.LOGS, JSON.stringify(INITIAL_ACTIVITY_LOGS));
      return INITIAL_ACTIVITY_LOGS;
    }
    try {
      return JSON.parse(raw);
    } catch {
      return INITIAL_ACTIVITY_LOGS;
    }
  },

  saveActivityLogs(logs: ActivityLog[]) {
    localStorage.setItem(KEYS.LOGS, JSON.stringify(logs));
  },

  getNotifications(): NotificationItem[] {
    const raw = localStorage.getItem(KEYS.NOTIFS);
    if (!raw) {
      localStorage.setItem(KEYS.NOTIFS, JSON.stringify(INITIAL_NOTIFICATIONS));
      return INITIAL_NOTIFICATIONS;
    }
    try {
      return JSON.parse(raw);
    } catch {
      return INITIAL_NOTIFICATIONS;
    }
  },

  saveNotifications(notifs: NotificationItem[]) {
    localStorage.setItem(KEYS.NOTIFS, JSON.stringify(notifs));
  },

  getTransferBatches(): ManagerTransferBatch[] {
    const raw = localStorage.getItem(KEYS.TRANSFER_BATCHES);
    if (!raw) {
      localStorage.setItem(KEYS.TRANSFER_BATCHES, JSON.stringify(INITIAL_TRANSFER_BATCHES));
      return INITIAL_TRANSFER_BATCHES;
    }
    try {
      return JSON.parse(raw);
    } catch {
      return INITIAL_TRANSFER_BATCHES;
    }
  },

  saveTransferBatches(batches: ManagerTransferBatch[]) {
    localStorage.setItem(KEYS.TRANSFER_BATCHES, JSON.stringify(batches));
  },

  getCurrentUserId(): string {
    return localStorage.getItem(KEYS.CURRENT_USER_ID) || 'usr_admin';
  },

  saveCurrentUserId(id: string) {
    localStorage.setItem(KEYS.CURRENT_USER_ID, id);
  },

  getTheme(): 'light' | 'dark' {
    return (localStorage.getItem(KEYS.THEME) as 'light' | 'dark') || 'light';
  },

  saveTheme(theme: 'light' | 'dark') {
    localStorage.setItem(KEYS.THEME, theme);
  },

  resetToDemo() {
    localStorage.setItem(KEYS.USERS, JSON.stringify(INITIAL_USERS));
    localStorage.setItem(KEYS.ORDERS, JSON.stringify(INITIAL_ORDERS));
    localStorage.setItem(KEYS.HANDOVERS, JSON.stringify(INITIAL_HANDOVER_SHEETS));
    localStorage.setItem(KEYS.COD_DEPOSITS, JSON.stringify(INITIAL_COD_DEPOSITS));
    localStorage.setItem(KEYS.LOGS, JSON.stringify(INITIAL_ACTIVITY_LOGS));
    localStorage.setItem(KEYS.NOTIFS, JSON.stringify(INITIAL_NOTIFICATIONS));
    localStorage.setItem(KEYS.CURRENT_USER_ID, 'usr_admin');
  },
};
