import { OrderStatus, HandoverSheetStatus, CODDepositStatus } from '../types';

export function formatVND(amount: number): string {
  return new Intl.NumberFormat('vi-VN', {
    style: 'currency',
    currency: 'VND',
    maximumFractionDigits: 0,
  }).format(amount || 0);
}

export function formatDateTime(isoString?: string): string {
  if (!isoString) return '--/--/---- --:--';
  const d = new Date(isoString);
  return d.toLocaleString('vi-VN', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function formatDateOnly(isoString?: string): string {
  if (!isoString) return '--/--/----';
  const d = new Date(isoString);
  return d.toLocaleDateString('vi-VN', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  });
}

export function formatTimeOnly(isoString?: string): string {
  if (!isoString) return '--:--';
  const d = new Date(isoString);
  return d.toLocaleTimeString('vi-VN', {
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function getOrderStatusMeta(status: OrderStatus): { label: string; bg: string; text: string; badgeClass: string } {
  switch (status) {
    case 'CHO_BAN_GIAO':
      return {
        label: 'Chờ bàn giao',
        bg: 'bg-amber-100 dark:bg-amber-900/40',
        text: 'text-amber-800 dark:text-amber-300',
        badgeClass: 'bg-amber-100 text-amber-800 border-amber-300 dark:bg-amber-900/40 dark:text-amber-300 dark:border-amber-700',
      };
    case 'DA_BAN_GIAO':
      return {
        label: 'Đã bàn giao (Chờ Xế)',
        bg: 'bg-blue-100 dark:bg-blue-900/40',
        text: 'text-blue-800 dark:text-blue-300',
        badgeClass: 'bg-blue-100 text-blue-800 border-blue-300 dark:bg-blue-900/40 dark:text-blue-300 dark:border-blue-700',
      };
    case 'XE_DA_NHAN':
      return {
        label: 'Xế đã nhận',
        bg: 'bg-indigo-100 dark:bg-indigo-900/40',
        text: 'text-indigo-800 dark:text-indigo-300',
        badgeClass: 'bg-indigo-100 text-indigo-800 border-indigo-300 dark:bg-indigo-900/40 dark:text-indigo-300 dark:border-indigo-700',
      };
    case 'DANG_DI_GIAO':
      return {
        label: 'Đang đi giao',
        bg: 'bg-orange-100 dark:bg-orange-900/40',
        text: 'text-orange-800 dark:text-orange-300',
        badgeClass: 'bg-orange-100 text-orange-800 border-orange-300 dark:bg-orange-900/40 dark:text-orange-300 dark:border-orange-700',
      };
    case 'DA_LIEN_HE_KHACH':
      return {
        label: 'Đã liên hệ khách',
        bg: 'bg-cyan-100 dark:bg-cyan-900/40',
        text: 'text-cyan-800 dark:text-cyan-300',
        badgeClass: 'bg-cyan-100 text-cyan-800 border-cyan-300 dark:bg-cyan-900/40 dark:text-cyan-300 dark:border-cyan-700',
      };
    case 'GIAO_THANH_CONG':
      return {
        label: 'Giao thành công',
        bg: 'bg-emerald-100 dark:bg-emerald-900/40',
        text: 'text-emerald-800 dark:text-emerald-300',
        badgeClass: 'bg-emerald-100 text-emerald-800 border-emerald-300 dark:bg-emerald-900/40 dark:text-emerald-300 dark:border-emerald-700',
      };
    case 'GIAO_THAT_BAI':
      return {
        label: 'Giao thất bại',
        bg: 'bg-rose-100 dark:bg-rose-900/40',
        text: 'text-rose-800 dark:text-rose-300',
        badgeClass: 'bg-rose-100 text-rose-800 border-rose-300 dark:bg-rose-900/40 dark:text-rose-300 dark:border-rose-700',
      };
    case 'KHANG_HEN_GIAO_LAI':
      return {
        label: 'Khách hẹn giao lại',
        bg: 'bg-purple-100 dark:bg-purple-900/40',
        text: 'text-purple-800 dark:text-purple-300',
        badgeClass: 'bg-purple-100 text-purple-800 border-purple-300 dark:bg-purple-900/40 dark:text-purple-300 dark:border-purple-700',
      };
    case 'KHANG_KHONG_NGHE':
      return {
        label: 'Khách không nghe máy',
        bg: 'bg-pink-100 dark:bg-pink-900/40',
        text: 'text-pink-800 dark:text-pink-300',
        badgeClass: 'bg-pink-100 text-pink-800 border-pink-300 dark:bg-pink-900/40 dark:text-pink-300 dark:border-pink-700',
      };
    case 'SAI_DIA_CHI':
      return {
        label: 'Sai địa chỉ',
        bg: 'bg-red-100 dark:bg-red-900/40',
        text: 'text-red-800 dark:text-red-300',
        badgeClass: 'bg-red-100 text-red-800 border-red-300 dark:bg-red-900/40 dark:text-red-300 dark:border-red-700',
      };
    case 'KHANG_TU_CHOI':
      return {
        label: 'Khách từ chối nhận',
        bg: 'bg-rose-100 dark:bg-rose-900/40',
        text: 'text-rose-800 dark:text-rose-300',
        badgeClass: 'bg-rose-100 text-rose-800 border-rose-300 dark:bg-rose-900/40 dark:text-rose-300 dark:border-rose-700',
      };
    case 'DON_HOAN':
      return {
        label: 'Đơn hoàn',
        bg: 'bg-slate-200 dark:bg-slate-700',
        text: 'text-slate-800 dark:text-slate-200',
        badgeClass: 'bg-slate-200 text-slate-800 border-slate-300 dark:bg-slate-700 dark:text-slate-200 dark:border-slate-600',
      };
    case 'DA_NOP_COD':
      return {
        label: 'Đã nộp COD',
        bg: 'bg-teal-100 dark:bg-teal-900/40',
        text: 'text-teal-800 dark:text-teal-300',
        badgeClass: 'bg-teal-100 text-teal-800 border-teal-300 dark:bg-teal-900/40 dark:text-teal-300 dark:border-teal-700',
      };
    case 'DA_DOI_SOAT':
      return {
        label: 'Đã đối soát',
        bg: 'bg-green-100 dark:bg-green-900/40',
        text: 'text-green-800 dark:text-green-300',
        badgeClass: 'bg-green-100 text-green-800 border-green-300 dark:bg-green-900/40 dark:text-green-300 dark:border-green-700',
      };
    default:
      return {
        label: status,
        bg: 'bg-gray-100 dark:bg-gray-800',
        text: 'text-gray-800 dark:text-gray-200',
        badgeClass: 'bg-gray-100 text-gray-800 border-gray-300 dark:bg-gray-800 dark:text-gray-200',
      };
  }
}

export function getHandoverSheetStatusMeta(status: HandoverSheetStatus): { label: string; badgeClass: string } {
  switch (status) {
    case 'CHO_XE_XAC_NHAN':
      return {
        label: 'Chờ Xế xác nhận',
        badgeClass: 'bg-amber-100 text-amber-800 border-amber-300 dark:bg-amber-900/40 dark:text-amber-300 dark:border-amber-700',
      };
    case 'XE_DA_XAC_NHAN':
      return {
        label: 'Xế đã nhận',
        badgeClass: 'bg-blue-100 text-blue-800 border-blue-300 dark:bg-blue-900/40 dark:text-blue-300 dark:border-blue-700',
      };
    case 'DANG_GIAO_HANG':
      return {
        label: 'Đang giao hàng',
        badgeClass: 'bg-orange-100 text-orange-800 border-orange-300 dark:bg-orange-900/40 dark:text-orange-300 dark:border-orange-700',
      };
    case 'DA_HOAN_TAT':
      return {
        label: 'Đã giao xong',
        badgeClass: 'bg-emerald-100 text-emerald-800 border-emerald-300 dark:bg-emerald-900/40 dark:text-emerald-300 dark:border-emerald-700',
      };
    case 'CHO_DOI_SOAT':
      return {
        label: 'Chờ đối soát',
        badgeClass: 'bg-purple-100 text-purple-800 border-purple-300 dark:bg-purple-900/40 dark:text-purple-300 dark:border-purple-700',
      };
    case 'DA_DOI_SOAT':
      return {
        label: 'Đã đối soát',
        badgeClass: 'bg-green-100 text-green-800 border-green-300 dark:bg-green-900/40 dark:text-green-300 dark:border-green-700',
      };
    case 'CO_SAI_LECH':
      return {
        label: 'Có sai lệch!',
        badgeClass: 'bg-rose-100 text-rose-800 border-rose-300 dark:bg-rose-900/40 dark:text-rose-300 dark:border-rose-700',
      };
    default:
      return {
        label: status,
        badgeClass: 'bg-gray-100 text-gray-800 border-gray-300 dark:bg-gray-800 dark:text-gray-200',
      };
  }
}

export function buildGoogleMapsUrl(address: string): string {
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(address)}`;
}

export async function copyToClipboard(text: string): Promise<boolean> {
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      return true;
    } else {
      const textArea = document.createElement('textarea');
      textArea.value = text;
      textArea.style.position = 'fixed';
      textArea.style.left = '-999999px';
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();
      const successful = document.execCommand('copy');
      document.body.removeChild(textArea);
      return successful;
    }
  } catch (err) {
    console.error('Copy failed:', err);
    return false;
  }
}
