import * as XLSX from 'xlsx';
import { Order, HandoverSheet, CODDeposit, User } from '../types';
import { formatVND, formatDateTime, getOrderStatusMeta } from './helpers';

export function exportOrdersToExcel(orders: Order[], filename = 'Danh_sach_don_hang.xlsx') {
  const data = orders.map((ord, idx) => ({
    'STT': idx + 1,
    'Mã đơn': ord.orderCode,
    'Mã vận đơn': ord.trackingCode,
    'Tên người nhận': ord.recipientName,
    'Số điện thoại': ord.recipientPhone,
    'Địa chỉ': ord.recipientAddress,
    'Khu vực': ord.area || '',
    'Sản phẩm': ord.productName,
    'Số lượng': ord.quantity,
    'Tiền COD': ord.codAmount,
    'Phí giao hàng': ord.shippingFee,
    'Trạng thái': getOrderStatusMeta(ord.status).label,
    'Ghi chú': ord.notes || '',
    'Thời gian tạo': formatDateTime(ord.createdAt),
    'Thời gian bàn giao': formatDateTime(ord.handoverAt),
    'Thời gian giao hàng': formatDateTime(ord.deliveredAt),
    'Lý do giao thất bại': ord.failureReason || '',
  }));

  const worksheet = XLSX.utils.json_to_sheet(data);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Đơn hàng');
  XLSX.writeFile(workbook, filename);
}

export function exportHandoverSheetToExcel(sheet: HandoverSheet, orders: Order[]) {
  const sheetOrders = orders.filter((o) => sheet.orderIds.includes(o.id));

  const headerInfo = [
    ['PHIẾU BÀN GIAO ĐƠN HÀNG ĐIỆN TỬ'],
    ['Mã phiếu:', sheet.sheetCode],
    ['Quản lý bàn giao:', sheet.managerName],
    ['Xế tiếp nhận:', sheet.driverName],
    ['Thời gian tạo:', formatDateTime(sheet.createdAt)],
    ['Tổng số đơn:', sheet.totalOrders],
    ['Tổng COD:', formatVND(sheet.totalCodAmount)],
    ['Trạng thái phiếu:', sheet.status],
    [],
    ['DANH SÁCH ĐƠN HÀNG BÀN GIAO'],
  ];

  const orderRows = sheetOrders.map((ord, idx) => ({
    'STT': idx + 1,
    'Mã đơn': ord.orderCode,
    'Mã vận đơn': ord.trackingCode,
    'Khách hàng': ord.recipientName,
    'SĐT': ord.recipientPhone,
    'Địa chỉ': ord.recipientAddress,
    'Sản phẩm': ord.productName,
    'Tiền COD': ord.codAmount,
    'Ghi chú': ord.notes || '',
  }));

  const worksheet = XLSX.utils.aoa_to_sheet(headerInfo);
  XLSX.utils.sheet_add_json(worksheet, orderRows, { origin: 'A11' });

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, sheet.sheetCode);
  XLSX.writeFile(workbook, `Phieu_ban_giao_${sheet.sheetCode}.xlsx`);
}

export function exportCodReportToExcel(drivers: User[], orders: Order[], deposits: CODDeposit[]) {
  const reportData = drivers.map((d, idx) => {
    const driverOrders = orders.filter((o) => o.driverId === d.id);
    const delivered = driverOrders.filter((o) => o.status === 'GIAO_THANH_CONG' || o.status === 'DA_NOP_COD' || o.status === 'DA_DOI_SOAT');
    const codToCollect = driverOrders.reduce((sum, o) => sum + (o.codAmount || 0), 0);
    const codCollected = delivered.reduce((sum, o) => sum + (o.collectedCodAmount || o.codAmount || 0), 0);
    
    const driverDeposits = deposits.filter((dep) => dep.driverId === d.id && dep.status === 'DA_XAC_NHAN');
    const codDeposited = driverDeposits.reduce((sum, dep) => sum + dep.amount, 0);
    const codUnsubmitted = codCollected - codDeposited;

    return {
      'STT': idx + 1,
      'Mã / Tên Xế': d.fullName,
      'Số điện thoại': d.phone,
      'Tổng đơn được giao': driverOrders.length,
      'Đơn giao thành công': delivered.length,
      'Tổng COD cần thu': codToCollect,
      'Tổng COD đã thu': codCollected,
      'Tổng COD đã nộp kho': codDeposited,
      'COD chưa nộp / Chênh lệch': codUnsubmitted,
    };
  });

  const worksheet = XLSX.utils.json_to_sheet(reportData);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Báo cáo COD Xế');
  XLSX.writeFile(workbook, `Bao_cao_doi_soat_COD_${new Date().toISOString().slice(0, 10)}.xlsx`);
}
